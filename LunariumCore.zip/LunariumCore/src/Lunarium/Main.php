<?php

namespace Lunarium;

use CortexPE\Commando\PacketHooker;
use Lunarium\Command\Player\Faction\FactionCommandManager;
use Lunarium\Listener\Events\PlayerRankEv;
use Lunarium\Managers\FactionManager;
use Lunarium\Managers\MaintenanceManager;
use Lunarium\Managers\MoneyManager;
use Lunarium\Managers\RegionManager;
use Lunarium\Managers\SanctionManager;
use Lunarium\Utils\Loader;
use Lunarium\Utils\Utils;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;

class Main extends PluginBase implements Listener
{
    public static Config $rank_data;
    public static Config $data;
    public static Config $datsa;
    public MaintenanceManager $maintenanceManager;
    public RegionManager $regionManager;

    use SingletonTrait;
    public function onEnable(): void
    {
        self::setInstance($this);

        if (!InvMenuHandler::isRegistered()) InvMenuHandler::register($this);
        if (!PacketHooker::isRegistered()) PacketHooker::register($this);

        $config = new Config($this->getDataFolder() . "maintenance.yml", Config::YAML);

        $this->getServer()->getNetwork()->setName("§dLunarium V1");
        $this->maintenanceManager = new MaintenanceManager($config->getNested("maintenance.enabled", false), $config->getNested("maintenance.whitelist", []));

        self::$rank_data = new Config($this->getDataFolder() . "colorrank.yml", Config::YAML);
        self::$data = new Config($this->getDataFolder() . "ranks.yml", Config::YAML);
        self::$datsa = new Config($this->getDataFolder() . "rankplayer.yml", Config::YAML);

        $this->getServer()->getCommandMap()->register("", new FactionCommandManager($this, "f", "Commandes de Faction", ["faction"]));

        Loader::loadUtils();
        Loader::loadItems();
        Loader::loadBlocks();
        Loader::unregisterCommands();
        Loader::loadCommands();
        Loader::loadEvents();
        Loader::loadTasks();



        self::getInstance()->getServer()->getWorldManager()->loadWorld("Flat");

        @mkdir(Main::getInstance()->getDataFolder() . "Statistics");
        @mkdir(Main::getInstance()->getDataFolder() . "blocks/");
        @mkdir(Main::getInstance()->getDataFolder());
    }

    protected function onDisable(): void
    {
        foreach(Utils::$lotteryp as $name => $prix){
            MoneyManager::addMoney($name, $prix);
        }
        $onlinep = Server::getInstance()->getOnlinePlayers();
        foreach ($onlinep as $player){
            $player->transfer("lunarium.mcbe.fr", "19170");
        }
    }

    public function getSanctionManager(): SanctionManager
    {
        return new SanctionManager();
    }

    public function getFactionManager(): FactionManager
    {
        return new FactionManager();
    }

    public function getRegionManager(): RegionManager
    {
        return $this->regionManager;
    }

    public function intToTime($temps, string $color = "§f"): string
    {
        $pluriel = function($nombre, $singulier, $pluriel) {
            return $nombre === 1 ? "$nombre $singulier" : "$nombre $pluriel";
        };

        if ($temps >= 86400) {
            $jours = floor($temps / 86400);
            $reste = $temps % 86400;
            $heures = floor($reste / 3600);
            $reste = $reste % 3600;
            $minutes = floor($reste / 60);
            $secondes = $reste % 60;
            return "§d" . $pluriel($jours, "jour", "jours") . "$color et §d" . $pluriel($heures, "heure", "heures") . "$color et §d" . $pluriel($minutes, "minute", "minutes") . "$color et §d" . $pluriel($secondes, "seconde", "secondes") . " $color";
        } elseif ($temps >= 3600) {
            $heures = floor($temps / 3600);
            $reste = $temps % 3600;
            $minutes = floor($reste / 60);
            $secondes = $reste % 60;
            return "§d" . $pluriel($heures, "heure", "heures") . "$color et §d" . $pluriel($minutes, "minute", "minutes") . "$color et §d" . $pluriel($secondes, "seconde", "secondes") . " $color";
        } elseif ($temps >= 60) {
            $minutes = floor($temps / 60);
            $secondes = $temps % 60;
            return "§d" . $pluriel($minutes, "minute", "minutes") . "$color et §d" . $pluriel($secondes, "seconde", "secondes") . " $color";
        } else {
            return "§d" . $pluriel($temps, "seconde", "secondes") . " $color";
        }
    }

    public function getAllRanks(): array
    {
        $ranks = [];
        foreach (self::$rank_data->getAll() as $rank => $perms) {
            $ranks[] = $rank;
        }
        return $ranks;
    }

    public function addRank(string $rank, string $color): void
    {
        $config = new Config($this->getDataFolder() . "colorrank.yml", Config::YAML);
        $config->setNested("color.$rank", $color);
        $config->save();
        self::$rank_data->set($rank, []);
        self::$rank_data->save();
    }

    public function removeRank(string $rank): void
    {
        foreach (self::$data->getAll() as $player => $key) {
            if ($key["rank"] === $rank) {
                $this->setRank($player, "Joueur");
                $user = $this->getServer()->getPlayerByPrefix($player);
                if ($user instanceof Player) PlayerRankEv::updateNameTag($user);
            }
        }

        self::$rank_data->remove($rank);
        self::$rank_data->save();
    }

    public function getRank($player): string
    {
        if ($this->existPlayer($player)) {
            return self::$data->get($this->getPlayerName($player))["rank"];
        } else return "Joueur";
    }

    public function getRankColor(string $rank): string
    {
        $config = new Config($this->getDataFolder() . "colorrank.yml", Config::YAML);
        if ($config->getNested("color.$rank", true) !== null) {
            return $config->get("color")[$rank];
        } else return "§f";
    }

    public function setRank($player, string $rank): void
    {
        self::$data->setNested($this->getPlayerName($player) . ".rank", $rank);
        self::$data->save();

        if (!($player instanceof Player)) {
            $p = $this->getServer()->getPlayerByPrefix($player);
            if ($p instanceof Player) $this->initPermission($p);
        } else $this->initPermission($player);
    }

    public function getPermission($user, bool $player)
    {
        if ($player) {
            return self::$data->get($this->getPlayerName($user))["permissions"];
        } else return self::$rank_data->get($user);
    }

    public function addPermission($user, string $perm, bool $player): void
    {
        if ($player) {
            $perms = $this->getPermission($user, true);
            $perms[] = $perm;
            self::$data->setNested($this->getPlayerName($user) . ".permissions", $perms);
            self::$data->save();

            if ($user instanceof Player) {
                $user->addAttachment($this, $perm, true);
            } else {
                $p = $this->getServer()->getInstance()->getPlayerByPrefix($user);
                if ($p instanceof Player) $p->addAttachment($this, $perm, true);
            }
        } else {
            $perms = $this->getPermission($user, false);
            $perms[] = $perm;
            self::$rank_data->set($user, $perms);
            self::$rank_data->save();

            foreach ($this->getServer()->getOnlinePlayers() as $onlinePlayer) {
                if ($this->getRank($onlinePlayer) === $user) {
                    $onlinePlayer->addAttachment($this, $perm, true);
                }
            }
        }
    }

    public function removePermission($user, string $perm, bool $player): void
    {
        if ($player) {
            $perms = $this->getPermission($user, true);
            unset($perms[array_search($perm, $perms)]);
            self::$data->setNested($this->getPlayerName($user) . ".permissions", $perms);
            self::$data->save();
        } else {
            $perms = $this->getPermission($user, false);
            unset($perms[array_search($perm, $perms)]);
            self::$rank_data->set($user, $perms);
            self::$rank_data->save();
        }
    }

    public function initPermission(Player $player): void {
        $playerPermissions = $this->getPermission($player, player: true);
        if (is_array($playerPermissions)) {
            foreach ($playerPermissions as $perm) {
                $player->addAttachment($this, $perm, true);
            }
        }

        $rankPermissions = $this->getPermission($this->getRank($player), player: false);
        if (is_array($rankPermissions)) {
            foreach ($rankPermissions as $perm) {
                $player->addAttachment($this, $perm, true);
            }
        }
    }

    public static function getPlayerName($player): string
    {
        if ($player instanceof Player) {
            return $player->getName();
        } elseif (is_string($player)) {
            return $player;
        } else {
            throw new \InvalidArgumentException("Invalid player parameter");
        }
    }
    public function existPlayer($player): bool
    {
        return self::$data->exists($this->getPlayerName($player));
    }

    public function existRank(string $rank): bool
    {
        return self::$rank_data->exists($rank);
    }

    public function createPlayer($player): void
    {
        if (!$this->existPlayer($player)) {
            self::$data->set($this->getPlayerName($player), ["rank" => "Joueur", "permissions" => ["lunarium.basic"]]);
            self::$data->save();
            return;
        }

        if (!$this->existRank($this->getRank($player))) {
            $this->setRank($player, "Joueur");
        }
    }

}


