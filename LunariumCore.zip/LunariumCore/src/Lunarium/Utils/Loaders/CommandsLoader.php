<?php

namespace Lunarium\Utils\Loaders;
use Lunarium\Command\Admin\AddPermissionCommand;
use Lunarium\Command\Admin\AddRankCommand;
use Lunarium\Command\Admin\AddXPCommand;
use Lunarium\Command\Admin\ChestDebugCommand;
use Lunarium\Command\Admin\ClearCooldownCommand;
use Lunarium\Command\Admin\EnchantCommand;
use Lunarium\Command\Admin\IdCommand;
use Lunarium\Command\Admin\IPLookupCommand;
use Lunarium\Command\Admin\ListRanksCommand;
use Lunarium\Command\Admin\MaintenanceCommand;
use Lunarium\Command\Admin\RegionByPassCommand;
use Lunarium\Command\Admin\RegionCommand;
use Lunarium\Command\Admin\RemovePermissionCommand;
use Lunarium\Command\Admin\SetRankCommand;
use Lunarium\Command\Admin\SudoCommand;
use Lunarium\Command\Admin\TPAllCommand;
use Lunarium\Command\Player\AntiTrashItemCommand;
use Lunarium\Command\Player\BackCommand;
use Lunarium\Command\Player\BlockCommand;
use Lunarium\Command\Player\BourseCommand;
use Lunarium\Command\Player\CashCommand;
use Lunarium\Command\Player\ClearLagCommand;
use Lunarium\Command\Player\CoinflipCommand;
use Lunarium\Command\Player\CraftsCommand;
use Lunarium\Command\Player\DiscordCommand;
use Lunarium\Command\Player\EnderChestCommand;
use Lunarium\Command\Player\FeedCommand;
use Lunarium\Command\Player\JobsCommand;
use Lunarium\Command\Player\KitCommand;
use Lunarium\Command\Player\ListCommand;
use Lunarium\Command\Player\LotteryCommand;
use Lunarium\Command\Player\MarketCommand;
use Lunarium\Command\Player\MessageCommand;
use Lunarium\Command\Player\NearCommand;
use Lunarium\Command\Player\NightVisionCommand;
use Lunarium\Command\Player\PingCommand;
use Lunarium\Command\Player\RenameCommand;
use Lunarium\Command\Player\RepairCommand;
use Lunarium\Command\Player\ReplyCommand;
use Lunarium\Command\Player\RTPCommand;
use Lunarium\Command\Player\SeeChunkCommand;
use Lunarium\Command\Player\ShopCommand;
use Lunarium\Command\Player\TPAcceptCommand;
use Lunarium\Command\Player\TPACommand;
use Lunarium\Command\Player\TPAhereCommand;
use Lunarium\Command\Player\TrashCommand;
use Lunarium\Command\Player\VoteCommand;
use Lunarium\Command\Player\XPBottleCommand;
use Lunarium\Command\Player\XYZCommand;
use Lunarium\Command\Staff\BanCommand;
use Lunarium\Command\Staff\EcInvSeeCommand;
use Lunarium\Command\Staff\FreezeCommand;
use Lunarium\Command\Staff\GamemodeCommand;
use Lunarium\Command\Staff\InvSeeCommand;
use Lunarium\Command\Staff\LockChatCommand;
use Lunarium\Command\Staff\StaffCommand;
use Lunarium\Command\Staff\UnbanCommand;
use Lunarium\Command\Staff\UnmuteCommand;
use Lunarium\Command\Staff\VanishCommand;
use Lunarium\Main;
use Lunarium\Command\Staff\MuteCommand;

class CommandsLoader
{

    public static function loadCommands(): void
    {
        $main = Main::getInstance();

        $commands = [
            new AddPermissionCommand($main, "addpermission", "Permet d'ajouté des permission à un joueur"),
            new AddRankCommand($main, "addrank", "Permet de créer un rôle"),
            new AddXPCommand($main, "addxp", "Permet d'ajouté de l'xp à un joueur"),
            new BanCommand($main, "ban", "Permet de bannir un joueur même hors-ligne"),
            new ClearCooldownCommand($main, "clearcooldown", "Permet de supprimé un cooldown à un joueur"),
            new EcInvSeeCommand($main, "ecinvsee", "Permet de voir l'enderchest d'un joueur"),
            new FreezeCommand($main, "freeze", "Permet de freeze un joueur"),
            new GamemodeCommand($main, "gamemode", "Permet de changer de mode de jeu", ["gm"]),
            new IdCommand($main, "id", "Permet d'avoir des infos sur un item que vous tenez en main"),
            new InvSeeCommand($main, "invsee", "Permet de voir l'inventaire d'un joueur"),
            new IPLookupCommand($main, "iplookup", "Permet d'avoir des infos sur une ip"),
            new MaintenanceCommand($main, "maintenance", "Permet de gérer le système de maintenance"),
            new MessageCommand($main, "msg", "Envoyer un message"),
            new MuteCommand($main, "mute", "Permet de rendre muet un joueur"),
            new NightVisionCommand($main, "nightvision", "Permet d'avoir l'effet de nightvision", ["nv"]),
            new RemovePermissionCommand($main, "removepermission", "Permet de retiré des permissions à un joueur"),
            new SetRankCommand($main, "setrank", "Permet d'attribuer un rôle à un joueur"),
            new StaffCommand($main, "staff", "Permet de se mettre en mode staff"),
            new SudoCommand($main, "sudo", "Permet de faire executé une commande à un joueur"),
            new TPAllCommand(),
            new UnbanCommand($main, "unban", "Permet d'unban un joueur", ["deban"]),
            new UnmuteCommand($main, "unmute", "Permet d'unmute un joueur"),
            new VanishCommand($main, "vanish", "Permet de se mettre en invisible.", ["v"]),

            new AntiTrashItemCommand(),
            new BackCommand($main, "back", "Permet de se téléporter à son dernier lieu de mort !", []),
            new BlockCommand(),
            new BourseCommand(),
            new CashCommand(),
            new ClearLagCommand(),
            new MarketCommand(),
            new CoinflipCommand(),
            new CraftsCommand(),
            new DiscordCommand($main, "discord", "Permet d'avoir le discord.", ["ds"]),
            new EnderChestCommand(),
            new FeedCommand(),
            new JobsCommand(),
            new KitCommand(),
            new ListCommand(),
            new LotteryCommand(),
            new MessageCommand($main, "message", "", ["msg"]),
            new NearCommand(),
            new PingCommand($main, "ping", "Permet d'avoir le ping d'un joueur"),
            new RenameCommand(),
            new RepairCommand($main, "repair", "Permet de réparer l'item en main", ["r"]),
            new ReplyCommand(),
            new RTPCommand(),
            new SeeChunkCommand(),
            new ShopCommand(),
            new TPAcceptCommand(),
            new TPACommand($main, "tpa", "Permet de faire une demande de téléportation sur un joueur"),
            new TPAhereCommand($main, "tpahere", "Permet de faire une demande de téléportation sur vous"),
            new TrashCommand($main, "trash", "Permet d'ouvrir la poubelle"),
            new VoteCommand($main, "vote", "Permet de voter sur le serveur"),
            new XPBottleCommand(),
            new XYZCommand(),

            new BlockCommand(),
            new ChestDebugCommand(),
            new EnchantCommand(),
            new FeedCommand(),
            new JobsCommand(),
            new ListRanksCommand(),
            new LockChatCommand(),
            new RegionByPassCommand(),
            new RegionCommand(),

        ];

        foreach ($commands as $cmd){
            $main->getServer()->getCommandMap()->register("LunariumCommand", $cmd);
        }

        $count = count($commands);
        $main->getLogger()->critical("{$count} commandes enregistrés");
    }
}
