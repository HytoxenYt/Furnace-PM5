<?php

namespace Lunarium\Utils\Loaders;

use customiesdevs\customies\item\component\CanDestroyInCreativeComponent;
use customiesdevs\customies\item\CustomiesItemFactory;
use Lunarium\LunaMod\Armor\Jade\JadeBoots;
use Lunarium\LunaMod\Armor\Jade\JadeChestplate;
use Lunarium\LunaMod\Armor\Jade\JadeHelmet;
use Lunarium\LunaMod\Armor\Jade\JadeLeggings;
use Lunarium\LunaMod\Armor\Nacre\NacreBoots;
use Lunarium\LunaMod\Armor\Nacre\NacreChestplate;
use Lunarium\LunaMod\Armor\Nacre\NacreHelmet;
use Lunarium\LunaMod\Armor\Nacre\NacreLeggings;
use Lunarium\LunaMod\Armor\Cosmetiques\Chapeau;
use Lunarium\LunaMod\Armor\Lunaire\LunaireBoots;
use Lunarium\LunaMod\Armor\Lunaire\LunaireChestplate;
use Lunarium\LunaMod\Armor\Lunaire\LunaireHelmet;
use Lunarium\LunaMod\Armor\Lunaire\LunaireLeggings;
use Lunarium\LunaMod\Blocks\Seeds\LunaireSeed;
use Lunarium\LunaMod\Item\Axe\JadeAxe;
use Lunarium\LunaMod\Item\Axe\NacreAxe;
use Lunarium\LunaMod\Item\Axe\LunaireAxe;
use Lunarium\LunaMod\Item\CustomItem;
use Lunarium\LunaMod\CustomRecipe;
use Lunarium\LunaMod\Item\Dynamite\DynamiteItem;
use Lunarium\LunaMod\Item\Food\CotonFruit;
use Lunarium\LunaMod\Item\Food\CotonSeed;
use Lunarium\LunaMod\Item\Food\LunaireApple;
use Lunarium\LunaMod\Item\Food\StrawberryFruit;
use Lunarium\LunaMod\Item\Food\StrawberrySeed;
use Lunarium\LunaMod\Item\Food\TomatoFruit;
use Lunarium\LunaMod\Item\Food\TomatoSeed;
use Lunarium\LunaMod\Item\Hammer\JadeHammer;
use Lunarium\LunaMod\Item\Hammer\LunaireHammer;
use Lunarium\LunaMod\Item\Hammer\NacreHammer;
use Lunarium\LunaMod\Item\Ingot\NacreIngot;
use Lunarium\LunaMod\Item\Ingot\JadeIngot;
use Lunarium\LunaMod\Item\Ingot\LunaireIngot;
use Lunarium\LunaMod\Item\Key\JadeKey;
use Lunarium\LunaMod\Item\Key\NacreKey;
use Lunarium\LunaMod\Item\Key\LunaireKey;
use Lunarium\LunaMod\Item\Key\VoteKey;
use Lunarium\LunaMod\Item\Lobby\Earth;
use Lunarium\LunaMod\Item\Pickaxe\JadePickaxe;
use Lunarium\LunaMod\Item\Pickaxe\NacrePickaxe;
use Lunarium\LunaMod\Item\Pickaxe\LunairePickaxe;
use Lunarium\LunaMod\Item\Powder\LunaireFragment;
use Lunarium\LunaMod\Item\Powder\LunairePowder;
use Lunarium\LunaMod\Item\Stick\HealStick;
use Lunarium\LunaMod\Item\Stick\MagicStick;
use Lunarium\LunaMod\Item\Stick\SpeedStick;
use Lunarium\LunaMod\Item\Sword\JadeSword;
use Lunarium\LunaMod\Item\Sword\NacreSword;
use Lunarium\LunaMod\Item\Sword\LunaireSword;
use Lunarium\LunaMod\Item\UnclaimFinder\UnclaimFinderVert;
use Lunarium\LunaMod\Item\UnclaimFinder\UnclaimFinderViolet;
use Lunarium\LunaMod\Item\Utility\Aimant;
use Lunarium\LunaMod\Item\Utility\Billet;
use Lunarium\LunaMod\Item\Utility\CompressedStone;
use Lunarium\LunaMod\Item\Utility\HandGlider;
use Lunarium\LunaMod\Item\Utility\MineurPotion;
use Lunarium\LunaMod\Item\Utility\Rune\ChaosRune;
use Lunarium\LunaMod\Item\Utility\Rune\InvisibilityRune;
use Lunarium\LunaMod\Item\Utility\Rune\JobsRune;
use Lunarium\LunaMod\Item\Utility\Rune\RandomRune;
use Lunarium\LunaMod\Item\Utility\Rune\TeleportationRune;
use Lunarium\LunaMod\Item\Utility\SeedPlanter;
use pocketmine\item\Item;
use pocketmine\Server;

class ItemsLoader extends Item {

    public static function loadItems(): void
    {
        CustomiesItemFactory::getInstance()->registerItem(LunaireHelmet::class, CustomItem::LUNAIRE_HELMET, "Casque Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunaireChestplate::class, CustomItem::LUNAIRE_CHESTPLATE, "Plastron Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunaireLeggings::class, CustomItem::LUNAIRE_LEGGINGS, "Jambières Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunaireBoots::class, CustomItem::LUNAIRE_BOOTS, "Bottes Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunaireSword::class, CustomItem::LUNAIRE_SWORD, "Épée Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunairePickaxe::class, CustomItem::LUNAIRE_PICKAXE, "Pioche Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunaireAxe::class, CustomItem::LUNAIRE_AXE, "Hache Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunairePowder::class, CustomItem::LUNAIRE_POWDER, "Poudre Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunaireFragment::class, CustomItem::LUNAIRE_FRAGMENT, "Fragment Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunaireIngot::class, CustomItem::LUNAIRE_INGOT, "Lingot Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(LunaireSeed::class, CustomItem::LUNAIRE_SEED, "Lunaire");


        CustomiesItemFactory::getInstance()->registerItem(JadeHelmet::class, CustomItem::JADE_HELMET, "Casque en Jade");
        CustomiesItemFactory::getInstance()->registerItem(JadeChestplate::class, CustomItem::JADE_CHESTPLATE, "Plastron en Jade");
        CustomiesItemFactory::getInstance()->registerItem(JadeLeggings::class, CustomItem::JADE_LEGGINGS, "Jambières en Jade");
        CustomiesItemFactory::getInstance()->registerItem(JadeBoots::class, CustomItem::JADE_BOOTS, "Bottes en Jade");
        CustomiesItemFactory::getInstance()->registerItem(JadeSword::class, CustomItem::JADE_SWORD, "Épée en Jade");
        CustomiesItemFactory::getInstance()->registerItem(JadePickaxe::class, CustomItem::JADE_PICKAXE, "Pioche en Jade");
        CustomiesItemFactory::getInstance()->registerItem(JadeAxe::class, CustomItem::JADE_AXE, "Hache en Jade");
        CustomiesItemFactory::getInstance()->registerItem(JadeIngot::class, CustomItem::JADE_INGOT, "Lingot en Jade");
        CustomiesItemFactory::getInstance()->registerItem(JadeHammer::class, CustomItem::JADE_HAMMER, "Hammer en Jade");
        CustomiesItemFactory::getInstance()->registerItem(NacreHammer::class, CustomItem::NACRE_HAMMER, "Hammer en Nacre");
        CustomiesItemFactory::getInstance()->registerItem(LunaireHammer::class, CustomItem::LUNAIRE_HAMMER, "Hammer en Lunaire");


        CustomiesItemFactory::getInstance()->registerItem(NacreHelmet::class, CustomItem::NACRE_HELMET, "Casque en Nacre");
        CustomiesItemFactory::getInstance()->registerItem(NacreChestplate::class, CustomItem::NACRE_CHESTPLATE, "Plastron en Nacre");
        CustomiesItemFactory::getInstance()->registerItem(NacreLeggings::class, CustomItem::NACRE_LEGGINGS, "Jambières en Nacre");
        CustomiesItemFactory::getInstance()->registerItem(NacreBoots::class, CustomItem::NACRE_BOOTS, "Bottes en Nacre");
        CustomiesItemFactory::getInstance()->registerItem(NacreSword::class, CustomItem::NACRE_SWORD, "Épée en Nacre");
        CustomiesItemFactory::getInstance()->registerItem(NacrePickaxe::class, CustomItem::NACRE_PICKAXE, "Pioche en Nacre");
        CustomiesItemFactory::getInstance()->registerItem(NacreAxe::class, CustomItem::NACRE_AXE, "Hache en Nacre");
        CustomiesItemFactory::getInstance()->registerItem(NacreIngot::class, CustomItem::NACRE_INGOT, "Lingot de Nacre");


        CustomiesItemFactory::getInstance()->registerItem(Earth::class, CustomItem::EARTH, "Serveur");
        CustomiesItemFactory::getInstance()->registerItem(HandGlider::class, CustomItem::PLANEUR, "Planeur");


        CustomiesItemFactory::getInstance()->registerItem(VoteKey::class, CustomItem::VOTE_KEY, "Clé de Vote");
        CustomiesItemFactory::getInstance()->registerItem(NacreKey::class, CustomItem::NACRE_KEY, "Clé de Nacre");
        CustomiesItemFactory::getInstance()->registerItem(JadeKey::class, CustomItem::JADE_KEY, "Clé en Jade");
        CustomiesItemFactory::getInstance()->registerItem(LunaireKey::class, CustomItem::LUNAIRE_KEY, "Clé Lunaire");


        CustomiesItemFactory::getInstance()->registerItem(HealStick::class, CustomItem::HEAL_STICK, "Stick de Heal");
        CustomiesItemFactory::getInstance()->registerItem(SpeedStick::class, CustomItem::SPEED_STICK, "Stick de Vitesse");


        CustomiesItemFactory::getInstance()->registerItem(LunaireApple::class, CustomItem::LUNAIRE_APPLE, "Pomme Lunaire");
        CustomiesItemFactory::getInstance()->registerItem(CotonSeed::class, CustomItem::COTON_CROP_SEED, "Graine de Coton");
        CustomiesItemFactory::getInstance()->registerItem(CotonFruit::class, CustomItem::COTON, "Coton");
        CustomiesItemFactory::getInstance()->registerItem(StrawberryFruit::class, CustomItem::STRAWBERRY, "Graine de Fraise");
        CustomiesItemFactory::getInstance()->registerItem(StrawberrySeed::class, CustomItem::STRAWBERRY_CROP_SEED, "Fraise");
        CustomiesItemFactory::getInstance()->registerItem(TomatoFruit::class, CustomItem::TOMATO, "Graine de Tomate");
        CustomiesItemFactory::getInstance()->registerItem(TomatoSeed::class, CustomItem::TOMATO_CROP_SEED, "Tomate");


        CustomiesItemFactory::getInstance()->registerItem(RandomRune::class, CustomItem::RANDOM_RUNE, "Rune Random");
        CustomiesItemFactory::getInstance()->registerItem(JobsRune::class, CustomItem::JOBS_RUNE, "Rune de Jobs");
        CustomiesItemFactory::getInstance()->registerItem(TeleportationRune::class, CustomItem::TELEPORTATION_RUNE, "Rune de Téléportation");
        CustomiesItemFactory::getInstance()->registerItem(InvisibilityRune::class, CustomItem::INVISIBILITY_RUNE, "Rune d'Invisibilité");
        CustomiesItemFactory::getInstance()->registerItem(ChaosRune::class, CustomItem::CHAOS_RUNE, "Rune de Chaos");


        CustomiesItemFactory::getInstance()->registerItem(DynamiteItem::class, CustomItem::DYNAMITE, "Dynamite");
        CustomiesItemFactory::getInstance()->registerItem(Billet::class, CustomItem::BILLET, "Billet");
        CustomiesItemFactory::getInstance()->registerItem(UnclaimFinderViolet::class, CustomItem::UNCLAIM_FINDER_VIOLET, "Unclaim Finder Violet");
        CustomiesItemFactory::getInstance()->registerItem(UnclaimFinderVert::class, CustomItem::UNCLAIM_FINDER_VERT, "Unclaim Finder Vert");
        CustomiesItemFactory::getInstance()->registerItem(CompressedStone::class, CustomItem::COMPRESSED_STONE, "Pierre Compressé");
        CustomiesItemFactory::getInstance()->registerItem(MineurPotion::class, CustomItem::MINEUR_POTION, "Potion de Mineur");
        CustomiesItemFactory::getInstance()->registerItem(Aimant::class, CustomItem::AIMANT, "Aimant");
        CustomiesItemFactory::getInstance()->registerItem(SeedPlanter::class, CustomItem::SEEDPLANTER, "Planteur de Graine");
        CustomiesItemFactory::getInstance()->registerItem(MagicStick::class, CustomItem::MAGIC_STICK, "Stick de Magie");

    }
}
