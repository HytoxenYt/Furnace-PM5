<?php

namespace Lunarium\Utils\Loaders;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\block\Material;
use customiesdevs\customies\block\Model;
use customiesdevs\customies\item\CreativeInventoryInfo;
use Lunarium\LunaMod\Blocks\Bois\LunaireLeaves;
use Lunarium\LunaMod\Blocks\Bois\LunairePlanks;
use Lunarium\LunaMod\Blocks\Bois\LunaireWood;
use Lunarium\LunaMod\Blocks\Chest\CustomChest;
use Lunarium\LunaMod\Blocks\Chest\Tile\CustomChestTile;
use Lunarium\LunaMod\Blocks\Chest\Tile\LunaireChestTile;
use Lunarium\LunaMod\Blocks\CustomBlockIds;
use Lunarium\LunaMod\Blocks\Minerais\NacreOre;
use Lunarium\LunaMod\Blocks\Minerais\JadeOre;
use Lunarium\LunaMod\Blocks\Minerais\LunaireOre;
use Lunarium\LunaMod\Blocks\Obsidian\LavaObsidian;
use Lunarium\LunaMod\Blocks\Seeds\CotonStage1;
use Lunarium\LunaMod\Blocks\Seeds\CotonStage2;
use Lunarium\LunaMod\Blocks\Seeds\CotonStage3;
use Lunarium\LunaMod\Blocks\Seeds\LunairePlantStage1;
use Lunarium\LunaMod\Blocks\Seeds\LunairePlantStage2;
use Lunarium\LunaMod\Blocks\Seeds\LunairePlantStage3;
use Lunarium\LunaMod\Blocks\Seeds\StrawberryStage1;
use Lunarium\LunaMod\Blocks\Seeds\StrawberryStage2;
use Lunarium\LunaMod\Blocks\Seeds\StrawberryStage3;
use Lunarium\LunaMod\Blocks\Seeds\TomatoStage1;
use Lunarium\LunaMod\Blocks\Seeds\TomatoStage2;
use Lunarium\LunaMod\Blocks\Seeds\TomatoStage3;
use Lunarium\LunaMod\Blocks\Utility\CaveBlock;
use Lunarium\LunaMod\Blocks\Utility\Cobblebreaker;
use Lunarium\LunaMod\Blocks\Utility\Drawer;
use Lunarium\LunaMod\Blocks\Utility\Elevator;
use Lunarium\LunaMod\Blocks\Utility\Livre;
use Lunarium\LunaMod\Blocks\Utility\SlimePad;
use Lunarium\LunaMod\Item\CustomItem;
use pocketmine\block\Block;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockToolType;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\block\tile\TileFactory;
use pocketmine\math\Vector3;

class BlocksLoader extends Block
{

    public static function loadBlocks(): void
    {
        $material = new Material(Material::TARGET_ALL, "livre", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.livre", new Vector3(-8, 0, -8), new Vector3(16, 3, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);
        $createRandomOre = static function () {
            return new Livre(new BlockIdentifier(CustomBlockIds::LIVRE), "livre",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::NONE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, CustomItem::LIVRE, $model, $creativeInfo);

        $material = new Material(Material::TARGET_ALL, "lunaire_chest", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.chest", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);
        $createRandomOre = static function () {
            return new CustomChest(new BlockIdentifier(CustomBlockIds::LUNAIRE_CHEST, LunaireChestTile::class), "Coffre en Lunaire",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::NONE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, CustomItem::LUNAIRE_CHEST, $model, $creativeInfo);

        $material = new Material(Material::TARGET_ALL, "drawer", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);
        $createRandomOre = static function () {
            return new Drawer(new BlockIdentifier(CustomBlockIds::DRAWER), "drawer",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::NONE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, CustomItem::DRAWER, $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "caveblock", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);
        $createRandomOre = static function () {
            return new CaveBlock(new BlockIdentifier(CustomBlockIds::CAVEBLOCK), "caveblock",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::NONE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, CustomItem::CAVEBLOCK, $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "cobblebreaker", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.cobblebreaker", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);
        $createRandomOre = static function () {
            return new Cobblebreaker(new BlockIdentifier(CustomBlockIds::COBBLEBREAKER), "cobblebreaker",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::PICKAXE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, "lunarium:cobblebreaker", $model, $creativeInfo);

        $material = new Material(Material::TARGET_ALL, "slimepad", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.slimepad", new Vector3(-8, 0, -8), new Vector3(16, 8, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createRandomOre = static function () {
            return new SlimePad(new BlockIdentifier(CustomBlockIds::SLIMEPAD), "slimepad",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::NONE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, CustomItem::SLIMEPAD, $model, $creativeInfo);

        $material = new Material(Material::TARGET_ALL, "elevator", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createRandomOre = static function () {
            return new Elevator(new BlockIdentifier(CustomBlockIds::ELEVATOR), "elevator",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::NONE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, CustomItem::ELEVATOR, $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "lava_obsidian", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createRandomOre = static function () {
            return new LavaObsidian(new BlockIdentifier(CustomBlockIds::LAVA_OBSIDIAN_ID), "lava_obsidian",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::PICKAXE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, "lunarium:lava_obsidian", $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "lunaire_leaves", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_LEAVES);
        $createRandomOre = static function () {
            return new LunaireLeaves(new BlockIdentifier(CustomBlockIds::LUNAIRE_LEAVES_ID), "lunaire_leaves",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::HOE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, "lunarium:lunaire_leaves", $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "lunaire_planks", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_PLANKS);
        $createRandomOre = static function () {
            return new LunairePlanks(new BlockIdentifier(CustomBlockIds::LUNAIRE_PLANKS_ID), "lunaire_planks",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::AXE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, "lunarium:lunaire_planks", $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "lunaire_wood", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.lunaire_wood", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_WOOD);
        $createRandomOre = static function () {
            return new LunaireWood(new BlockIdentifier(CustomBlockIds::LUNAIRE_WOOD_ID), "lunaire_wood",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::AXE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, "lunarium:lunaire_wood", $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "nacre_ore", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createAluminiumOre = static function () {
            return new NacreOre(new BlockIdentifier(CustomBlockIds::NACRE_ORE_ID), "nacre_ore",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::PICKAXE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createAluminiumOre, "lunarium:nacre_ore", $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "jade_ore", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createBronzeOre = static function () {
            return new JadeOre(new BlockIdentifier(CustomBlockIds::JADE_ORE_ID), "jade_ore",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::PICKAXE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createBronzeOre, "lunarium:jade_ore", $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "lunaire_ore", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.block", new Vector3(-8, 0, -8), new Vector3(16, 16, 16), false);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createRandomOre = static function () {
            return new LunaireOre(new BlockIdentifier(CustomBlockIds::LUNAIRE_ORE_ID), "lunaire_ore",
                new BlockTypeInfo(new BlockBreakInfo(0.5, BlockToolType::PICKAXE), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createRandomOre, "lunarium:lunaire_ore", $model, $creativeInfo);

        $material = new Material(Material::TARGET_ALL, "lunaire_plant_stage_1", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.lunaire_plant", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createFluoritePlantStage1 = static function () {
            return new LunairePlantStage1(new BlockIdentifier(CustomBlockIds::LUNAIRE_PLANT_1_ID), "lunaire_plant_stage_1",
                new BlockTypeInfo(new BlockBreakInfo(0), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createFluoritePlantStage1, "lunarium:lunaire_plant_stage_1", $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "lunaire_plant_stage_2", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.lunaire_plant", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createFluoritePlantStage2 = static function () {
            return new LunairePlantStage2(new BlockIdentifier(CustomBlockIds::LUNAIRE_PLANT_2_ID), "lunaire_plant_stage_2",
                new BlockTypeInfo(new BlockBreakInfo(0), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createFluoritePlantStage2, "lunarium:lunaire_plant_stage_2", $model, $creativeInfo);


        $material = new Material(Material::TARGET_ALL, "lunaire_plant_stage_3", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.lunaire_plant", new Vector3(-8, 0, -8), new Vector3(16, 16, 16));
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION, CreativeInventoryInfo::GROUP_ORE);
        $createFluoritePlantStage3 = static function () {
            return new LunairePlantStage3(new BlockIdentifier(CustomBlockIds::LUNAIRE_PLANT_3_ID), "lunaire_plant_stage_3",
                new BlockTypeInfo(new BlockBreakInfo(0), [], []));
        };
        CustomiesBlockFactory::getInstance()->registerBlock($createFluoritePlantStage3, "lunarium:lunaire_plant_stage_3", $model, $creativeInfo);

        $material = new Material(Material::TARGET_ALL, "coton_crop_1", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.coton_crops", new Vector3(-8, 0, -8), new Vector3(16, 8, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new CotonStage1(
                new BlockIdentifier(CustomBlockIds::COTON_STAGE_1),
                "Coton",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:coton_stage_1",
            $model, $creativeInfo
        );


        $material = new Material(Material::TARGET_ALL, "coton_crop_2", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.coton_crops", new Vector3(-8, 0, -8), new Vector3(16, 8, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new CotonStage2(
                new BlockIdentifier(CustomBlockIds::COTON_STAGE_2),
                "Coton",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:coton_stage_2",
            $model, $creativeInfo
        );

        $material = new Material(Material::TARGET_ALL, "coton_crop_3", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.coton_crops", new Vector3(-8, 0, -8), new Vector3(16, 8, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new CotonStage3(
                new BlockIdentifier(CustomBlockIds::COTON_STAGE_3),
                "Coton",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:coton_stage_3",
            $model, $creativeInfo
        );

        $material = new Material(Material::TARGET_ALL, "tomato_crop_1", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.tomato_crops", new Vector3(-8, 0, -8), new Vector3(16, 16, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new TomatoStage1(
                new BlockIdentifier(CustomBlockIds::TOMATE_STAGE_1),
                "Tomate",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:tomato_stage_1",
            $model, $creativeInfo
        );

        $material = new Material(Material::TARGET_ALL, "tomato_crop_2", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.tomato_crops", new Vector3(-8, 0, -8), new Vector3(16, 16, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new TomatoStage2(
                new BlockIdentifier(CustomBlockIds::TOMATE_STAGE_2),
                "Tomate",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:tomato_stage_2",
            $model, $creativeInfo
        );

        $material = new Material(Material::TARGET_ALL, "tomato_crop_3", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.tomato_crops", new Vector3(-8, 0, -8), new Vector3(16, 16, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new TomatoStage3(
                new BlockIdentifier(CustomBlockIds::TOMATE_STAGE_3),
                "Tomate",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:tomato_stage_3",
            $model, $creativeInfo
        );

        $material = new Material(Material::TARGET_ALL, "strawberry_crop_1", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.strawberry_crops", new Vector3(-8, 0, -8), new Vector3(16, 5, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new StrawberryStage1(
                new BlockIdentifier(CustomBlockIds::STRAWBERRY_STAGE_1),
                "Fraise",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:strawberry_stage_1",
            $model, $creativeInfo
        );

        $material = new Material(Material::TARGET_ALL, "strawberry_crop_2", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.strawberry_crops", new Vector3(-8, 0, -8), new Vector3(16, 9, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new StrawberryStage2(
                new BlockIdentifier(CustomBlockIds::STRAWBERRY_STAGE_2),
                "Fraise",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:strawberry_stage_2",
            $model, $creativeInfo
        );

        $material = new Material(Material::TARGET_ALL, "strawberry_crop_3", Material::RENDER_METHOD_ALPHA_TEST);
        $model = new Model([$material], "geometry.strawberry_crops", new Vector3(-8, 0, -8), new Vector3(16, 10, 16), true);
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_CONSTRUCTION);

        CustomiesBlockFactory::getInstance()->registerBlock(
            static fn() => new StrawberryStage3(
                new BlockIdentifier(CustomBlockIds::STRAWBERRY_STAGE_3),
                "Fraise",
                new BlockTypeInfo(new BlockBreakInfo(0))
            ),
            "lunarium:strawberry_stage_3",
            $model, $creativeInfo
        );


        TileFactory::getInstance()->register(CustomChestTile::class);
        TileFactory::getInstance()->register(LunaireChestTile::class);
    }
}
