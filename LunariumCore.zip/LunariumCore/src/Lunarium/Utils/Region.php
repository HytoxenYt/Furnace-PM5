<?php

namespace Lunarium\Utils;

use Lunarium\Managers\RegionManager;
use pocketmine\block\BlockTypeIds;
use pocketmine\math\Vector3;

class Region {
    public const
        FLAG_CAN_PLACE = "canPlace",
        FLAG_CAN_BREAK = "canBreak",
        FLAG_CAN_INTERACT = "canInteract",
        FLAG_FALL_DAMAGE = "fallDamage",
        FLAG_INVINCIBLE = "invincible",
        FLAG_PVP = "pvp",
        FLAG_REGENERATION = "regeneration",
        FLAG_EXPLOSION = "explosion",
        FLAG_PROJECTILES = "projectiles",
        FLAG_ITEM_DROP = "itemDrop",
        FLAG_ITEM_COLLECT = "itemCollect",
        FLAG_KEEP_INVENTORY = "keepInventory",
        FLAG_GAMEMODE = "gamemode",
        FLAG_NATURAL = "natural",
        FLAG_CAN_CHAT = "canChat",
        FLAG_BRIGHTNESS = "brightness",
        FLAG_ENTRY_MESSAGE = "entryMessage",
        FLAG_EXIT_MESSAGE = "exitMessage",
        FLAG_DENIED_COMMANDS = "deniedCommands";
    public const
        TYPE_BOOL = "bool",
        TYPE_INT = "int",
        TYPE_STRING = "string";
    public const FLAG_PROPERTIES = [
        self::FLAG_CAN_PLACE => ["Poser des blocs", self::TYPE_BOOL],
        self::FLAG_CAN_BREAK => ["Casser des blocs", self::TYPE_BOOL],
        self::FLAG_CAN_INTERACT => ["Interaction", self::TYPE_BOOL],
        self::FLAG_FALL_DAMAGE => ["Dégâts de chute", self::TYPE_BOOL],
        self::FLAG_INVINCIBLE => ["Invincibilité", self::TYPE_BOOL],
        self::FLAG_PVP => ["PvP", self::TYPE_BOOL],
        self::FLAG_REGENERATION => ["Régénération", self::TYPE_BOOL],
        self::FLAG_EXPLOSION => ["Explosions", self::TYPE_BOOL],
        self::FLAG_PROJECTILES => ["Projectiles", self::TYPE_BOOL],
        self::FLAG_ITEM_DROP => ["Jeter des objets au sol", self::TYPE_BOOL],
        self::FLAG_ITEM_COLLECT => ["Récupération d'objets au sol", self::TYPE_BOOL],
        self::FLAG_KEEP_INVENTORY => ["Garder l'inventaire", self::TYPE_BOOL],
        self::FLAG_GAMEMODE => ["Mode de jeu", self::TYPE_INT],
        self::FLAG_NATURAL => ["Événements naturels", self::TYPE_BOOL],
        self::FLAG_CAN_CHAT => ["Utilisation du chat", self::TYPE_BOOL],
        self::FLAG_BRIGHTNESS => ["Luminosité", self::TYPE_BOOL],
        self::FLAG_ENTRY_MESSAGE => ["Message d'entrée", self::TYPE_STRING],
        self::FLAG_EXIT_MESSAGE => ["Message de sortie", self::TYPE_STRING],
        self::FLAG_DENIED_COMMANDS => ["Commandes désactivées", self::TYPE_STRING]
    ];
    public const DEFAULT_FLAGS = [
        self::FLAG_CAN_PLACE => true,
        self::FLAG_CAN_BREAK => true,
        self::FLAG_CAN_INTERACT => true,
        self::FLAG_FALL_DAMAGE => true,
        self::FLAG_INVINCIBLE => false,
        self::FLAG_PVP => true,
        self::FLAG_REGENERATION => true,
        self::FLAG_EXPLOSION => true,
        self::FLAG_PROJECTILES => true,
        self::FLAG_ITEM_DROP => true,
        self::FLAG_ITEM_COLLECT => true,
        self::FLAG_KEEP_INVENTORY => false,
        self::FLAG_GAMEMODE => 0,
        self::FLAG_NATURAL => true,
        self::FLAG_CAN_CHAT => true,
        self::FLAG_BRIGHTNESS => false,
        self::FLAG_ENTRY_MESSAGE => "",
        self::FLAG_EXIT_MESSAGE => "",
        self::FLAG_DENIED_COMMANDS => ""
    ];
    public const INTERACT_ALLOWED = [
        BlockTypeIds::ENDER_CHEST,
        BlockTypeIds::CRAFTING_TABLE,
        BlockTypeIds::ENCHANTING_TABLE,
        BlockTypeIds::ANVIL
    ];
    private array $flags = self::DEFAULT_FLAGS;

    public function __construct(private readonly RegionManager $manager, private string $name, private int $priority, private readonly string $worldName, private ?Vector3 $pos1 = null, private ?Vector3 $pos2 = null, private bool $extendedVertically = false) {
        if (!$this->pos1 or !$this->pos2) {
            $this->pos1 = null;
            $this->pos2 = null;
        }
    }

    public function getName(): string {
        return $this->name;
    }

    public function setName(string $name): bool {
        if (!$this->manager->get($name)) {
            $this->name = $name;
            return true;
        }
        return false;
    }

    public function getPriority(): int {
        return $this->priority;
    }

    public function setPriority(int $priority): void
    {
        $this->priority = $priority;
    }

    public function getWorldName(): string {
        return $this->worldName;
    }

    public function getFlag(string $flag) {
        return $this->flags[$flag] ?? null;
    }

    public function getFlags(): ?array {
        return $this->flags;
    }

    public function setFlags(array $flags): void
    {
        $this->flags = $flags;
    }

    public function setFlag(string $flag, $value): void
    {
        if (isset($this->flags[$flag])) {
            $this->flags[$flag] = $value;
        }
    }

    public function getPos1(): ?Vector3 {
        return $this->pos1;
    }

    public function getPos2(): ?Vector3 {
        return $this->pos2;
    }

    public function setPos1(Vector3 $pos): void
    {
        $this->pos1 = $pos;
    }

    public function setPos2(Vector3 $pos): void
    {
        $this->pos2 = $pos;
    }

    public function isExtendedVertically(): bool {
        return $this->extendedVertically;
    }

    public function setExtendedVertically(bool $extendedVertically): void
    {
        $this->extendedVertically = $extendedVertically;
    }

    public function isWorldRegion(): bool {
        return !$this->pos1 and !$this->pos2;
    }

    public function getManager(): RegionManager {
        return $this->manager;
    }
}