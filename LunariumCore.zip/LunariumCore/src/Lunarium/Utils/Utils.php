<?php

namespace Lunarium\Utils;

use Lunarium\Main;
use pocketmine\block\Block;
use pocketmine\data\bedrock\EnchantmentIds;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\world\Position;
use RuntimeException;

class Utils {
    const PREFIX = "§f[§5Lunarium§f] §f";

    public static int $maxWorldMinage = 2;
    public static int $lottery = 0;
    public static array $lotteryp = [];
    public static array $regionBypass;
    public static array $regionSelection;
    public static int $lotterietime = 0;

    public static ?Region $region;
    public static Cooldown $cooldown;


    public function __construct()
    {
        self::$cooldown = new Cooldown(new Config(Main::getInstance()->getDataFolder() . "cooldown.yml", Config::YAML, []));
    }

    public static function getCooldown(): Cooldown
    {
        return self::$cooldown;
    }

    public static function getRegion(Player $player, bool $update = false): ?Region {
        if ($update) {
            $position = new Position($player->getLocation()->getFloorX(), $player->getLocation()->getFloorY(), $player->getLocation()->getFloorZ(), $player->getLocation()->getWorld());
            self::$region = Main::getInstance()->getRegionManager()->getFromPosition($position);
        }
        return self::$region ?? null;
    }

    public static function getItemInInventory(Player $player, Block|Item $item) :int{
        $count = 0;
        for ($i = 0; $i < $player->getInventory()->getSize(); $i++){
            if ($player->getInventory()->getItem($i)->getTypeId() === $item->getTypeId()) {
                $count = $count + $player->getInventory()->getItem($i)->getCount();
            }

        } return $count;
    }



    public static function bypassRegion(Player $player): bool {
        return self::$regionBypass[$player->getName()] ?? false;
    }

    public static function setRegionBypass(Player $player, bool $bypass): void
    {
        self::$regionBypass[$player->getName()] = $bypass;
    }

    public static function getRegionSelection(Player $player): ?Region {
        return self::$regionSelection[$player->getName()] ?? null;
    }


    public static function setRegionSelection(Player $player, ?Region $region): void
    {
        self::$regionSelection[$player->getName()] = $region;
    }

    public static function giveItems(Player $player, Item|array $item, bool $isArray): void
    {
        if ($isArray) {
            /** @var Item $items */
            foreach ($item as $items) {
                if ($player->getInventory()->canAddItem($items)) {
                    $player->getInventory()->addItem($items);
                } else {
                    $player->getWorld()->dropItem($player->getPosition()->asVector3(), $items);
                }
            }
        } else {
            if ($player->getInventory()->canAddItem($item)) {
                $player->getInventory()->addItem($item);
            } else {
                $player->getWorld()->dropItem($player->getPosition()->asVector3(), $item);
            }
        }
    }

    public static function ItemSerialize(Item $item) : ?string{
        if(is_null($item) || $item->getTypeId() === VanillaItems::AIR()->getTypeId()){
            return '';
        }
        $result = zlib_encode((new BigEndianNbtSerializer())->write(new TreeRoot($item->nbtSerialize())), ZLIB_ENCODING_GZIP);
        if($result === false){
            /** @noinspection PhpUnhandledExceptionInspection */
            throw new RuntimeException("Failed to serialize item " . json_encode($item, JSON_THROW_ON_ERROR));
        }

        return $result;
    }

    public static function ItemDeserialize(string $string): Item {
        if (strlen($string) % 2 !== 0) {
            throw new \InvalidArgumentException("La chaîne hexadécimale doit avoir une longueur paire");
        }

        return Item::nbtDeserialize(
            (new BigEndianNbtSerializer())->read(zlib_decode(hex2bin($string)))->mustGetCompoundTag()
        );
    }
    public static function getEnchantName(int $id): string
    {
        return match ($id) {
            EnchantmentIds::PROTECTION => "Protection",
            EnchantmentIds::FIRE_PROTECTION => "Protection contre le feu",
            EnchantmentIds::FEATHER_FALLING => "Chute amortie",
            EnchantmentIds::BLAST_PROTECTION => "Protection contre les explosions",
            EnchantmentIds::PROJECTILE_PROTECTION => "Protection contre les projectiles",
            EnchantmentIds::THORNS => "Épines",
            EnchantmentIds::RESPIRATION => "Respiration",
            EnchantmentIds::DEPTH_STRIDER => "Agilité aquatique",
            EnchantmentIds::AQUA_AFFINITY => "Affinité aquatique",
            EnchantmentIds::SHARPNESS => "Tranchant",
            EnchantmentIds::SMITE => "Châtiment",
            EnchantmentIds::BANE_OF_ARTHROPODS => "Fléau des arthropodes",
            EnchantmentIds::KNOCKBACK => "Recul",
            EnchantmentIds::FIRE_ASPECT => "Aura de feu",
            EnchantmentIds::LOOTING => "Butin",
            EnchantmentIds::EFFICIENCY => "Efficacité",
            EnchantmentIds::SILK_TOUCH => "Toucher de soie",
            EnchantmentIds::UNBREAKING => "Solidité",
            EnchantmentIds::FORTUNE => "Fortune",
            EnchantmentIds::POWER => "Puissance",
            EnchantmentIds::PUNCH => "Frappe",
            EnchantmentIds::FLAME => "Flamme",
            EnchantmentIds::INFINITY => "Infinité",
            EnchantmentIds::LUCK_OF_THE_SEA => "Chance de la mer",
            EnchantmentIds::LURE => "Appât",
            EnchantmentIds::FROST_WALKER => "Marche sur la glace",
            EnchantmentIds::MENDING => "Réparation",
            EnchantmentIds::BINDING => "Malédiction de lien",
            EnchantmentIds::VANISHING => "Malédiction de disparition",
            EnchantmentIds::IMPALING => "Empalement",
            EnchantmentIds::RIPTIDE => "Torrent",
            EnchantmentIds::LOYALTY => "Loyauté",
            EnchantmentIds::CHANNELING => "Canalisation",
            EnchantmentIds::MULTISHOT => "Tir multiple",
            EnchantmentIds::PIERCING => "Perforation",
            EnchantmentIds::QUICK_CHARGE => "Recharge rapide",
            EnchantmentIds::SOUL_SPEED => "Vitesse des âmes",
            EnchantmentIds::SWIFT_SNEAK => "Discrétion rapide",
            default => "Enchantement inconnu",
        };
    }

    public static function getItemName(Item $item): string
    {
        $name = $item->getName();
        if($item->hasCustomName()){
            $name = $item->getCustomName();
        }

        if($item->isNull()){
            $name = "Undefined";
        }

        return $name;
    }

    public static function getAuctionHouseTaxes(Player $player): int
    {
        $taxes = [
            "Joueur" => 15,
            "Cavalier" => 10,
            "Roi-Mage" => 7,
            "Ange" => 5,
            "Divin" => 2,
        ];

        $grade = Main::getInstance()->getRank($player);
        if (array_key_exists($grade, $taxes)) {
            return $taxes[$grade];
        }
        return 15;
    }

    public static function getAuctionLimit(Player $player): int
    {
        $taxes = [
            "Joueur" => 10,
            "Cavalier" => 15,
            "Roi-Mage" => 20,
            "Ange" => 25,
            "Divin" => 50,
        ];

        $grade = Main::getInstance()->getRank($player);
        if (array_key_exists($grade, $taxes)) {
            return $taxes[$grade];
        }
        return 10;
    }
}