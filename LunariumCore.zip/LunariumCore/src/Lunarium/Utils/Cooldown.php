<?php

namespace Lunarium\Utils;

use pocketmine\utils\Config;

class Cooldown {
    private Config $config;

    public function __construct(Config $config)
    {
        $this->config = $config;
    }

    public function add(string $player, string $name, float $delay): void
    {
        $player = strtolower($player);
        $name = strtolower($name);
        $cooldowns = $this->config->get("cooldowns", []);
        $cooldowns[$player][$name] = microtime(true) + $delay;
        $this->config->set("cooldowns", $cooldowns);
        $this->config->save();
    }

    public function has(string $player, string $name): bool {
        return $this->get($player, $name) !== null;
    }

    public function get(string $player, string $name): ?float {
        $player = strtolower($player);
        $name = strtolower($name);
        $cooldowns = $this->config->get("cooldowns", []);
        if (isset($cooldowns[$player][$name])) {
            $time = $cooldowns[$player][$name];
            if ($time > microtime(true)) {
                return $time - microtime(true);
            } else {
                $this->remove($player, $name); // Remove expired cooldown
            }
        }
        return null;
    }

    public function remove(string $player, string $name): void
    {
        $player = strtolower($player);
        $name = strtolower($name);
        $cooldowns = $this->config->get("cooldowns", []);
        unset($cooldowns[$player][$name]);
        $this->config->set("cooldowns", $cooldowns);
        $this->config->save();
    }

    public function getAll(): array
    {
        return $this->config->get("cooldowns", []);
    }
}
