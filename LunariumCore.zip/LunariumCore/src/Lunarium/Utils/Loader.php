<?php

namespace Lunarium\Utils;

use customiesdevs\customies\entity\CustomiesEntityFactory;
use Lunarium\Effects\CustomEffects;
use Lunarium\Entity\DynamiteEntity;
use Lunarium\Listener\BlockListener;
use Lunarium\Listener\Events\PlayerRankEv;
use Lunarium\Listener\FactionListener;
use Lunarium\Listener\InventoryListener;
use Lunarium\Listener\LogsListener;
use Lunarium\Listener\PlayerListener;
use Lunarium\Listener\RegionListener;
use Lunarium\Listener\StaffListener;
use Lunarium\LunaMod\Item\Dynamite\DynamiteItem;
use Lunarium\LunaMod\Item\Stick\MagicStick;
use Lunarium\LunaMod\Item\Utility\Aimant;
use Lunarium\Main;
use Lunarium\Managers\FactionManager;
use Lunarium\Managers\RegionManager;
use Lunarium\Managers\MoneyManager;
use Lunarium\Managers\VotePartyManager;
use Lunarium\Managers\TokenManager;
use Lunarium\Tasks\ChatEventGameTask;
use Lunarium\Tasks\SentenceTask;
use Lunarium\Tasks\PlayerTask;
use Lunarium\Utils\Loaders\BlocksLoader;
use Lunarium\Utils\Loaders\CommandsLoader;
use Lunarium\Utils\Loaders\ItemsLoader;
use pocketmine\data\bedrock\EffectIdMap;
use pocketmine\data\bedrock\EffectIds;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\Task;
use pocketmine\utils\Config;
use pocketmine\world\World;
use tedo0627\inventoryui\InventoryUI;

class Loader
{

    public static function loadBlocks(): void
    {
        BlocksLoader::loadBlocks();
    }

    public static function loadItems(): void
    {
        ItemsLoader::loadItems();
    }

    public static function loadCommands(): void
    {
        CommandsLoader::loadCommands();
    }

    public static function loadEvents(): void
    {
        $main = Main::getInstance();
        $pluginManager = $main->getServer()->getPluginManager();

        $pluginManager->registerEvents(new PlayerRankEv(), $main);
        $pluginManager->registerEvents(new BlockListener(), $main);
        $pluginManager->registerEvents(new FactionListener(), $main);
        $pluginManager->registerEvents(new InventoryListener(), $main);
        $pluginManager->registerEvents(new LogsListener(), $main);
        $pluginManager->registerEvents(new PlayerListener(), $main);
        $pluginManager->registerEvents(new StaffListener(), $main);
        $pluginManager->registerEvents(new RegionListener(), $main);
    }

    public static function loadUtils(): void
    {
        Main::getInstance()->saveResource("secure.yml");

        Utils::$cooldown = new Cooldown(new Config(Main::getInstance()->getDataFolder() . "cooldown.yml", Config::YAML, []));

        EffectIdMap::getInstance()->register(EffectIds::HEALTH_BOOST, CustomEffects::CUSTOM_HEALTH_BOOST_JADE());
        EffectIdMap::getInstance()->register(EffectIds::HEALTH_BOOST, CustomEffects::CUSTOM_HEALTH_BOOST_NACRE());
        EffectIdMap::getInstance()->register(EffectIds::HEALTH_BOOST, CustomEffects::CUSTOM_HEALTH_BOOST_LUNAIRE());

        new Utils();
        new FactionManager();
        new MoneyManager();
        new TokenManager();
        new VotePartyManager();
        Main::getInstance()->regionManager = new RegionManager(Main::getInstance());

        CustomiesEntityFactory::getInstance()->registerEntity(DynamiteEntity::class, DynamiteEntity::getNetworkTypeId(), function (World $world, CompoundTag $tag): DynamiteEntity{
            return new DynamiteEntity(EntityDataHelper::parseLocation($tag, $world), null, $tag);
        });

        Main::getInstance()->saveResource("shop.yml");
        Main::getInstance()->saveResource("job.yml");
        Main::getInstance()->saveResource("banned-word.yml");

        InventoryUI::setup(Main::getInstance());
    }

    public static function unregisterCommands(): void
    {
        $command = Main::getInstance()->getServer()->getCommandMap();

        $command->unregister($command->getCommand("gamemode"));
        $command->unregister($command->getCommand("unban"));
        $command->unregister($command->getCommand("tell"));
        $command->unregister($command->getCommand("me"));
    }

    public static function loadTasks(): void
    {
        $main = Main::getInstance()->getScheduler();

        $main->scheduleRepeatingTask(new PlayerTask(300), 20);
        $main->scheduleRepeatingTask(new SentenceTask(), 60 * 30);
        $main->scheduleRepeatingTask(new ChatEventGameTask(), (20 * 60) * 30);
        $main->scheduleRepeatingTask(new class(Main::getInstance()) extends Task {
            private $plugin;

            public function __construct(PluginBase $plugin) {
                $this->plugin = $plugin;
            }

            public function onRun(): void {
                foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
                    Aimant::onAimantEffect($player);
                }
            }
        }, 2);
    }
}
