<?php

namespace Lunarium\API;

use JsonException;
use Lunarium\Main;
use pocketmine\player\Player;
use pocketmine\player\PlayerInfo;
use pocketmine\player\XboxLivePlayerInfo;
use pocketmine\utils\Config;

class BanAPI
{

    /**
     * @return Config
     */
    public static function getConfig(): Config
    {
        return new Config(Main::getInstance()->getDataFolder() . "bans.json");
    }

    /**
     * @return array
     */
    public static function getAll(): array
    {
        $config = self::getConfig();
        $array = [];
        foreach ($config->getAll() as $id => $value) {
            if (str_contains($id, "xuid_")) {
                $array[$id] = $value;
            }
        }
        return $array;
    }

    /**
     * @throws JsonException
     */
    public static function ban(array $values, int $time): void
    {
        $config = self::getConfig();
        $config->set($values["pseudo"], [
            "time" => $time,
            "pseudo" => $values["pseudo"],
            "xuid" => $values["xuid"],
            "uuid" => $values["uuid"],
            "cid" => $values["cid"],
            "ip" => $values["ip"],
            "staff" => $values["staff"],
            "reason" => $values["reason"]
        ]);
        $config->set("xuid_" . $values["xuid"], [
            "time" => $time,
            "pseudo" => $values["pseudo"],
            "xuid" => $values["xuid"],
            "uuid" => $values["uuid"],
            "cid" => $values["cid"],
            "ip" => $values["ip"],
            "staff" => $values["staff"],
            "reason" => $values["reason"]
        ]);
        $config->set($values["uuid"], [
            "time" => $time,
            "pseudo" => $values["pseudo"],
            "xuid" => $values["xuid"],
            "uuid" => $values["uuid"],
            "cid" => $values["cid"],
            "ip" => $values["ip"],
            "staff" => $values["staff"],
            "reason" => $values["reason"]
        ]);
        $config->set($values["cid"], [
            "time" => $time,
            "pseudo" => $values["pseudo"],
            "xuid" => $values["xuid"],
            "uuid" => $values["uuid"],
            "cid" => $values["cid"],
            "ip" => $values["ip"],
            "staff" => $values["staff"],
            "reason" => $values["reason"]
        ]);
        $config->set($values["ip"], [
            "time" => $time,
            "pseudo" => $values["pseudo"],
            "xuid" => $values["xuid"],
            "uuid" => $values["uuid"],
            "cid" => $values["cid"],
            "ip" => $values["ip"],
            "staff" => $values["staff"],
            "reason" => $values["reason"]
        ]);
        $config->save();
    }

    /**
     * @throws JsonException
     */
    public static function unban(XboxLivePlayerInfo $playerInfo, string $ip): void
    {
        $config = self::getConfig();
        if ($config->exists("xuid_" . $playerInfo->getXuid())) {
            $config->remove("xuid_" . $playerInfo->getXuid());
            if ($config->exists($playerInfo->getUsername())) $config->remove($playerInfo->getUsername());
            if ($config->exists($playerInfo->getUuid()->toString())) $config->remove($playerInfo->getUuid()->toString());
            if ($config->exists($playerInfo->getExtraData()["ClientRandomId"])) $config->remove($playerInfo->getExtraData()["ClientRandomId"]);
            if ($config->exists($ip)) $config->remove($ip);
            $config->save();
        } elseif ($config->exists($playerInfo->getUsername())) {
            $config->remove($playerInfo->getUsername());
            if ($config->exists("xuid_" . $playerInfo->getXuid())) $config->remove("xuid_" . $playerInfo->getXuid());
            if ($config->exists($playerInfo->getUuid()->toString())) $config->remove($playerInfo->getUuid()->toString());
            if ($config->exists($playerInfo->getExtraData()["ClientRandomId"])) $config->remove($playerInfo->getExtraData()["ClientRandomId"]);
            if ($config->exists($ip)) $config->remove($ip);
            $config->save();
        } elseif ($config->exists($playerInfo->getUuid()->toString())) {
            $config->remove($playerInfo->getUuid()->toString());
            if ($config->exists($playerInfo->getUsername())) $config->remove($playerInfo->getUsername());
            if ($config->exists("xuid_" . $playerInfo->getXuid())) $config->remove("xuid_" . $playerInfo->getXuid());
            if ($config->exists($playerInfo->getExtraData()["ClientRandomId"])) $config->remove($playerInfo->getExtraData()["ClientRandomId"]);
            if ($config->exists($ip)) $config->remove($ip);
            $config->save();
        } elseif ($config->exists($playerInfo->getExtraData()["ClientRandomId"])) {
            $config->remove($playerInfo->getExtraData()["ClientRandomId"]);
            if ($config->exists($playerInfo->getUsername())) $config->remove($playerInfo->getUsername());
            if ($config->exists($playerInfo->getUuid()->toString())) $config->remove($playerInfo->getUuid()->toString());
            if ($config->exists("xuid_" . $playerInfo->getXuid())) $config->remove("xuid_" . $playerInfo->getXuid());
            if ($config->exists($ip)) $config->remove($ip);
            $config->save();
        } elseif ($config->exists($ip)) {
            $config->remove($ip);
            if ($config->exists($playerInfo->getUsername())) $config->remove($playerInfo->getUsername());
            if ($config->exists($playerInfo->getUuid()->toString())) $config->remove($playerInfo->getUuid()->toString());
            if ($config->exists("xuid_" . $playerInfo->getXuid())) $config->remove("xuid_" . $playerInfo->getXuid());
            $config->save();
        }
    }

    /**
     * @param string $blase
     * @return void
     * @throws JsonException
     */
    public static function unbanByBlase(string $blase): void
    {
        $config = self::getConfig();
        $minecraftString = $blase;
        $blase = str_replace("§r", "", $minecraftString);
        if ($config->exists($blase)) {
            $config->remove($blase);
            $config->save();
        }
    }

    /**
     * @param string $xuid
     * @return void
     * @throws JsonException
     */
    public static function unbanByXuid(string $xuid): void
    {
        $config = self::getConfig();
        if ($config->exists($xuid)) {
            $config->remove($xuid);
            $infos = Main::getInstance()->getSecure()->get(str_replace("xuid_", "", $xuid));
            if (isset($infos["uuid"])) {
                if ($config->exists($infos["uuid"])) $config->remove($infos["uuid"]);
            }
            if (isset($infos["cid"])) {
                if ($config->exists($infos["cid"])) $config->remove($infos["cid"]);
            }
            if (isset($infos["pseudo"])) {
                if ($config->exists($infos["pseudo"])) $config->remove($infos["pseudo"]);
            }
            if (isset($infos["ip"])) {
                if ($config->exists($infos["ip"])) $config->remove($infos["ip"]);
            }
            $config->save();
        }
    }

    /**
     * @param XboxLivePlayerInfo $playerInfo
     * @param string $ip
     * @return bool
     */
    public static function isBanned(XboxLivePlayerInfo $playerInfo, string $ip): bool
    {
        $config = self::getConfig();
        if ($config->exists("xuid_" . $playerInfo->getXuid())) {
            return true;
        } elseif ($config->exists($playerInfo->getUsername())) {
            return true;
        } elseif ($config->exists($playerInfo->getUuid()->toString())) {
            return true;
        } elseif ($config->exists($playerInfo->getExtraData()["ClientRandomId"])) {
            return true;
        } elseif ($config->exists($ip)) {
            return true;
        }
        return false;
    }

    /**
     * @param XboxLivePlayerInfo $playerInfo
     * @param string $ip
     * @return array|null
     */
    public static function getInfos(XboxLivePlayerInfo $playerInfo, string $ip): null|array
    {
        $config = self::getConfig();
        if ($config->exists("xuid_" . $playerInfo->getXuid())) {
            return $config->get("xuid_" . $playerInfo->getXuid());
        } elseif ($config->exists($playerInfo->getUsername())) {
            return $config->get($playerInfo->getUsername());
        } elseif ($config->exists($playerInfo->getUuid()->toString())) {
            return $config->get($playerInfo->getUuid()->toString());
        } elseif ($config->exists($playerInfo->getExtraData()["ClientRandomId"])) {
            return $config->get($playerInfo->getExtraData()["ClientRandomId"]);
        } elseif ($config->exists($ip)) {
            return $config->get($ip);
        }
        return null;
    }

}