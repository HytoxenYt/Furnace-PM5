<?php

namespace Lunarium\API;

use JsonException;
use Lunarium\Main;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class MuteAPI {

    public static function getConfig(): Config{
        return new Config(Main::getInstance()->getDataFolder() . "mutes.json");
    }

    public static function getAll(): array{
        return self::getConfig()->getAll();
    }

    public static function isMuted(Player $player): bool{
        return self::getConfig()->exists($player->getXuid());
    }

    /**
     * @throws JsonException
     */
    public static function mute(array $values, int $time): void{
        $config = self::getConfig();
        $config->set($values["xuid"], [
            "time" => $time,
            "pseudo" => $values["pseudo"],
            "xuid" => $values["xuid"],
            "staff" => $values["staff"],
            "reason" => $values["reason"]
        ]);
        $config->save();
    }

    /**
     * @throws JsonException
     */
    public static function unmute(string $xuid): void{
        if (self::getConfig()->exists($xuid)){
            $config = self::getConfig();
            $config->remove($xuid);
            $config->save();
        }
    }

    public static function getTimeLeft(string $xuid): int{
        return self::getConfig()->get($xuid)["time"];
    }

    public static function getStaff(string $xuid): string{
        return self::getConfig()->get($xuid)["staff"];
    }

    public static function getReason(string $xuid): string{
        return self::getConfig()->get($xuid)["reason"];
    }

}