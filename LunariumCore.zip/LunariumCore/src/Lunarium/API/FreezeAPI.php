<?php

namespace Lunarium\API;

use pocketmine\player\Player;

class FreezeAPI {

    private static array $frozen = [];

    /**
     * @param Player $player
     * @return void
     */
    public static function setFrozen(Player $player): void{
        self::$frozen[$player->getName()] = $player->getName();
        $player->setNoClientPredictions();
        $player->sendMessage("§5[Lunarium] §d Vous venez d'être freeze par un staff.");
    }

    /**
     * @param Player $player
     * @return void
     */
    public static function setUnfrozen(Player $player): void{
        unset(self::$frozen[$player->getName()]);
        $player->setNoClientPredictions(false);
        $player->sendMessage("§5[Lunarium] §d Vous n'êtes plus freeze.");
    }

    /**
     * @param Player $player
     * @return bool
     */
    public static function isFrozen(Player $player): bool{
        return isset(self::$frozen[$player->getName()]);
    }

}