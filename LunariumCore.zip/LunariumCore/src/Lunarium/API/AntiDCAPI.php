<?php

namespace Lunarium\API;

use Lunarium\Main;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class AntiDCAPI {

    public static function getConfig(): Config{
        return new Config(Main::getInstance()->getDataFolder() . "dc.json");
    }

    /**
     * @throws \JsonException
     */
    public static function verify(Player $player): void{
        $config = self::getConfig();
        $actus_ip = [];
        if ($config->exists($player->getName())){
            $actus_ip = $config->get($player->getName());
        }
        $actus_ip[$player->getNetworkSession()->getIp()] = $player->getNetworkSession()->getIp();
        $config->set($player->getName(), $actus_ip);
        $actus = [];
        if ($config->exists($player->getNetworkSession()->getIp())){
            $actus = $config->get($player->getNetworkSession()->getIp());
        }
        $actus[$player->getName()] = $player->getName();
        $config->set($player->getNetworkSession()->getIp(), $actus);
        $config->save();
    }

    /**
     * @param Player $player
     * @return array
     */
    public static function getByIp(Player $player): array{
        return self::getConfig()->get($player->getNetworkSession()->getIp());
    }

    /**
     * @param Player $player
     * @return array
     */
    public static function getByName(Player $player): array{
        return self::getConfig()->get($player->getName());
    }

}