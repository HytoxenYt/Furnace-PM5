<?php

namespace Lunarium\API;

use CortexPE\DiscordWebhookAPI\Embed;
use CortexPE\DiscordWebhookAPI\Message;
use CortexPE\DiscordWebhookAPI\Webhook;
use Lunarium\Main;

class WebhookAPI {

    /**
     * @param string $msg
     * @return void
     */
    public static function sendBanMessage(string $msg){
        $webhook = new Webhook(Main::getInstance()->getConfig()->get("webhook-url"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("Sanction - Bannissement");
        $embed->setColor(0xFF0000);
        $embed->setDescription($msg);
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    /**
     * @param string $msg
     * @return void
     */
    public static function sendMuteMessage(string $msg){
        $webhook = new Webhook(Main::getInstance()->getConfig()->get("webhook-url"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("Sanction - Mute");
        $embed->setColor(0x808080);
        $embed->setDescription($msg);
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    /**
     * @param string $msg
     * @return void
     */
    public static function sendKickMessage(string $msg){
        $webhook = new Webhook(Main::getInstance()->getConfig()->get("webhook-url"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("Sanction - Kick");
        $embed->setColor(0xFFD700);
        $embed->setDescription($msg);
        $message->addEmbed($embed);
        $webhook->send($message);
    }

}