<?php

namespace Lunarium\API;

use DaPigGuy\PiggyFactions\factions\Faction;
use DaPigGuy\PiggyFactions\flags\Flag;
use DaPigGuy\PiggyFactions\PiggyFactions;
use DaPigGuy\PiggyFactions\utils\RoundValue;
use onebone\economyapi\EconomyAPI;

class LeaderboardAPI
{

    public static function getFactionTop(): string
    {
        $types = [
            "power" => function (Faction $a, Faction $b): int {
                return (int)($b->getPower() - $a->getPower());
            }
        ];

        $plugin = PiggyFactions::getInstance();
        if (!$plugin->isEnabled()) {
            return "";
        }

        $factionsManager = $plugin->getFactionsManager();
        if ($factionsManager === null) {
            return "";
        }

        $factions = array_filter($factionsManager->getFactions(), function (Faction $faction): bool {
            return !$faction->getFlag(Flag::SAFEZONE) && !$faction->getFlag(Flag::WARZONE);
        });
        usort($factions, $types["power"]);

        $topFactions = array_slice($factions, 0, 10); // Récupère les 10 premières factions

        $leaderboard = "§f=== §6Top Faction §f=== \n";
        foreach ($topFactions as $rank => $faction) {
            $leaderboard .= '§6' . ($rank + 1) . "§f- §6" . $faction->getName() . "§f - §6Power: " . RoundValue::round($faction->getPower()) . "\n";
        }

        return $leaderboard;
    }

}