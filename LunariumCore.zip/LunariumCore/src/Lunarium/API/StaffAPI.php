<?php

namespace Lunarium\API;

use Lunarium\Utils\Utils;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\Server;

class StaffAPI
{

    public static array $staff = [];
    public static array $inv = [];
    public static array $armor = [];

    /**
     * @param Player $player
     * @return void
     */
    public static function setStaff(Player $player): void
    {
        if (!self::isStaff($player)) {
            $player->setGamemode(GameMode::CREATIVE);
            self::$armor[$player->getName()] = $player->getArmorInventory()->getContents();
            self::$inv[$player->getName()] = $player->getInventory()->getContents();
            self::$staff[$player->getName()] = $player->getName();
            $player->getArmorInventory()->clearAll();
            $player->getInventory()->clearAll();
            for ($i = 0; $i < 36; $i++) {
                $player->getInventory()->setItem($i, VanillaBlocks::BARRIER()->asItem()->setCustomName("§r§c--"));
            }
            $player->getInventory()->setItem(1, VanillaBlocks::FROSTED_ICE()->asItem()->setCustomName("§r§bFreeze/Unfreeze"));
            $player->getInventory()->setItem(3, VanillaItems::DIAMOND()->setCustomName("§r§aTP Aléatoire"));
            $player->getInventory()->setItem(5, VanillaItems::BLAZE_ROD()->setCustomName("§r§cSanctions"));
            $player->getInventory()->setItem(7, VanillaItems::REDSTONE_DUST()->setCustomName("§rVanish: §cOFF"));
            foreach (Server::getInstance()->getOnlinePlayers() as $ply) {
                $ply->hidePlayer($player);
            }
            $player->sendMessage(Utils::PREFIX . "Vous êtes désormais en staffmode");
        }
    }

    /**
     * @param Player $player
     * @return void
     */
    public static function removeStaff(Player $player): void
    {
        if (self::isStaff($player)) {
            $player->setGamemode(GameMode::SURVIVAL());
            $player->getInventory()->clearAll();
            $player->getArmorInventory()->clearAll();
            $player->getInventory()->setContents(self::$inv[$player->getName()]);
            $player->getArmorInventory()->setContents(self::$armor[$player->getName()]);
            unset(self::$staff[$player->getName()]);
            unset(self::$inv[$player->getName()]);
            unset(self::$armor[$player->getName()]);
            foreach (Server::getInstance()->getOnlinePlayers() as $ply) {
                $ply->showPlayer($player);
            }
            $player->sendMessage(Utils::PREFIX . "Vous n'êtes plus en staffmode");
        }
    }

    /**
     * @param Player $player
     * @return bool
     */
    public static function isStaff(Player $player): bool
    {
        return isset(self::$staff[$player->getName()]);
    }
}