<?php

namespace Lunarium\Managers;

use CortexPE\DiscordWebhookAPI\Embed;
use CortexPE\DiscordWebhookAPI\Message;
use CortexPE\DiscordWebhookAPI\Webhook;

class DiscordManager
{
    public static function sendMessage(string $message, string $webhook): void
    {
        $web = new Webhook($webhook);
        $mes = new Message();

        $mes->setContent($message);
        $mes->setAvatarURL("https://media.discordapp.net/attachments/1327985440569032774/1330472591260909578/92a5e288a6736dbd10ae9bfc2ea5147d.webp?ex=678e1aa8&is=678cc928&hm=e0e6986a28e196b4675f3df470c3f6f673bb0005659647574e2b950b378d8b4b&=&format=webp&width=140&height=140");

        $web->send($mes);
    }

    public static function sendEmbed(string $message, string $webhook): void
    {
        $web = new Webhook($webhook);
        $mes = new Message();
        $embed = new Embed();

        $embed->setColor(800080);

        $embed->setAuthor("LunariumMcbe");
        $embed->setDescription($message);
        $dateTime = new \DateTime('now');
        $formattedDate = $dateTime->format('d F Y à H:i:s');

        $embed->setFooter("Le $formattedDate");
        $mes->addEmbed($embed);

        $web->send($mes);
    }
}