<?php

namespace Lunarium\Managers;

use Lunarium\Main;
use pocketmine\utils\Config;

class SanctionManager {

    public function InsertBan($name, $value): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Ban.json", Config::JSON);
        $config->set($name, $value);
        $config->save();
    }

    public function isBanned($name): bool
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Ban.json", Config::JSON);
        return $config->exists($name);
    }

    public function DeleteBan($name): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Ban.json", Config::JSON);
        $config->remove($name);
        $config->save();
    }

    public function GetBan($name) {
        $config = new Config(Main::getInstance()->getDataFolder() . "Ban.json", Config::JSON);
        return $config->get($name);
    }

    public function InsertBanIP($ip, $name): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "BanIP.json", Config::JSON);
        $config->set($name, $ip);
        $config->save();
    }

    public function isBannedIP($name): bool
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "BanIP.json", Config::JSON);
        return $config->exists($name);
    }

    public function DeleteBanIP($name): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "BanIP.json", Config::JSON);
        $config->remove($name);
        $config->save();
    }

    public function GetBanIP($name) {
        $config = new Config(Main::getInstance()->getDataFolder() . "BanIP.json", Config::JSON);
        return $config->get($name);
    }

    public function InsertMute($name, $value): void
    {
        $name = strtolower($name);
        $config = new Config(Main::getInstance()->getDataFolder() . "Mute.json", Config::JSON);
        $config->set($name, $value);
        $config->save();
    }

    public function isMuted($name): bool
    {
        $name = strtolower($name);
        $config = new Config(Main::getInstance()->getDataFolder() . "Mute.json", Config::JSON);
        return $config->exists($name);
    }

    public function DeleteMute($name): void
    {
        $name = strtolower($name);
        $config = new Config(Main::getInstance()->getDataFolder() . "Mute.json", Config::JSON);
        $config->remove($name);
        $config->save();
    }

    public function GetMute($name) {
        $name = strtolower($name);
        $config = new Config(Main::getInstance()->getDataFolder() . "Mute.json", Config::JSON);
        return $config->get($name);
    }


    public function getAllBans(): array
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Ban.json", Config::JSON);
        return $config->getAll();
    }

    public function getAllMutes(): array
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Mute.json", Config::JSON);
        return $config->getAll();
    }
}