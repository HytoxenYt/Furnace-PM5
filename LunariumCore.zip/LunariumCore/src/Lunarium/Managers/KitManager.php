<?php

namespace Lunarium\Managers;

use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class KitManager{

    public function __construct()
    {
        $kitsPath = Main::getInstance()->getDataFolder() . "Kits/";
        if (!is_dir($kitsPath)) {
            mkdir($kitsPath, 0755, true);
        }

    }

    public static function giveKitJoueur(Player $player): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Kits/kit_joueur.yml", Config::YAML);
        $time = $config->get("{$player->getName()}");

        if($time - time() <= 0 || !$time){
            $array = [
                VanillaItems::IRON_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 1)),
                VanillaItems::IRON_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 1)),
                VanillaItems::IRON_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 1)),
                VanillaItems::IRON_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 1)),
                VanillaItems::IRON_SWORD(),
                VanillaItems::IRON_PICKAXE(),
                VanillaItems::IRON_AXE(),
                VanillaItems::IRON_SHOVEL(),
                VanillaItems::IRON_HOE(),
                VanillaItems::GOLDEN_APPLE()->setCount(6)
            ];

            Utils::giveItems($player, $array,true);

            $config->set("{$player->getName()}", time() + 300);
            $config->save();

            $player->sendMessage(Utils::PREFIX . "§fVous avez reçu votre kit §9Joueur");
        }else{
            $timeRestant = $time - time();
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre ". Main::getInstance()->intToTime($timeRestant, "§c"));
        }
    }

    public static function giveKitYoutubeur(Player $player): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Kits/kit_youtubeur.yml", Config::YAML);
        $time = $config->get("{$player->getName()}");

        if($time - time() <= 0 || !$time){
            $array = [
                VanillaItems::DIAMOND_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3)),
                VanillaItems::DIAMOND_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3)),
                VanillaItems::DIAMOND_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3)),
                VanillaItems::DIAMOND_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3)),
                VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 1)),
                VanillaItems::DIAMOND_PICKAXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 1)),
                VanillaItems::DIAMOND_AXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 1)),
                VanillaItems::DIAMOND_SHOVEL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 1)),
                VanillaItems::DIAMOND_HOE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::GOLDEN_APPLE()->setCount(18)
            ];

            Utils::giveItems($player, $array,true);

            $config->set("{$player->getName()}", time() + 86400);
            $config->save();

            $player->sendMessage(Utils::PREFIX . "§fVous avez reçu votre kit §9Youtubeur");

        }else{
            $timeRestant = $time - time();
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre ". Main::getInstance()->intToTime($timeRestant, "§c"));
        }
    }

    public static function giveKitStreameur(Player $player): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Kits/kit_streameur.yml", Config::YAML);
        $time = $config->get("{$player->getName()}");

        if($time - time() <= 0 || !$time){
            $array = [
                VanillaItems::DIAMOND_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3)),
                VanillaItems::DIAMOND_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3)),
                VanillaItems::DIAMOND_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3)),
                VanillaItems::DIAMOND_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3)),
                VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 1)),
                VanillaItems::DIAMOND_PICKAXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 1)),
                VanillaItems::DIAMOND_AXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 1)),
                VanillaItems::DIAMOND_SHOVEL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 1)),
                VanillaItems::DIAMOND_HOE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::GOLDEN_APPLE()->setCount(18)
            ];

            Utils::giveItems($player, $array,true);

            $config->set("{$player->getName()}", time() + 86400);
            $config->save();

            $player->sendMessage(Utils::PREFIX . "§fVous avez reçu votre kit §9Streameur");

        }else{
            $timeRestant = $time - time();
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre ". Main::getInstance()->intToTime($timeRestant, "§c"));
        }
    }

    public static function giveKitCavalier(Player $player): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Kits/kit_cavalier.yml", Config::YAML);
        $time = $config->get("{$player->getName()}");

        if($time - time() <= 0 || !$time){
            $array = [
                VanillaItems::DIAMOND_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4)),
                VanillaItems::DIAMOND_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4)),
                VanillaItems::DIAMOND_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4)),
                VanillaItems::DIAMOND_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4)),
                VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 2)),
                VanillaItems::DIAMOND_PICKAXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 2)),
                VanillaItems::DIAMOND_AXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 2)),
                VanillaItems::DIAMOND_SHOVEL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 2)),
                VanillaItems::DIAMOND_HOE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::GOLDEN_APPLE()->setCount(32)
            ];

            Utils::giveItems($player, $array,true);

            $config->set("{$player->getName()}", time() + 86400);
            $config->save();

            $player->sendMessage(Utils::PREFIX . "§fVous avez reçu votre kit §9Cavalier");

        }else{
            $timeRestant = $time - time();
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre ". Main::getInstance()->intToTime($timeRestant, "§c"));
        }
    }

    public static function giveKitRoiMage(Player $player): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Kits/kit_roi-mage.yml", Config::YAML);
        $time = $config->get("{$player->getName()}");

        if($time - time() <= 0 || !$time){
            $array = [
                VanillaItems::DIAMOND_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 3)),
                VanillaItems::DIAMOND_PICKAXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 3)),
                VanillaItems::DIAMOND_AXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 3)),
                VanillaItems::DIAMOND_SHOVEL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 3)),
                VanillaItems::DIAMOND_HOE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::GOLDEN_APPLE()->setCount(42)
            ];

            Utils::giveItems($player, $array,true);

            $config->set("{$player->getName()}", time() + 86400);
            $config->save();

            $player->sendMessage(Utils::PREFIX . "§fVous avez reçu votre kit §9Roi-Mage");

        }else{
            $timeRestant = $time - time();
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre ". Main::getInstance()->intToTime($timeRestant, "§c"));
        }
    }

    public static function giveKitAnge(Player $player): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Kits/kit_ange.yml", Config::YAML);
        $time = $config->get("{$player->getName()}");

        if($time - time() <= 0 || !$time){
            $array = [
                VanillaItems::DIAMOND_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 4)),
                VanillaItems::DIAMOND_PICKAXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 4)),
                VanillaItems::DIAMOND_AXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 4)),
                VanillaItems::DIAMOND_SHOVEL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 4)),
                VanillaItems::DIAMOND_HOE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::GOLDEN_APPLE()->setCount(52)
            ];


            Utils::giveItems($player, $array,true);

            $config->set("{$player->getName()}", time() + 86400);
            $config->save();

            $player->sendMessage(Utils::PREFIX . "§fVous avez reçu votre kit §9Ange");

        }else{
            $timeRestant = $time - time();
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre ". Main::getInstance()->intToTime($timeRestant, "§c"));
        }
    }

    public static function giveKitLunaire(Player $player): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "Kits/kit_lunaire.yml", Config::YAML);
        $time = $config->get("{$player->getName()}");

        if($time - time() <= 0 || !$time){
            $array = [
                VanillaItems::DIAMOND_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 5)),
                VanillaItems::DIAMOND_PICKAXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5)),
                VanillaItems::DIAMOND_AXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5)),
                VanillaItems::DIAMOND_SHOVEL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5)),
                VanillaItems::DIAMOND_HOE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3)),
                VanillaItems::GOLDEN_APPLE()->setCount(64)
            ];


            Utils::giveItems($player, $array,true);

            $config->set("{$player->getName()}", time() + 86400);
            $config->save();

            $player->sendMessage(Utils::PREFIX . "§fVous avez reçu votre kit §9Lunaire");

        }else{
            $timeRestant = $time - time();
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre ". Main::getInstance()->intToTime($timeRestant, "§c"));
        }
    }

}
