<?php

namespace Lunarium\Managers;

use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\Server;
use pocketmine\utils\Config;

class VotePartyManager
{
    public static Config $config;
    public function __construct()
    {
        self::$config = new Config(Main::getInstance()->getDataFolder() . "voteparty.yml", Config::YAML);
    
        if(!self::$config->exists("total")){
            self::$config->set("total", 0);
        }
    }

    public static function addVoteParty(int $vote = 1): void
    {
        self::$config->set(self::$config->get("total") + $vote);

        $voteCount = self::getVoteParty();
        if ($voteCount >= 50) {
            self::resetVoteParty();
            foreach (Server::getInstance()->getOnlinePlayers() as $player) {
                $player->sendMessage(Utils::PREFIX . "Le VoteParty est terminé, vous gagnez tous §d100000$ §fet des §dClés");
                MoneyManager::addMoney($player, 100000);
                //todo keys
            }
        }
    }

    public static function getVoteParty(): int
    {
        return self::$config->get("total");
    }

    public static function resetVoteParty(): void
    {
        self::$config->set("total", 0);
    }
}
