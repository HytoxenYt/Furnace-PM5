<?php

namespace Lunarium\Managers;

use Lunarium\Main;
use pocketmine\event\Listener;
use pocketmine\utils\Config;

class DrawerManager implements Listener{

    public static function addDrawer($x, $y, $z)
    {
        $config = new Config(Main::getInstance()->getDataFolder()."blocks/drawer.json", Config::JSON);
        $config->set("drawer-{$x}.{$y}.{$z}", ["name" => "None", "id" => 0, "count" => 0, "use" => "false"]);
        $config->save();
    }

    public static function removeDrawer($x, $y, $z)
    {
        $config = new Config(Main::getInstance()->getDataFolder()."blocks/drawer.json", Config::JSON);
        $config->remove("drawer-{$x}.{$y}.{$z}");
        $config->save();
    }

    public static function getCount($x, $y, $z): int
    {
        $config = new Config(Main::getInstance()->getDataFolder()."blocks/drawer.json", Config::JSON);
        return $config->get("drawer-{$x}.{$y}.{$z}")['count'];
    }

    public static function setItem($x, $y, $z, $name, $id)
    {
        $config = new Config(Main::getInstance()->getDataFolder()."blocks/drawer.json", Config::JSON);
        $count = $config->get("drawer-{$x}.{$y}.{$z}")['count'] + 1;
        $use = $config->get("drawer-{$x}.{$y}.{$z}")['use'];
        $config->set("drawer-{$x}.{$y}.{$z}", ["name" => "{$name}", "id" => $id, "count" => $count, "use" => $use]);
        $config->save();
    }

    public static function isUsed($x, $y, $z) : bool
    {
        $config = new Config(Main::getInstance()->getDataFolder()."blocks/drawer.json", Config::JSON);
        $use = $config->get("drawer-{$x}.{$y}.{$z}")['use'];
        if ($use === "true") return true;
        else return false;
    }

    public static function setUsed($x, $y, $z, bool $bool)
    {
        $config = new Config(Main::getInstance()->getDataFolder()."blocks/drawer.json", Config::JSON);
        $count = $config->get("drawer-{$x}.{$y}.{$z}")['count'];
        $name = $config->get("drawer-{$x}.{$y}.{$z}")['name'];
        $id = $config->get("drawer-{$x}.{$y}.{$z}")['id'];

        if ($bool === true ) $config->set("drawer-{$x}.{$y}.{$z}", ["name" => "{$name}", "id" => $id, "count" => $count, "use" => "true"]);
        else $config->set("drawer-{$x}.{$y}.{$z}", ["name" => "{$name}", "id" => $id, "count" => $count, "use" => "false"]);
    }



    public static function removeItem($x, $y, $z, $amount)
    {
        $config = new Config(Main::getInstance()->getDataFolder()."blocks/drawer.json", Config::JSON);
        $count = $config->get("drawer-{$x}.{$y}.{$z}")['count'] - $amount;
        $name = $config->get("drawer-{$x}.{$y}.{$z}")['name'];
        $id = $config->get("drawer-{$x}.{$y}.{$z}")['id'];
        $use = $config->get("drawer-{$x}.{$y}.{$z}")['use'];


        $config->set("drawer-{$x}.{$y}.{$z}", ["name" => "{$name}", "id" => $id, "count" => $count, "use" => $use]);
        $config->save();
    }
}