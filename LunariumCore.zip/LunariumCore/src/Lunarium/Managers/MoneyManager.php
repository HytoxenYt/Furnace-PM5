<?php

namespace Lunarium\Managers;

use Lunarium\Main;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class MoneyManager{

    public static Config $money;

    public function __construct()
    {
        self::$money = new Config(Main::getInstance()->getDataFolder() . "money.yml", Config::YAML);
    }

    public static function createPlayer($player):void
    {
        if(!self::existsMoney(self::getPlayerName($player))){
            self::$money->set(self::getPlayerName($player), 1000);
            self::$money->save();
        }
    }

    public static function existsMoney($player): bool
    {
        return self::$money->exists(self::getPlayerName($player));
    }

    public static function addMoney($player, int|float $money): void
    {
        self::setMoney($player, self::getMoneyPlayer($player) + $money);
    }

    public static function removeMoney($player, int|float $money): void
    {
        self::setMoney($player, self::getMoneyPlayer($player) - $money);
    }

    public static function setMoney($player, int|float $money): void
    {
        self::$money->set(self::getPlayerName($player), $money);
        self::$money->save();
    }

    public static function getMoneyPlayer($player): int|float
    {
        return self::$money->get(self::getPlayerName($player));
    }
    public static function getPlayerName($player): string
    {
        if ($player instanceof Player) return $player->getName(); else return $player;
    }
}