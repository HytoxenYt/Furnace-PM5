<?php

namespace Lunarium\Managers;

use JsonException;
use Lunarium\Main;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class JobsManager
{
    public static Config $data;

    const MINEUR = "Mineur";
    const ASSASSIN = "Assassin";
    const BUCHERON = "Bucheron";
    const FERMIER = "Fermier";
    public function __construct()
    {
        self::$data = new Config(Main::getInstance()->getDataFolder() . "jobs_data.yml", Config::YAML);
    }

    public static function getLevel(Player $player, string $job): int
    {
        $dataFolder = Main::getInstance()->getDataFolder() . "Jobs/";
        if (!is_dir($dataFolder)) {
            mkdir($dataFolder, 0777, true);
        }
        $config = new Config($dataFolder . "$job.json", Config::JSON);
        return $config->get($player->getName())[1];
    }

    public static function getMaxLevel(): int
    {
        return 25;
    }

    public static function getXp(Player $player, string $job): int|float
    {
        $dataFolder = Main::getInstance()->getDataFolder() . "Jobs/";
        if (!is_dir($dataFolder)) {
            mkdir($dataFolder, 0777, true);
        }
        $config = new Config($dataFolder . "$job.json", Config::JSON);
        return $config->get($player->getName())[0];
    }

    public static function getMaxXp(Player $player, string $job): int
    {
        return self::getIntoConfig("Jobs")[$job]["XpPerLevel"][self::getLevel($player, $job) - 1];
    }

    public static function getIntoConfig(string $value)
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "job.yml", Config::YAML);
        return $config->get($value);
    }

    /**
     * @throws JsonException
     */
    public static function addXp(Player $player, string $job, int|float $xp, float $xpBoostMultiplier = 1.0): void
    {
        $dataFolder = Main::getInstance()->getDataFolder() . "Jobs/";
        if (!is_dir($dataFolder)) {
            mkdir($dataFolder, 0777, true);
        }
        $config = new Config($dataFolder . "$job.json", Config::JSON);
        $playerName = $player->getName();
        if (!$config->exists($playerName)) {
            $config->set($playerName, [0, 1]);
            $config->save();
        }

        $boostedXp = (int)($xp * $xpBoostMultiplier);

        $currentExp = self::getXp($player, $job);
        $currentLevel = self::getLevel($player, $job);
        $maxExp = self::getMaxXp($player, $job);
        $newExp = $currentExp + $boostedXp;
        $newLevel = $currentLevel;

        while ($newExp >= $maxExp && $newLevel < self::getMaxLevel()) {
            $newExp -= $maxExp;
            $newLevel++;
            $maxExp = self::getIntoConfig("Jobs")[$job]["XpPerLevel"][$newLevel - 1];
            $rewards = self::getIntoConfig("Jobs")[$job]["rewards"][$newLevel - 1];

            foreach ($rewards as $reward) {
                $rewardParts = explode("&", $reward);
                $rewardType = $rewardParts[0];
                $rewardValue = (int)$rewardParts[1];

                switch ($rewardType) {
                    case "money":
                        MoneyManager::addMoney($player, $rewardValue);
                        break;
                    case "xp":
                        $player->getXpManager()->addXpLevels($rewardValue);
                        break;
                    case "token":
                        TokenManager::addToken($player, $rewardValue);
                        break;
                    case "perm":
                        Main::getInstance()->addPermission($player, $rewardValue, true);
                        break;
                    default:
                        $item = StringToItemParser::getInstance()->parse($rewardType);
                        if ($item) {
                            $item->setCount($rewardValue);
                            if ($player->getInventory()->canAddItem($item)) {
                                $player->getInventory()->addItem($item);
                            } else {
                                $player->getWorld()->dropItem($player->getPosition(), $item);
                            }
                        }
                        break;
                }

                $player->sendMessage(self::getIntoConfig("Jobs")[$job]["rewardsMessages"][$newLevel - 1]);
            }
        }

        $config->set($playerName, [$newExp, $newLevel]);
        $config->save();

        $player->sendPopup("§f+§9{$boostedXp}xp§f |§9 {$newExp}§f/§9$maxExp");
    }

    public static function getReward(string $job, int $level)
    {
        $rewards = self::getIntoConfig("Jobs")[$job]["rewards"];
        if (isset($rewards[$level])) {
            return $rewards[$level];
        }
        return null;
    }


    public static function getIntoConfigPlayer(string $job): Config
    {
        $dataFolder = Main::getInstance()->getDataFolder() . "Jobs/";
        if (!is_dir($dataFolder)) {
            mkdir($dataFolder, 0777, true);
        }

        return new Config($dataFolder . "$job.json", Config::JSON);
    }
}