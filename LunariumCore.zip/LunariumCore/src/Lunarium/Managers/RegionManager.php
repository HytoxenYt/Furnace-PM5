<?php

namespace Lunarium\Managers;

use JsonException;
use Lunarium\Utils\Region;
use pocketmine\math\Vector3;
use pocketmine\plugin\Plugin;
use pocketmine\utils\Config;
use pocketmine\world\Position;
use pocketmine\world\World;

class RegionManager {
    private Config $config;
    /** @var Region[] */
    private array $regions = [];

    /**
     * @throws JsonException
     */
    public function __construct(private readonly Plugin $plugin) {
        $this->load();
    }

    /**
     * @throws JsonException
     */
    public function add(Region $region): bool {
        if ($this->get($region->getName())) return false;
        $this->regions[] = $region;
        $this->save();
        return true;
    }

    /**
     * @throws JsonException
     */
    public function remove(Region|string $region): bool {
        if ($region instanceof Region) $region = $region->getName();
        if (!is_string($region)) return false;

        foreach ($this->regions as $index => $tempRegion) {
            if (strtolower($tempRegion->getName()) === strtolower($region)) {
                unset($this->regions[$index]);
                $this->save();
                return true;
            }
        }
        return false;
    }

    /**
     * @return Region[]
     */
    public function getAll(): array {
        return $this->regions;
    }

    public function get(string $name): ?Region {
        foreach ($this->regions as $region) {
            if (strtolower($region->getName()) === strtolower($name)) return $region;
        }
        return null;
    }

    public function getFromPosition(Position $position): ?Region {
        $region = null;
        foreach ($this->regions as $tempRegion) {
            if ($position->getWorld()->getDisplayName() !== $tempRegion->getWorldName()) continue;
            if ($tempRegion->getPos1() and $tempRegion->getPos2()) {
                $x1 = min($tempRegion->getPos1()->getX(), $tempRegion->getPos2()->getX());
                $x2 = max($tempRegion->getPos1()->getX(), $tempRegion->getPos2()->getX());
                $y1 = min($tempRegion->getPos1()->getY(), $tempRegion->getPos2()->getY());
                $y2 = max($tempRegion->getPos1()->getY(), $tempRegion->getPos2()->getY());
                $z1 = min($tempRegion->getPos1()->getZ(), $tempRegion->getPos2()->getZ());
                $z2 = max($tempRegion->getPos1()->getZ(), $tempRegion->getPos2()->getZ());

                if (($position->getFloorX() >= $x1 and $position->getFloorX() <= $x2) and
                    ($tempRegion->isExtendedVertically() or ($position->getFloorY() >= $y1 and $position->getFloorY() <= $y2)) and
                    ($position->getFloorZ() >= $z1 and $position->getFloorZ() <= $z2)) {
                    if ($region) {
                        if ($tempRegion->getPriority() > $region->getPriority())
                            $region = $tempRegion;
                    } else {
                        $region = $tempRegion;
                    }
                }
            } else {
                if ($region) {
                    if ($tempRegion->getPriority() > $region->getPriority())
                        $region = $tempRegion;
                } else {
                    $region = $tempRegion;
                }
            }
        }
        return $region;
    }

    public function getWorldRegion($world): ?Region {
        if ($world instanceof World) $world = $world->getDisplayName();
        if (!is_string($world)) return null;

        foreach ($this->regions as $region) {
            if ($region->getWorldName() === $world and $region->isWorldRegion())
                return $region;
        }
        return null;
    }

    private function getConfig(): Config {
        if (!isset($this->config)) $this->config = new Config($this->plugin->getDataFolder() . "regions.json", Config::JSON);
        return $this->config;
    }

    /**
     * @throws JsonException
     */
    public function load(): void
    {
        $regions = $this->getConfig()->getAll();
        foreach ($regions as $tempRegion) {
            if (!is_array($tempRegion)) continue;
            if (["name", "priority", "level", "pos1", "pos2", "extendedVertically", "flags"] != array_keys($tempRegion)) continue;

            $name = $tempRegion["name"];
            $priority = $tempRegion["priority"];
            $world = $tempRegion["level"];
            $pos1 = $tempRegion["pos1"];
            $pos2 = $tempRegion["pos2"];
            $extendedVertically = $tempRegion["extendedVertically"];
            $flags = $tempRegion["flags"];

            if (is_array($pos1) and is_array($pos2)) {
                if (["x", "y", "z"] != array_keys($tempRegion["pos1"])) continue;
                if (["x", "y", "z"] != array_keys($tempRegion["pos2"])) continue;
                $region = new Region($this, $name, $priority, $world, new Vector3(...array_values($pos1)), new Vector3(...array_values($pos2)), boolval($extendedVertically));
            } else {
                $region = new Region($this, $name, $priority, $world);
            }

            $region->setFlags($flags);
            $this->add($region);
        }
        $this->plugin->getLogger()->notice(count($this->regions) . " régions chargées");
    }

    /**
     * @throws JsonException
     */
    public function save(): void
    {
        $regions = [];
        foreach ($this->regions as $region) {
            $regions[$region->getName()] = [
                "name" => $region->getName(),
                "priority" => $region->getPriority(),
                "level" => $region->getWorldName(),
                "pos1" => $region->getPos1() ? [
                    "x" => $region->getPos1()->getX(),
                    "y" => $region->getPos1()->getY(),
                    "z" => $region->getPos1()->getZ()
                ] : "",
                "pos2" => $region->getPos2() ? [
                    "x" => $region->getPos2()->getX(),
                    "y" => $region->getPos2()->getY(),
                    "z" => $region->getPos2()->getZ()
                ] : "",
                "extendedVertically" => $region->isExtendedVertically(),
                "flags" => $region->getFlags()
            ];
        }

        $this->getConfig()->setAll($regions);
        $this->getConfig()->save();
    }
}