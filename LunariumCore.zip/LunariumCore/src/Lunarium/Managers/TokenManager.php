<?php

namespace Lunarium\Managers;

use Lunarium\Main;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class TokenManager{

    public static Config $token;

    public function __construct()
    {
        self::$token = new Config(Main::getInstance()->getDataFolder() . "token.yml", Config::YAML);
    }

    public static function createPlayer($player):void
    {
        if(!self::existsToken(self::getPlayerName($player))){
            self::$token->set(self::getPlayerName($player), 0);
            self::$token->save();
        }
    }

    public static function existsToken($player): bool
    {
        return self::$token->exists(self::getPlayerName($player));
    }

    public static function addToken($player, int|float $token): void
    {
        self::setToken($player, self::getTokenPlayer($player) + $token);
    }

    public static function removeToken($player, int|float $token): void
    {
        self::setToken($player, self::getTokenPlayer($player) - $token);
    }

    public static function setToken($player, int|float $token): void
    {
        self::$token->set(self::getPlayerName($player), $token);
        self::$token->save();
    }

    public static function getTokenPlayer($player): int|float
    {
        return self::$token->get(self::getPlayerName($player));
    }
    public static function getPlayerName($player): string
    {
        if ($player instanceof Player) return $player->getName(); else return $player;
    }
}