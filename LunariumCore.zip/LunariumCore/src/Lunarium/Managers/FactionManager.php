<?php

namespace Lunarium\Managers;

use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\world\Position;

class FactionManager
{
    public static array $invitation_ally = [];
    public static array $invitation = [];
    public static array $chat_ally = [];
    public static array $players = [];
    public static array $faction = [];
    public static array $chunk = [];
    public static array $chat = [];
    public static Config $data;
    public static Config $time;
    public static Config $power;
    public static Config $claim;


    public function __construct()
    {
        self::$claim = new Config(Main::getInstance()->getDataFolder() . "claim.yml", Config::YAML);
        self::$power = new Config(Main::getInstance()->getDataFolder() . "power.yml", Config::YAML);
        self::$data = new Config(Main::getInstance()->getDataFolder() . "faction.yml", Config::YAML);


        $this->init();

    }

    private function getPlayerName($player): ?string
    {
        if ($player instanceof Player) return $player->getName(); elseif ($player instanceof CommandSender) return "Serveur";
        else return $player;
    }


    private function init(): void
    {
        foreach (self::$data->getAll() as $faction => $key) {
            if (isset($key["Owner"])) {
                self::$faction[$faction] = $key["Owner"];

                foreach ($key["Members"] as $member => $rank) {
                    self::$players[$member] = $faction;
                }
            }
        }
    }


    public function isInFaction($player): bool
    {
        return isset(self::$players[self::getPlayerName($player)]);
    }

    public function getFactionPlayer($player): string
    {
        return self::$players[$this->getPlayerName($player)] ?? "";
    }

    public function hasPermissionInFaction($player, string $perm): bool
    {
        if ($this->getOwnerFaction($this->getFactionPlayer($player)) === $this->getPlayerName($player)) return true;
        $rankPermission = [
            "Recrue" => [],
            "Membre" => [],
            "Officier" => ["BANK", "DESCRIPTION", "KICK", "INVITE", "PROMOTE", "DEMOTE", "CLAIM", "UNCLAIM", "SURCLAIM", "ALLY", "UNALLY", "SETHOME", "RENAME"],
            "Chef" => ["BANK", "DESCRIPTION", "KICK", "INVITE", "PROMOTE", "DEMOTE", "CLAIM", "UNCLAIM", "SURCLAIM", "ALLY", "UNALLY", "SETHOME", "RENAME"]
        ];
        return in_array($perm,$rankPermission[$this->getRankPlayerInFaction($player)]);
    }

    public function existFaction(string $faction): bool
    {
        return isset(self::$faction[$faction]);
    }

    /**
     * @throws \JsonException
     */
    public function createFaction(string $faction, $owner): void
    {
        date_default_timezone_set("Europe/Paris");
        self::$faction[$faction] = $this->getPlayerName($owner);
        self::$players[$this->getPlayerName($owner)] = $faction;
        $rand1 = rand(10000, 60000);
        $rand2 = rand(30, 130);
        $rand3 = rand(3000, 6000);
        $rand4 = rand(300, 3000);
        $rand5 = rand(6310, 21000);

        $quest1 = Main::getInstance()->getFactionManager()->generateQuest(1, "Marcher §d{$rand1} §fblocks", $rand1, $rand1, rand(40000, 75000));
        $quest2 = Main::getInstance()->getFactionManager()->generateQuest(2, "Tuer §d{$rand2} §fjoueurs", $rand2, $rand2, rand(25000, 40000));
        $quest3 = Main::getInstance()->getFactionManager()->generateQuest(3, "Miner §d{$rand3} §fblocs", $rand3, $rand3, rand(20000, 35000));
        $quest4 = Main::getInstance()->getFactionManager()->generateQuest(4, "Enchanter §d{$rand4} §fitems", $rand4, $rand4, rand(50000, 110000));
        $quest5 = Main::getInstance()->getFactionManager()->generateQuest(5, "Placer §d{$rand5}§f blocks", $rand5, $rand5, rand(40000, 90000));

        self::$data->set($faction, [
            "Owner" => $this->getPlayerName($owner),
            "Members" => [$this->getPlayerName($owner) => $this->getRankName(3)],
            "Description" => "",
            "Ally" => [],
            "Home" => " ",
            "Bank" => 0,
            "Age" => [
                "Jour" => date("d/m/Y §fà§d H:i")
            ],
            "Niveau" => 0,
            "Prestige" => 0,
            "Valeur" => 0,
            "Quest" => [
                1 => $quest1,
                2 => $quest2,
                3 => $quest3,
                4 => $quest4,
                5 => $quest5
            ]
        ]);
        self::$data->save();
        Main::getInstance()->getServer()->broadcastMessage(Utils::PREFIX . "§fLa faction §d$faction §fà été créer par §d" . $this->getPlayerName($owner));
    }

    public function setQuestFaction(string $faction, int $number, array $quest): void
    {
        self::$data->setNested($faction.".Quest.$number", $quest);
        self::$data->save();
    }

    public function deleteQuestFaction(string $faction, int $number): void
    {
        self::$data->removeNested($faction.".Quest.$number");
        self::$data->save();
    }
    public function deleteFaction(string $faction): void
    {
        unset(self::$faction[$faction]);

        foreach ($this->getAllMembersFaction($faction) as $member => $rank) {
            unset(self::$players[$member]);
        }

        self::$data->remove($faction);
        self::$data->save();
    }

    public function getOwnerFaction(string $faction): string
    {
        return self::$faction[$faction];
    }

    public function setOwnerFaction(string $faction, $player): void
    {
        self::$faction[$faction] = $this->getPlayerName($player);

        self::$data->setNested("$faction.Members." . $this->getOwnerFaction($faction), $this->getRankName(3 - 1));

        self::$data->setNested("$faction.Owner", $this->getPlayerName($player));
        self::$data->setNested("$faction.Members." . $this->getPlayerName($player), $this->getRankName(3));
        self::$data->save();
    }
    public function getAllFactions(): array
    {
        $allFactions = [];
        foreach (self::$data->getAll() as $factionName => $factionData) {
            $allFactions[] = $factionName;
        }
        return $allFactions;
    }
    public function addMemberInFaction(string $faction, $player): void
    {
        self::$players[$this->getPlayerName($player)] = $faction;

        self::$data->setNested("$faction.Members." . $this->getPlayerName($player), $this->getRankName());
        self::$data->save();
    }

    public function removeMemberInFaction(string $faction, $player): void
    {
        unset(self::$players[$this->getPlayerName($player)]);

        self::$data->removeNested("$faction.Members." . $this->getPlayerName($player));
        self::$data->save();
    }

    public function getAllMembersFaction(string $faction, string $filter = "all"): array
    {
        $return = [];
        $factionData = self::$data->get($faction);

        if (isset($factionData["Members"]) && is_array($factionData["Members"])) {
            foreach ($factionData["Members"] as $member => $rank) {
                $return[$member] = $rank;
            }
        }

        return $return;
    }


    public function getRankName(int $int = 0): string
    {
        $rank = [];
        $ranks = [
            "Recrue" => "-",
            "Membre" => "+",
            "Officier" => "*",
            "Chef" => "^"
        ];
        foreach ($ranks as $rank_ => $chat) {
            $rank[] = $rank_;
        }

        return $rank[$int];
    }

    public function getRankInt(string $name): int
    {
        $rank = [];
        $count = 0;
        $ranks = [
            "Recrue" => "-",
            "Membre" => "+",
            "Officier" => "*",
            "Chef" => "^"
        ];
        foreach ($ranks as $rank_ => $chat) {
            $rank[$rank_] = $count;
            $count++;
        }

        return $rank[$name];
    }


    public function getRankPlayerInFaction($player): string
    {
        return self::$data->get($this->getFactionPlayer($player))["Members"][$this->getPlayerName($player)];
    }

    public function promotePlayerInFaction($player): void
    {
        $this->setRankPlayer($player, $this->getRankName($this->getRankInt($this->getRankPlayerInFaction($player)) + 1));
    }

    public function demotePlayerInFaction($player): void
    {
        $this->setRankPlayer($player, $this->getRankName($this->getRankInt($this->getRankPlayerInFaction($player)) - 1));
    }

    public function setRankPlayer($player, string $rank): void
    {
        self::$data->setNested($this->getFactionPlayer($player) . ".Members." . $this->getPlayerName($player), $rank);
        self::$data->save();
    }

    public function setDescriptionFaction(string $faction, string $desc): void
    {
        self::$data->setNested("$faction.Description", $desc);
        self::$data->save();
    }

    public function getDescriptionFaction(string $faction): string
    {
        return self::$data->get($faction)["Description"];
    }

    public function invitePlayerInFaction(string $faction, $player): void
    {
        self::$invitation[$this->getPlayerName($player)] = ["faction" => $faction, "time" => time() + 60];
    }

    public function hasInvitationPlayer($player): bool
    {
        return isset(self::$invitation[$this->getPlayerName($player)]);
    }

    public function isValidInvitation($player): bool
    {
        $name = $this->getPlayerName($player);
        if (self::$invitation[$name]["time"] > time()) return true; else {
            unset(self::$invitation[$name]);
        }
        return false;
    }

    public function countPlayerInFaction(string $faction): int
    {
        return count($this->getAllMembersFaction($faction));
    }

    public function countAllyFaction(string $faction): int
    {
        $count = 0;
        foreach (self::$data->getNested("$faction.Ally") as $ally => $faction_) {
            $count++;
        }
        return $count;
    }

    public function getFactionInvite($player): string
    {
        return self::$invitation[$this->getPlayerName($player)]["faction"];
    }

    public function existPlayer($player): bool
    {
        return self::$power->exists($this->getPlayerName($player));
    }

    public function getPowerPlayer($player): int
    {
        return self::$power->get($this->getPlayerName($player));
    }

    public function addPowerPlayer($player, int $power): void
    {
        self::$power->set($this->getPlayerName($player), $this->getPowerPlayer($player) + $power);
        self::$power->save();
    }

    public function removePowerPlayer($player, int $power): void
    {
        self::$power->set($this->getPlayerName($player), $this->getPowerPlayer($player) - $power);
        self::$power->save();
    }

    public function getChatPlayer($player): string
    {
        if (isset(self::$chat[$this->getPlayerName($player)])) {
            return "faction";
        } elseif (isset(self::$chat_ally[$this->getPlayerName($player)])) {
            return "ally";
        } else return "global";
    }

    public function getPowerFaction(string $faction): int
    {
        $power = 0;

        foreach ($this->getAllMembersFaction($faction) as $member => $rank) {
            $power += $this->getPowerPlayer($member);
        }

        return $power;
    }

    public function isChunkClaim(Vector3 $pos): bool
    {
        $x = $this->getPosChunk($pos)[0];
        $z = $this->getPosChunk($pos)[1];
        return self::$claim->exists("$x:$z");
    }

    public function claimChunk(string $faction, Vector3 $pos): void
    {
        $x = $this->getPosChunk($pos)[0];
        $z = $this->getPosChunk($pos)[1];
        self::$claim->set("$x:$z", $faction);
        self::$claim->save();
    }
    public function getClaim(int $chunkX, int $chunkZ)
    {
        return self::$claim->get($chunkX . ":" . $chunkZ);
    }

    public function unclaimChunk(Vector3 $pos): void
    {
        $x = $this->getPosChunk($pos)[0];
        $z = $this->getPosChunk($pos)[1];
        self::$claim->remove("$x:$z");
        self::$claim->save();
    }

    public function getFactionClaim(Vector3 $pos): string
    {
        $x = $this->getPosChunk($pos)[0];
        $z = $this->getPosChunk($pos)[1];
        return self::$claim->get("$x:$z");
    }

    public function countClaimFaction(string $faction): int
    {
        $count = 0;
        foreach (self::$claim->getAll() as $pos => $fac) {
            if ($fac === $faction) $count++;
        }
        return $count;
    }

    public function getPosChunk(Vector3 $pos): array
    {
        $x = $pos->getFloorX() >> 4;
        $z = $pos->getFloorZ() >> 4;
        return [$x, $z];
    }

    public function isAlly(string $faction, string $faction_ally): bool
    {
        if (self::$data->getNested("$faction.Ally.$faction_ally") !== null) {
            return true;
        } else return false;
    }

    public function addAllyFaction(string $faction, string $faction_ally): void
    {
        self::$data->setNested("$faction.Ally.$faction_ally", $faction_ally);
        self::$data->setNested("$faction_ally.Ally.$faction", $faction);
        self::$data->save();
    }

    public function removeAllyFaction(string $faction, string $faction_ally): void
    {
        self::$data->removeNested("$faction.Ally.$faction_ally");
        self::$data->removeNested("$faction_ally.Ally.$faction");
        self::$data->save();
    }

    public function inviteAlly(string $faction, string $faction_ally): void
    {
        self::$invitation_ally[$faction_ally] = ["faction" => $faction, "time" => time() + 60];
    }

    public function hasInvitationAlly(string $faction): bool
    {
        return isset(self::$invitation_ally[$faction]);
    }

    public function isValidInvitationAlly(string $faction): bool
    {
        if (self::$invitation_ally[$faction]["time"] > time()) return true; else {
            unset(self::$invitation_ally[$faction]);
        }
        return false;
    }

    public function sendChatFaction(string $faction, string $msg): void
    {
        foreach ($this->getAllMembersFaction($faction) as $member => $rank) {
            $player = Server::getInstance()->getPlayerByPrefix($member);
            if ($player instanceof Player) {
                $player->sendMessage($msg);
            }
        }
    }

    public function sendChatAlly(string $faction, string $msg): void
    {
        foreach (self::$data->get($faction)["Ally"] as $ally => $fac) {
            foreach ($this->getAllMembersFaction($ally) as $member => $rank) {
                $player = Server::getInstance()->getPlayerByPrefix($member);
                if ($player instanceof Player) {
                    $player->sendMessage($msg);
                }
            }
        }
    }

    public function hasHomeFaction(string $faction): bool
    {
        if (self::$data->get($faction)["Home"] === " ") return false; else return true;
    }

    public function setHomeFaction(string $faction, Position $position): void
    {
        self::$data->setNested($faction.".Home", [$position->x, $position->y, $position->z, $position->getWorld()->getDisplayName()]);
        self::$data->save();
    }

    public function getPositionHomeFaction(string $faction): Position
    {
        $pos = self::$data->get($faction)["Home"];
        return new Position($pos[0], $pos[1], $pos[2], Server::getInstance()->getWorldManager()->getWorldByName($pos[3]));
    }
    public function getAgeFaction(string $faction): array
    {
        if ($this->existFaction($faction)) {
            return self::$data->get($faction)["Age"];
        }else return [];
    }
    public function getBankFaction(string $faction): int|float
    {
        if ($this->existFaction($faction)) {
            return self::$data->get($faction)["Bank"];
        }else return 0;
    }
    public function setBankFaction(string $faction, int|float $money): void
    {
        self::$data->setNested($faction.".Bank", $money);
        self::$data->save();
    }
    public function getNiveauFaction(string $faction): int|float
    {
        if ($this->existFaction($faction)) {
            return self::$data->get($faction)["Niveau"];
        }else return 0;
    }
    public function getPrestigeFaction(string $faction): int|float
    {
        if ($this->existFaction($faction)) {
            return self::$data->get($faction)["Prestige"];
        }else return 0;
    }
    public function getAlliesFaction(string $faction): array
    {
        return self::$data->get($faction)["Ally"];
    }

    public function getAllChunkFromFaction(string $faction): array
    {
        $chunks = [];
        foreach (self::$claim->getAll() as $pos => $fac) {
            if ($fac === $faction) {
                $pos = explode(":", $pos);
                $chunks[] = ["x" => $pos[0], "z" => $pos[1]];
            }
        }
        return $chunks;
    }
    public function setValeurFaction(string $faction, int|float $valeur): void
    {
        self::$data->setNested($faction.".Valeur", $valeur);
        self::$data->save();
    }

    public function getValeurFaction(string $faction): int|float
    {
        if ($this->existFaction($faction)) {
            return self::$data->get($faction)["Valeur"];
        }else return 0;
    }
    public function generateQuest(int $number, string $description, int $objectifNumber, string $objectif, int $money, int $power = 0): array
    {
        return [
            "name" => "Mission n°§d$number",
            "description" => $description,
            "objectifNumber" => $objectifNumber,
            "objectif" => $objectif,
            "progression" => 0,
            "reward" => [
                "money" => $money,
                "power" => $power
            ],
            "recup" => "false",
            "finish" => "§cNon terminé",
            "send_message" => "false"
        ];
    }

    public function setRecupQuest(string $faction, int $number, string $recup): void
    {
        self::$data->setNested($faction.".Quest.$number.recup", $recup);
        self::$data->save();
    }
    public function getQuests(string $faction):array
    {
        return self::$data->get($faction)["Quest"];
    }
    public function setFinishQuest(string $faction, int $number, string $finish): void
    {
        self::$data->setNested($faction.".Quest.$number.finish", $finish);
        self::$data->save();
    }
    public function setSendMessage(string $faction, int $number, string $bool):void
    {
        self::$data->setNested($faction.".Quest.$number.send_message", $bool);
        self::$data->save();
    }

    public function addProgressionQuest(string $faction, int $number, int $progression): void
    {
        self::$data->setNested($faction.".Quest.$number.progression", $this->getQuests($faction)[$number]["progression"] + $progression);
        self::$data->save();
    }
    public function getFinishQuest(string $faction, int $number): string
    {
        return self::$data->get($faction)["Quest"][$number]["finish"];
    }
    public function getRewardMoneyQuest(string $faction, int $number): int|float
    {
        return self::$data->get($faction)["Quest"][$number]["reward"]["money"];
    }

    public function renameFaction(string $faction, string $new_faction): void
    {
        self::$faction[$new_faction] = self::getOwnerFaction($faction);
        unset(self::$faction[$faction]);

        foreach (self::getAllMembersFaction($faction) as $member) {
            unset(self::$players[$member]);
            self::$players[$member] = $new_faction;
        }

        self::$data->set($new_faction, self::$data->get($faction));
        self::$data->remove($faction);
        self::$data->save();
    }
}