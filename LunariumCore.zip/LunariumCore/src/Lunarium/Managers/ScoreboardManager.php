<?php

namespace Lunarium\Managers;


use Lunarium\Main;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\player\Player;
use pocketmine\Server;
class ScoreboardManager {

    public static array $scoreboards = [];
    public static array $scoreboards_actus = [];
    private const OBJECTIVE_NAME = "objective";
    private const CRITERIA_NAME = "dummy";

    public static function updateScoreboard(Player $player): void
    {
        if (isset(self::$scoreboards_actus[$player->getXuid()]) && self::$scoreboards_actus[$player->getXuid()] === "off") {
            return;
        }

        if (self::hasScore($player)) {
            self::setScore($player, " ");


            $lines = [
                "§f ",
                "§l§d» Profil",
                " §7Faction: " . (new FactionManager)->getFactionPlayer($player),
                " §7Pièces: §e" . MoneyManager::getMoneyPlayer($player),
                " §7Gemmes: §a" . TokenManager::getTokenPlayer($player),
                " ",
                "§l§d» Infos",
                " §7Serveur: §c".count(Server::getInstance()->getOnlinePlayers()),
                " §7VoteParty: §6" . VotePartyManager::getVoteParty() . "§f/§650",
                "     §dplay.lunamcbe.fr   "
            ];

            foreach ($lines as $key => $value) {
                self::setScoreLine($player, $key + 1, $value);
            }
        } else {
            self::setScore($player, " ");
            self::updateScoreboard($player);
        }
    }


    public static function hasScore(Player $player): bool
    {
        return isset(self::$scoreboards[mb_strtolower($player->getXuid())]);
    }

    public static function setScore(Player $player, string $displayName, int $slotOrder = SetDisplayObjectivePacket::SORT_ORDER_ASCENDING, string $displaySlot = SetDisplayObjectivePacket::DISPLAY_SLOT_SIDEBAR, string $objectiveName = self::OBJECTIVE_NAME, string $criteriaName = self::CRITERIA_NAME): void
    {
        if (isset(self::$scoreboards[mb_strtolower($player->getXuid())])) {
            self::removeScore($player);
        }

        $pk = new SetDisplayObjectivePacket();
        $pk->displaySlot = $displaySlot;

        $pk->objectiveName = $objectiveName;
        $pk->displayName = $displayName;

        $pk->criteriaName = $criteriaName;
        $pk->sortOrder = $slotOrder;

        $player->getNetworkSession()->sendDataPacket($pk);
        self::$scoreboards[mb_strtolower($player->getXuid())] = $objectiveName;
    }

    public static function removeScore(Player $player): void
    {
        $objectiveName = self::$scoreboards[mb_strtolower($player->getXuid())] ?? self::OBJECTIVE_NAME;
        $pk = new RemoveObjectivePacket();
        $pk->objectiveName = $objectiveName;
        $player->getNetworkSession()->sendDataPacket($pk);
        unset(self::$scoreboards[mb_strtolower($player->getXuid())]);
    }

    public static function setScoreLine(Player $player, int $line, string $message, int $type = ScorePacketEntry::TYPE_FAKE_PLAYER): void
    {
        $entry = new ScorePacketEntry();

        $entry->objectiveName = self::$scoreboards[mb_strtolower($player->getXuid())] ?? self::OBJECTIVE_NAME;
        $entry->type = $type;
        $entry->customName = $message;
        $entry->score = $line;
        $entry->scoreboardId = $line;

        $pk = new SetScorePacket();

        $pk->type = $pk::TYPE_CHANGE;
        $pk->entries[] = $entry;

        $player->getNetworkSession()->sendDataPacket($pk);
    }
}