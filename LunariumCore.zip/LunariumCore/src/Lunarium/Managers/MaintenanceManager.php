<?php

namespace Lunarium\Managers;

use JsonException;
use Lunarium\Main;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

class MaintenanceManager
{
    public function __construct(private bool $enabled = false, private array $list = [])
    {
    }

    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    /**
     * @throws JsonException
     */
    public function setEnabled(bool $enabled = true): void
    {
        $this->enabled = $enabled;
        $this->save();

        if ($enabled)
            foreach (Server::getInstance()->getOnlinePlayers() as $player) {
                if (!$this->inList($player->getName()))
                    $player->kick(TextFormat::colorize(implode(TextFormat::EOL, [
                        "&d&l---- MAINTENANCE ----",
                        "",
                        " &r&fVous pourrez de nouveau",
                        "jouer lorsque nous aurons",
                        "       terminé. A bientôt."
                    ])));
            }
    }

    /**
     * @throws JsonException
     */
    public function save(): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "maintenance.yml", Config::YAML);
        $config->setNested("maintenance.enabled", $this->enabled);
        $config->setNested("maintenance.whitelist", $this->list);
        $config->save();
    }

    /**
     * @return string[]
     */
    public function getList(): array
    {
        return $this->list;
    }

    /**
     * @param string[] $list
     * @throws JsonException
     */
    public function setList(array $list): void
    {
        $this->list = $list;
        $this->save();
    }

    /**
     * @throws JsonException
     */
    public function add(string $name): void
    {
        if (!$this->inList($name)) {
            $this->list[] = strtolower($name);
            $this->save();
        }
    }

    public function inList(string $name): bool
    {
        return in_array(strtolower($name), array_map("strtolower", $this->list));
    }

    /**
     * @throws JsonException
     */
    public function remove(string $name): void
    {
        if ($this->inList($name)) {
            $list = array_map("strtolower", $this->list);
            unset($list[array_search(strtolower($name), $list)]);
            $this->list = $list;
            $this->save();
        }
    }
}