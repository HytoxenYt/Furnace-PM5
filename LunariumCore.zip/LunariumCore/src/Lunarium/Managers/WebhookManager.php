<?php

namespace Lunarium\Managers;

class WebhookManager {
    const BAN = "https://discord.com/api/webhooks/1330490788240425011/CM8zWcWFeqpkIVr1c92_1T9FHva2qsQnh9F7cCE9aX3v61ViPM1lHvUPFB_OsXn8ZkTk";
    const MUTE = "https://discord.com/api/webhooks/1330492148440633474/Gz2GMzdtoobeInrRdvEtfMT-MAYH3jgd8-DKyYLbox4ZWHeKMVvLm33ip5IGCPov__yV";
    const WARN = "https://discord.com/api/webhooks/1330492372358004788/3uKOjOb5KqJWW8MVNZpWvTQeqEvGDtzl71HwjgiljmFngwmeUoUfn7-08cnPawwOQ63y";
    const DOUBLE_COMPTE = "https://discord.com/api/webhooks/1330544133831524353/fxjuniI9DlEoiGgKEANALk_Xykfdp_iZobwBCf4DtFcOTFzj6fBDqHiH1OkFsDNp3d_z";
}