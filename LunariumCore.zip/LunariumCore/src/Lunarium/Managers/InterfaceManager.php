<?php

namespace Lunarium\Managers;

use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;
use Lunarium\Main;
use Lunarium\Managers\MoneyManager;
use Lunarium\Utils\Utils;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class InterfaceManager
{
    public static array $page = [];
    public static array $auctions = [];
    public static array $auctionItem = [];
    public static array $search = [];
    public static array $statistics = [];
    public static array $statisticsItem = [];
    public static array $auctionMaxPage = [];

    public static function AuctionMenu(Player $player): void
    {
        $ui = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;

            switch ($data) {
                case 0:
                    self::AuctionPages($player);
                    break;
                case 1:
                    self::AuctionSearch($player);
                    break;
                case 2:
                    self::AuctionPlayer($player);
                    break;
                case 3:
                    self::AuctionStatistic($player);
                    break;
            }
        });

        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $ui->setContent("§fFaites §5/hdv sell <prix> §fpour vendre l'item entre vos mains");
        $ui->addButton("Annonce", 0, "textures/ui/Annonce");
        $ui->addButton("Recherches", 0, "textures/ui/Recherche");
        $ui->addButton("Mes annonces", 0, "textures/ui/MyAnnonce");
        $ui->addButton("Statistiques", 0, "textures/ui/Statistics");
        $ui->sendToPlayer($player);
    }

    public static function AuctionPages(Player $player, $page = 1): void
    {
        $configg = new Config(Main::getInstance()->getDataFolder() . "auction.json", Config::JSON);
        self::$page[$player->getXuid()] = $page;
        unset(self::$auctions[$player->getXuid()]);
        self::$auctions[$player->getXuid()] = [];

        $ui = new SimpleForm(function (Player $player, $data) use ($configg) {
            if (is_null($data)) return;

            if (self::$auctions[$player->getXuid()] !== []) {
                $min = 0;
                $max = count(self::$auctions[$player->getXuid()]) - 1;
                if ($data >= $min && $data <= $max) {
                    self::AuctionItem($player, self::$auctions[$player->getXuid()][$data]);
                    self::$auctionItem[$player->getXuid()] = self::$auctions[$player->getXuid()][$data];
                }

                if ($data === $max + 1) {
                    $array = $configg->getAll();
                    $maxpages = intval(abs(count($array) / 15));
                    $reste = count($array) % 15;
                    if ($reste > 0) {
                        $maxpage = $maxpages + 1;
                    } else {
                        $maxpage = $maxpages;
                    }
                    if (self::$page[$player->getXuid()] >= $maxpage) {
                        self::AuctionPages($player, self::$page[$player->getXuid()]);
                        return;
                    }
                    self::AuctionPages($player, self::$page[$player->getXuid()] + 1);
                    return;
                }

                if ($data === $max + 2) {
                    if (self::$page[$player->getXuid()] === 1) {
                        self::AuctionPages($player, self::$page[$player->getXuid()]);
                        return;
                    }
                    self::AuctionPages($player, self::$page[$player->getXuid()] - 1);
                    return;
                }

                if ($data === $max + 3) {
                    self::AuctionMenu($player);
                    return;
                }
            } else {
                if ($data === 0) {
                    $array = $configg->getAll();
                    $maxpages = intval(abs(count($array) / 15));
                    $reste = count($array) % 15;
                    if ($reste > 0) {
                        $maxpage = $maxpages + 1;
                    } else {
                        $maxpage = $maxpages;
                    }
                    if (self::$page[$player->getXuid()] >= $maxpage) {
                        self::AuctionPages($player, self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionPages($player, self::$page[$player->getXuid()] + 1);
                    return;
                }

                if ($data === 1) {
                    if (self::$page[$player->getXuid()] === 1) {
                        self::AuctionPages($player, self::$page[$player->getXuid()]);
                        return;
                    }
                    self::AuctionPages($player, self::$page[$player->getXuid()] - 1);
                    return;
                }

                if ($data === 2) {
                    self::AuctionMenu($player);
                    return;
                }
            }
        });

        $array = $configg->getAll();
        $array = array_reverse($array);
        $maxpages = intval(abs(count($array) / 15));
        $reste = count($array) % 15;
        if ($reste > 0) {
            $maxpage = $maxpages + 1;
        } else {
            $maxpage = $maxpages;
        }

        if ($maxpage == 0) $maxpage = 1;
        $ui->setTitle("§5- §fHôtel de Vente §f(§5{$page}§f/§5{$maxpage}§f)§5 -");
        $button = 1;
        $deptop = (($page - 1) * 15) + 1;
        $fintop = (($page - 1) * 15) + 16;
        foreach ($array as $auction => $item) {
            if ($button === $fintop) break;
            if ($button >= $deptop) {
                $item = Utils::ItemDeserialize($item);
                $values = explode(":::", $auction);
                $price = $values[0];
                $name = $values[1];
                $time = $values[2];
                $playerName = $values[3];
                $count = $item->getCount();
                if ($time - time() > 0) {
                    self::$auctions[$player->getXuid()][] = $auction;
                    $ui->addButton("§5$count $name §fà §5{$price}§f$\n§fVendeur: §5$playerName",);
                }
            }
            $button++;
        }
        $ui->addButton("§aSuivant");
        $ui->addButton("§cPrécédent");
        $ui->addButton("§4Retour");
        $ui->sendToPlayer($player);
    }

    public static function AuctionItem(Player $player, $value): void
    {
        $configg = new Config(Main::getInstance()->getDataFolder() . "auction.json", Config::JSON);
        $ui = new SimpleForm(function (Player $player, $data) use ($configg, $value) {
            if (is_null($data)) return;

            switch ($data) {
                case 0:
                    $value = self::$auctionItem[$player->getXuid()];
                    if ($configg->exists($value)) {
                        $item = $configg->get($value);
                        $item = Utils::ItemDeserialize($item);
                        $values = explode(":::", $value);
                        $price = $values[0];
                        $name = $values[1];
                        $time = $values[2];
                        $playerName = $values[3];
                        $count = $item->getCount();
                        if (MoneyManager::getMoneyPlayer($playerName) < intval($price)) {
                            $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez d'argent");
                            $player->closeAllForms();
                            return;
                        }

                        if (!$player->getInventory()->canAddItem($item->setCount($count))) {
                            $player->sendMessage(Utils::PREFIX . "§cVotre inventaire est plein");
                            $player->closeAllForms();
                            return;
                        }

                        if (strtolower($player->getName()) === $playerName) {
                            $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas vous acheter votre propre article");
                            $player->closeAllForms();
                            return;
                        }

                        $player->getInventory()->addItem($item->setCount($count));
                        MoneyManager::removeMoney($player, intval($price));
                        $configg->remove($value);
                        $configg->save();
                        $player->sendMessage(Utils::PREFIX . "§fVous avez bien acheté §5$count $name §5pour §5{$price}§f$");
                        $stats = new Config(Main::getInstance()->getDataFolder() . "Statistics/".Utils::getItemName($item).".json", Config::JSON);
                        if (!$stats->exists("maximum") or round($price / $count, 2) > (float)$stats->get("maximum")) $stats->set("maximum", round($price / $count, 2));
                        if (!$stats->exists("minimum") or round($price / $count, 2) < (float)$stats->get("minimum")) $stats->set("minimum", round($price / $count, 2));
                        $stats->set("price_total", (int) $stats->get("price_total") + (int) $price);
                        $stats->set("count_total", $stats->get("count_total") + $count);
                        $statsArray = $stats->exists("last-sales") === true ? (array)$stats->get("last-sales") : [];
                        $statsArray[] = $price . ":" . $count . ":" . $playerName;
                        if (count($statsArray) > 10) $statsArray = array_slice($statsArray, -10, 10);
                        $stats->set("last-sales", $statsArray);
                        $stats->save();
                        if ($player->getServer()->getPlayerByPrefix($playerName) !== null) {
                            $player->getServer()->getPlayerByPrefix($playerName)->sendMessage(Utils::PREFIX . "§5{$player->getName()}§f vous à acheté §5$count $name §fpour §5{$price}§f$");
                            MoneyManager::addMoney($player->getServer()->getPlayerByPrefix($playerName), $price);
                        } else MoneyManager::addMoney($playerName, $price);
                    } else $player->sendMessage(Utils::PREFIX . "§cL'article n'est plus disponible, quelqu'un l'a acheté avant vous");
                    break;
                case 1:
                    self::AuctionPages($player, self::$page[$player->getXuid()]);
                    break;
                case 2:
                    if ($player->hasPermission("Main.staff")) {
                        $value = self::$auctionItem[$player->getXuid()];
                        $configg->remove($value);
                        $configg->save();
                        $player->sendMessage(Utils::PREFIX . "§fVous avez bien supprimé l'article");
                        break;
                    }
                    break;
            }
        });
        $item = $configg->get($value);
        $item = Utils::ItemDeserialize($item);
        $count = $item->getCount();
        $values = explode(":::", $value);
        $price = $values[0];
        $name = $values[1];
        $time = $values[2];
        $playerName = $values[3];
        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $enchantment = [];
        foreach ($item->getEnchantments() as $enchantment) {
            $id = EnchantmentIdMap::getInstance()->toId($enchantment->getType());
            $level = $enchantment->getLevel();
            $enchName = Utils::getEnchantName($id);
            $enchantment[] = "§5$enchName §f=> §5$level";
        }
        $lore = implode(" ", $item->getLore());
        if ($enchantment === []) {
            $enchantment = "§cAucun enchantement";
        } else {
            $enchantment = implode(",", $enchantment);
        }

        $ui->setContent("§fVendeur: §5$playerName\n\n§fArticle: §5{$count}§fx §5$name\n§fEnchantment: {$enchantment}\n§fPrix: §5{$price}§f$");
        $ui->addButton("§aAcheter");
        $ui->addButton("§cAnnuler");
        if ($player->hasPermission("Main.staff")) $ui->addButton("§4Supprimer");
        $ui->sendToPlayer($player);
    }

    public static function AuctionPlayer(Player $player): void
    {
        $configg = new Config(Main::getInstance()->getDataFolder() . "auction.json", Config::JSON);
        unset(self::$auctions[$player->getXuid()]);
        self::$auctions[$player->getXuid()] = [];

        $ui = new SimpleForm(function (Player $player, $data) use ($configg) {
            if (is_null($data)) return;

            if (self::$auctions[$player->getXuid()] !== []) {
                $min = 0;
                $max = count(self::$auctions[$player->getXuid()]) - 1;
                if ($data >= $min and $data <= $max) {
                    self::AuctionPlayerItem($player, self::$auctions[$player->getXuid()][$data]);
                    self::$auctionItem[$player->getXuid()] = self::$auctions[$player->getXuid()][$data];
                }

                if ($data === $max + 1) {
                    self::AuctionMenu($player);
                    $player->closeAllForms();
                    return;
                }
            } else {
                self::AuctionMenu($player);
                $player->closeAllForms();
                return;
            }
        });

        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $array = $configg->getAll();
        $array = array_reverse($array);
        foreach ($array as $auction => $value) {
            $values = explode(":::", $auction);
            $playerName = $values[3];
            if ($playerName === $player->getName()) {
                self::$auctions[$player->getXuid()][] = $auction;
                $price = $values[0];
                $name = $values[1];
                $time = $values[2];
                $item = Utils::ItemDeserialize($value);
                $count = $item->getCount();
                if ($time - time() <= 0) {
                    $TempRestant = "§cExpiré";
                } else {
                    $time = $time - time();
                    $jour = intval(abs($time / 86400));
                    $time = $time - ($jour * 86400);
                    $heure = intval(abs($time / 3600));
                    $time = $time - ($heure * 3600);
                    $minute = intval(abs($time / 60));
                    $second = $time - ($minute * 60);
                    if ($jour > 0) {
                        $TempRestant = "§5{$jour}j §f{$heure}h §f{$minute}m §f{$second}s";
                    } elseif ($heure > 0) {
                        $TempRestant = "§5{$heure}h §f{$minute}m §f{$second}s";
                    } elseif ($minute > 0) {
                        $TempRestant = "§5{$minute}m §f{$second}s";
                    } else {
                        $TempRestant = "§5{$second}s";
                    }
                }
                $ui->addButton("§5{$count} {$name} §fà §5{$price}§f$\n§5{$TempRestant}");
            }
        }

        $ui->addButton("Retour");
        $ui->sendToPlayer($player);
    }

    public static function AuctionPlayerItem(Player $player, $value): void
    {
        $configg = new Config(Main::getInstance()->getDataFolder() . "auction.json", Config::JSON);
        $ui = new SimpleForm(function (Player $player, $data) use ($configg) {
            if (is_null($data)) return;

            switch ($data) {
                case 0:
                    $value = self::$auctionItem[$player->getXuid()];
                    if ($configg->exists($value)) {
                        $item = $configg->get($value);
                        $item = Utils::ItemDeserialize($item);
                        $values = explode(":::", $value);
                        $name = $values[1];
                        $count = $item->getCount();
                        if (!$player->getInventory()->canAddItem($item->setCount($count))) {
                            $player->sendMessage(Utils::PREFIX . "§cVotre inventaire est plein");
                            $player->closeAllForms();
                            return;
                        }

                        $player->getInventory()->addItem($item->setCount($count));
                        $player->closeAllForms();
                        $configg->remove($value);
                        $configg->save();
                        $player->sendMessage(Utils::PREFIX . "§fVous venez de recupérer §5$count $name");
                    } else {
                        $player->sendMessage(Utils::PREFIX . "§cL'article n'est plus disponible, quelqu'un l'a acheté avant vous");
                    }
                    break;
                case 1:
                    self::AuctionPlayer($player);
                    break;
            }
        });
        $item = $configg->get($value);
        $item = Utils::ItemDeserialize($item);
        $values = explode(":::", $value);
        $count = $item->getCount();
        $price = $values[0];
        $name = $values[1];
        $time = $values[2];
        $playerName = $values[3];
        $enchantment = [];
        foreach ($item->getEnchantments() as $enchantment) {
            $id = EnchantmentIdMap::getInstance()->toId($enchantment->getType());
            $level = $enchantment->getLevel();
            $enchName = Utils::getEnchantName($id);
            $enchantment[] = "§5$enchName §f=> §5$level";
        }

        if ($enchantment === []) {
            $enchantment = "§cAucun enchantement";
        } else {
            $enchantment = implode(",", $enchantment);
        }
        $lore = implode(" ", $item->getLore());

        if ($time - time() <= 0) {
            $TempRestant = "§cExpiré";
        } else {
            $time = $time - time();
            $jour = intval(abs($time / 86400));
            $time = $time - ($jour * 86400);
            $heure = intval(abs($time / 3600));
            $time = $time - ($heure * 3600);
            $minute = intval(abs($time / 60));
            $second = $time - ($minute * 60);
            if ($jour > 0) {
                $TempRestant = "§5{$jour}j §f{$heure}h §f{$minute}m §f{$second}s";
            } elseif ($heure > 0) {
                $TempRestant = "§5{$heure}h §f{$minute}m §f{$second}s";
            } elseif ($minute > 0) {
                $TempRestant = "§5{$minute}m §f{$second}s";
            } else {
                $TempRestant = "§5{$second}s";
            }
        }
        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $ui->setContent("§fExpiration: §5{$TempRestant}\n\n§fArticle: §5{$count} $name\n§fEnchantements: §5{$enchantment}\n§fPrix: §5{$price}§f$");
        $ui->addButton("Recupérer");
        $ui->addButton("§cAnnuler");
        $ui->sendToPlayer($player);
    }

    public static function AuctionSearch(Player $player): void
    {
        $ui = new CustomForm(function (Player $player, $data) {
            if (is_null($data)) return;

            if (!isset($data[0])) {
                $player->sendMessage(Utils::PREFIX . "§cVeuillez insérer un mot pour votre recherche");
                $player->closeAllForms();
                return;
            }

            $value = str_replace(' ', '', $data[0]);
            $value = str_replace('é', '', $value);
            $value = str_replace('É', '', $value);
            $value = str_replace('è', '', $value);
            $value = str_replace('È', '', $value);
            $value = str_replace('ê', '', $value);
            $value = str_replace('Ê', '', $value);

            if (!ctype_alpha($value)) {
                $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez utiliser que des lettres pour la recherche");
                $player->closeAllForms();
                return;
            }

            self::AuctionSearchPages($player, $data[0], 1);
            self::$search[$player->getXuid()] = $data[0];
        });
        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $ui->addInput("Quel item souhaitez-vous a chercher ?", "§fPierre");
        $ui->sendToPlayer($player);
    }

    public static function AuctionSearchPages(Player $player, $search, $page): void
    {
        $configg = new Config(Main::getInstance()->getDataFolder() . "auction.json", Config::JSON);
        self::$page[$player->getXuid()] = $page;
        unset(self::$auctions[$player->getXuid()]);
        self::$auctions[$player->getXuid()] = [];
        $ui = new SimpleForm(function (Player $player, $data) use ($configg) {
            if (self::$auctions[$player->getXuid()] != array()) {
                $min = 0;
                $max = count(self::$auctions[$player->getXuid()]) - 1;
                if ($data >= $min and $data <= $max) {
                    self::AuctionSearchItem($player, self::$auctions[$player->getXuid()][$data]);
                    self::$auctionItem[$player->getXuid()] = self::$auctions[$player->getXuid()][$data];
                }

                if ($data === $max + 1) {
                    $array = self::$auctions[$player->getXuid()];
                    $maxpages = intval(abs(count($array) / 15));
                    $reste = count($array) % 15;
                    if ($reste > 0) {
                        $maxpage = $maxpages + 1;
                    } else {
                        $maxpage = $maxpages;
                    }
                    if (self::$page[$player->getXuid()] >= self::$auctionMaxPage[$player->getXuid()]) {
                        self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] + 1);
                    return;
                }

                if ($data === $max + 2) {
                    if (self::$page[$player->getXuid()] === 1) {
                        self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                        return;
                    }
                    self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] - 1);
                    return;
                }

                if ($data === $max + 3) {
                    self::AuctionMenu($player);
                    return;
                }
            } else {
                if ($data === 0) {
                    $array = self::$auctions[$player->getXuid()];
                    $maxpages = intval(abs(count($array) / 15));
                    $reste = count($array) % 15;
                    if ($reste > 0) {
                        $maxpage = $maxpages + 1;
                    } else {
                        $maxpage = $maxpages;
                    }
                    if (self::$page[$player->getXuid()] >= self::$auctionMaxPage[$player->getXuid()]) {
                        self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                        return;
                    }
                    self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] + 1);
                    return;
                }

                if ($data === 1) {
                    if (self::$page[$player->getXuid()] === 1) {
                        self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] - 1);
                    return;
                }

                if ($data === 2) {
                    self::AuctionMenu($player);
                    return;
                }
            }
        });
        $array2 = $configg->getAll();
        $array2 = array_reverse($array2);
        $array = [];
        foreach ($array2 as $auction => $item) {
            if (strpos($auction, ucfirst($search))) {
                $array[$auction] = $item;
            }
        }

        $maxpages = intval(abs(count($array) / 15));
        $reste = count($array) % 15;
        if ($reste > 0) {
            $maxpage = $maxpages + 1;
        } else {
            $maxpage = $maxpages;
        }
        if ($maxpage == 0) $maxpage = 1;
        self::$auctionMaxPage[$player->getXuid()] = $maxpage;
        $ui->setTitle("§5- §fHôtel de Vente (§5{$page}§f/§5{$maxpage})§5 -");
        $button = 1;
        $deptop = (($page - 1) * 15) + 1;
        $fintop = (($page - 1) * 15) + 16;

        foreach ($array as $auctionnnns => $item) {
            if ($button === $fintop) break;
            if ($button >= $deptop) {
                $value = explode(":::", $auctionnnns);
                $price = $value[0];
                $name = $value[1];
                $time = $value[2];
                $playerName = $value[3];
                $item = Utils::ItemDeserialize($item);
                $count = $item->getCount();
                if ($time - time() > 0) {
                    self::$auctions[$player->getXuid()][] = $auctionnnns;
                    $ui->addButton("§5$count $name §fà §5{$price}§f$\n§fVendeur: §5$playerName");
                }
            }
            $button++;
        }
        $ui->addButton("§aSuivant");
        $ui->addButton("§cPrécédent");
        $ui->addButton("§4Retour");
        $ui->sendToPlayer($player);
    }

    public static function AuctionSearchItem(Player $player, $value): void
    {
        $configg = new Config(Main::getInstance()->getDataFolder() . "auction.json", Config::JSON);
        $ui = new SimpleForm(function (Player $player, $data) use ($configg) {
            if (is_null($data)) return;
            switch ($data) {
                case 0:
                    $value = self::$auctionItem[$player->getXuid()];
                    if ($configg->exists($value)) {
                        $item = $configg->get($value);
                        $item = Utils::ItemDeserialize($item);
                        $values = explode(":::", $value);
                        $price = $values[0];
                        $name = $values[1];
                        $time = $values[2];
                        $playerName = $values[3];
                        $count = $item->getCount();
                        if (MoneyManager::getMoneyPlayer($playerName) < intval($price)) {
                            $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez d'argent");
                            $player->closeAllForms();
                            return;
                        }

                        if (!$player->getInventory()->canAddItem($item->setCount($count))) {
                            $player->sendMessage(Utils::PREFIX . "§cVotre inventaire est plein");
                            $player->closeAllForms();
                            return;
                        }

                        if (strtolower($player->getName()) === $playerName) {
                            $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas vous acheter votre propre article");
                            $player->closeAllForms();
                            return;
                        }

                        $player->getInventory()->addItem($item->setCount($count));
                        MoneyManager::removeMoney($player, intval($price));
                        $configg->remove($value);
                        $configg->save();
                        $player->sendMessage(Utils::PREFIX . "§fVous avez bien acheté §5$count $name §5pour §5{$price}§f$");
                        $stats = new Config(Main::getInstance()->getDataFolder() . "Statistics/".Utils::getItemName($item).".json", Config::JSON);
                        if (!$stats->exists("maximum") or round($price / $count, 2) > (float)$stats->get("maximum")) $stats->set("maximum", round($price / $count, 2));
                        if (!$stats->exists("minimum") or round($price / $count, 2) < (float)$stats->get("minimum")) $stats->set("minimum", round($price / $count, 2));
                        $stats->set("price_total", (int) $stats->get("price_total") + (int) $price);
                        $stats->set("count_total", (int) $stats->get("count_total") + $count);
                        $statsArray = $stats->exists("last-sales") === true ? (array)$stats->get("last-sales") : [];
                        $statsArray[] = $price . ":" . $count . ":" . $playerName;
                        if (count($statsArray) > 10) $statsArray = array_slice($statsArray, -10, 10);
                        $stats->set("last-sales", $statsArray);
                        $stats->save();
                        if ($player->getServer()->getPlayerByPrefix($playerName) !== null) {
                            $player->getServer()->getPlayerByPrefix($playerName)->sendMessage(Utils::PREFIX . "§5{$player->getName()}§f vous à acheté §5$count $name §fpour §5{$price}§f$");
                            MoneyManager::addMoney($player->getServer()->getPlayerByPrefix($playerName), $price);
                        } else MoneyManager::addMoney($playerName, $price);
                    } else $player->sendMessage(Utils::PREFIX . "§cL'article n'est plus disponible, quelqu'un l'a acheté avant vous");
                    break;
                case 1:
                    self::AuctionSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                    break;
                case 2:
                    if ($player->hasPermission("Main.staff")) {
                        $value = self::$auctionItem[$player->getXuid()];
                        $configg->remove($value);
                        $configg->save();
                        $player->sendMessage(Utils::PREFIX . "§fVous avez bien supprimé l'article");
                        break;
                    }
                    break;
            }
        });
        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $values = explode(":::", $value);
        $item = Utils::ItemDeserialize($configg->get($value));
        $count = $item->getCount();
        $price = $values[0];
        $name = $values[1];
        $playerName = $values[3];
        $enchantment = [];
        foreach ($item->getEnchantments() as $enchantment) {
            $id = EnchantmentIdMap::getInstance()->toId($enchantment->getType());
            $level = $enchantment->getLevel();
            $enchName = Utils::getEnchantName($id);
            $enchantment[] = "§5$enchName §f=> §5$level";
        }
        $lore = implode(" ", $item->getLore());
        if ($enchantment === []) {
            $enchantment = "§cAucun enchantement";
        } else {
            $enchantment = implode(",", $enchantment);
        }
        $ui->setContent("§fVendeur: §5$playerName\n\n§fArticle: §5{$count}§fx §5$name\n§fEnchantment: {$enchantment}\n§fPrix: §5{$price}§f$");
        $ui->addButton("§aAcheter");
        $ui->addButton("§cAnnuler");
        if ($player->hasPermission("Main.staff")) $ui->addButton("§4Supprimer");
        $ui->sendToPlayer($player);
    }

    public static function AuctionStatistic($player, $page = 1): void
    {
        $items = scandir(Main::getInstance()->getDataFolder() . "Statistics");
        self::$page[$player->getXuid()] = $page;
        unset(self::$statistics[$player->getXuid()]);
        self::$statistics[$player->getXuid()] = [];
        $ui = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;

            if (self::$statistics[$player->getXuid()] !== array()) {
                $min = 1;
                $max = count(self::$statistics[$player->getXuid()]);
                if ($data >= $min and $data <= $max) {
                    self::AuctionStatisticItem($player, self::$statistics[$player->getXuid()][$data - 1]);
                    self::$statisticsItem[$player->getXuid()] = self::$statistics[$player->getXuid()][$data - 1];
                }

                if ($data === 0) {
                    self::AuctionStatisticSearch($player);
                    return;
                }

                if ($data === $max + 1) {
                    $items = scandir(Main::getInstance()->getDataFolder() . "Statistics");
                    $reste = count($items) % 15;
                    $maxpage = $reste > 0 === true ? intval(abs(count($items) / 15)) + 1 : intval(abs(count($items) / 15));
                    if (self::$page[$player->getXuid()] >= $maxpage) {
                        self::AuctionStatistic($player, self::$page[$player->getXuid()]);
                        return;
                    }
                    self::AuctionStatistic($player, self::$page[$player->getXuid()] + 1);
                    return;
                }

                if ($data === $max + 2) {
                    if (self::$page[$player->getXuid()] === 1) {
                        self::AuctionStatistic($player, self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionStatistic($player, self::$page[$player->getXuid()] - 1);
                    return;
                }

                if ($data === $max + 3) {
                    self::AuctionMenu($player);
                    return;
                }
            } else {
                if ($data === 0) {
                    self::AuctionStatisticSearch($player);
                    return;
                }

                if ($data === 1) {
                    $items = scandir(Main::getInstance()->getDataFolder() . "Statistics");
                    $reste = count($items) % 15;
                    $maxpage = $reste > 0 === true ? intval(abs(count($items) / 15)) + 1 : intval(abs(count($items) / 15));

                    if (self::$page[$player->getXuid()] >= $maxpage) {
                        self::AuctionStatistic($player, self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionStatistic($player, self::$page[$player->getXuid()] + 1);
                    return;
                }

                if ($data === 2) {
                    if (self::$page[$player->getXuid()] === 1) {
                        self::AuctionStatistic($player, self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionStatistic($player, self::$page[$player->getXuid()] - 1);
                    return;
                }

                if ($data === 3) {
                    self::AuctionMenu($player);
                    return;
                }
            }
        });
        $reste = count($items) % 15;
        $maxpage = $reste > 0 === true ? intval(abs(count($items) / 15)) + 1 : intval(abs(count($items) / 15));
        if ($maxpage === 0) $maxpage = 1;
        $ui->setTitle("§5- §fHôtel de Vente §f(§5{$page}§f/§5{$maxpage}§f)§5 -");
        $button = 1;
        $deptop = (($page - 1) * 15) + 1;
        $fintop = (($page - 1) * 15) + 16;
        $ui->addButton("Recherche");
        foreach ($items as $index => $fileName) {
            if ($button === $fintop) break;
            if ($button >= $deptop) {
                if (str_contains($fileName, '.json')) {
                    self::$statistics[$player->getXuid()][] = $fileName;
                    $fileNameE = explode(".json", $fileName)[0];
                    $ui->addButton($fileNameE);
                }
            }
            $button++;
        }
        $ui->addButton("§aSuivant");
        $ui->addButton("§cPrécédent");
        $ui->addButton("§4Retour");
        $ui->sendToPlayer($player);
    }

    public static function AuctionStatisticItem($player, $value): void
    {
        $ui = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;
            self::AuctionStatistic($player, self::$page[$player->getXuid()] ?? 1);

        });
        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $config = new Config(Main::getInstance()->getDataFolder() . "Statistics/" . $value, Config::JSON);
        $itemName = explode(".json", $value)[0] ?? "Undefined";
        $minimum = (float)$config->get("minimum");
        $maximum = (float)$config->get("maximum");
        $ptotal = (float)$config->get("price_total");
        $ctotal = (float)$config->get("count_total");
        $average = round($ptotal / $ctotal, 2);
        $lasts = [];
        foreach (array_reverse($config->get("last-sales")) as $index => $values) {
            $values = explode(":", $values);
            $count = $values[1];
            $price = $values[0];
            $playerName = $values[2];
            $lasts[] = "§5- §5{$count}x§f pour§5 {$price}§f$ §fpar§5 {$playerName}";
        }
        $lasts = implode("\n", $lasts);
        $content = str_replace(["{name}", "{price_max}", "{price_min}", "{price_average}", "{price_total}", "{count_total}", "{last-sales}"], [$itemName, $maximum, $minimum, $average, $ptotal, $ctotal, $lasts], "§fNom : §5{name}\n\n§fPrix minimum à l'unité : §5{price_min}$\n§fPrix maximum à l'unité : §5{price_max}$\n§fPrix moyen à l'unité : §5{price_average}$\n\n§fNombre total vendus : §5{count_total}\n§fArgent total gagné : §5{price_total}$\n\n§f10 dernières ventes :\n§5{last-sales}");
        $ui->setContent($content);
        $ui->addButton("§4Retour");
        $ui->sendToPlayer($player);
    }

    public static function AuctionStatisticSearch($player)
    {
        $ui = new CustomForm(function (Player $player, $data) {
            if (is_null($data)) return;

            if (!isset($data[0])) {
                $player->sendMessage(Utils::PREFIX . "§cVeuillez insérer un mot pour votre recherche");
                $player->closeAllForms();
                return;
            }

            $value = str_replace(' ', '', $data[0]);
            $value = str_replace('é', '', $value);
            $value = str_replace('É', '', $value);
            $value = str_replace('è', '', $value);
            $value = str_replace('È', '', $value);
            $value = str_replace('ê', '', $value);
            $value = str_replace('Ê', '', $value);

            if (!ctype_alpha($value)) {
                $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez utiliser que des lettres pour la recherche");
                $player->closeAllForms();
                return;
            }

            self::AuctionStatisticSearchPages($player, $data[0], 1);
            self::$search[$player->getXuid()] = $data[0];
        });
        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $ui->addInput("Quel item souhaitez-vous a chercher ?", "§fPierre");
        $ui->sendToPlayer($player);
    }

    public static function AuctionStatisticSearchPages($player, $search, $page): void
    {
        $items = scandir(Main::getInstance()->getDataFolder() . "Statistics");
        self::$page[$player->getXuid()] = $page;
        unset(self::$statistics[$player->getXuid()]);
        self::$statistics[$player->getXuid()] = [];
        $ui = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;

            if (self::$statistics[$player->getXuid()] !== array()) {
                $min = 1;
                $max = count(self::$statistics[$player->getXuid()]);
                if ($data >= $min and $data <= $max) {
                    self::AuctionStatisticSearchItem($player, self::$statistics[$player->getXuid()][$data - 1]);
                    self::$statisticsItem[$player->getXuid()] = self::$statistics[$player->getXuid()][$data - 1];
                }

                if ($data === 0) {
                    self::AuctionStatisticSearch($player);
                    return;
                }

                if ($data === $max + 1) {
                    $items = scandir(Main::getInstance()->getDataFolder() . "Statistics");
                    $reste = count($items) % 15;
                    $maxpage = $reste > 0 === true ? intval(abs(count($items) / 15)) + 1 : intval(abs(count($items) / 15));
                    if (self::$page[$player->getXuid()] >= self::$auctionMaxPage[$player->getXuid()]) {
                        self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                        return;
                    }
                    self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] + 1);
                    return;
                }

                if ($data === $max + 2) {
                    if (self::$page[$player->getXuid()] === 1) {
                        self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] - 1);
                    return;
                }

                if ($data === $max + 3) {
                    self::AuctionMenu($player);
                    return;
                }
            } else {
                if ($data === 0) {
                    self::AuctionStatisticSearch($player);
                    return;
                }

                if ($data === 1) {
                    $items = scandir(Main::getInstance()->getDataFolder() . "Statistics");
                    $reste = count($items) % 15;
                    $maxpage = $reste > 0 === true ? intval(abs(count($items) / 15)) + 1 : intval(abs(count($items) / 15));

                    if (self::$page[$player->getXuid()] >= self::$auctionMaxPage[$player->getXuid()]) {
                        self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] + 1);
                    return;
                }

                if ($data === 2) {
                    if (self::$page[$player->getXuid()] === 1) {
                        self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()]);
                        return;
                    }

                    self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] - 1);
                    return;
                }

                if ($data === 3) {
                    self::AuctionMenu($player);
                    return;
                }
            }


        });
        $array = [];
        foreach ($items as $index => $fileName) {
            if (strpos($fileName, '.json') !== false) {
                if (strpos($fileName, ucfirst($search)) !== false) {
                    $array[] = $fileName;
                }
            }
        }

        $reste = count($array) % 15;
        $maxpage = $reste > 0 === true ? intval(abs(count($array) / 15)) + 1 : intval(abs(count($array) / 15));
        self::$auctionMaxPage[$player->getXuid()] = $maxpage;
        if ($maxpage === 0) $maxpage = 1;
        $ui->setTitle("§5- §fHôtel de Vente §f(§5{$page}§f/§5{$maxpage}§f)§5 -");
        $button = 1;
        $deptop = (($page - 1) * 15) + 1;
        $fintop = (($page - 1) * 15) + 16;
        $ui->addButton("Recherche");
        foreach ($array as $index => $fileName) {
            if ($button === $fintop) break;
            if ($button >= $deptop) {
                if (strpos($fileName, '.json') !== false) {
                    self::$statistics[$player->getXuid()][] = $fileName;
                    $fileNameE = explode(".json", $fileName)[0];
                    $ui->addButton($fileNameE);
                }
            }
            $button++;
        }
        $ui->addButton("§aSuivant");
        $ui->addButton("§cPrécédent");
        $ui->addButton("§4Retour");
        $ui->sendToPlayer($player);
    }

    public static function AuctionStatisticSearchItem($player, $value)
    {
        $ui = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;
            self::AuctionStatisticSearchPages($player, self::$search[$player->getXuid()], self::$page[$player->getXuid()] ?? 1);

        });
        $ui->setTitle("§5- §fHôtel de Vente§5 -");
        $config = new Config(Main::getInstance()->getDataFolder() . "Statistics/" . $value, Config::JSON);
        $itemName = explode(".json", $value)[0] ?? "Undefined";
        $minimum = (float)$config->get("minimum");
        $maximum = (float)$config->get("maximum");
        $ptotal = (float)$config->get("price_total");
        $ctotal = (float)$config->get("count_total");
        $average = round($ptotal / $ctotal, 2);
        $lasts = [];
        foreach (array_reverse($config->get("last-sales")) as $index => $values) {
            $values = explode(":", $values);
            $count = $values[1];
            $price = $values[0];
            $playerName = $values[2];
            $lasts[] = "§5-§5 {$count}§5x§f pour§5 {$price}§f$ §fpar§5 {$playerName}";

        }
        $lasts = implode("\n", $lasts);
        $content = str_replace(["{name}", "{price_max}", "{price_min}", "{price_average}", "{price_total}", "{count_total}", "{last-sales}"], [$itemName, $maximum, $minimum, $average, $ptotal, $ctotal, $lasts], "§fNom : §5{name}\n\n§fPrix minimum à l'unité : §5{price_min}$\n§fPrix maximum à l'unité : §5{price_max}$\n§fPrix moyen à l'unité : §5{price_average}$\n\n§fNombre total vendus : §5{count_total}\n§fArgent total gagné : §5{price_total}$\n\n§f10 dernières ventes :\n§5{last-sales}");
        $ui->setContent($content);
        $ui->addButton("§4Retour");
        $ui->sendToPlayer($player);
    }
}