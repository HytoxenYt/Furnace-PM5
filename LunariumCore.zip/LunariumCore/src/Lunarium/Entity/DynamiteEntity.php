<?php

namespace Lunarium\Entity;

use Lunarium\Main;
use Lunarium\Utils\Region;
use pocketmine\entity\projectile\Throwable;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\world\Explosion;

class DynamiteEntity extends Throwable {
    private bool $hasExploded = false;

    protected function onHit(ProjectileHitEvent $event): void {
        $this->flagForDespawn();
        if (!$this->hasExploded) {
            $this->hasExploded = true;
            $explosion = $this->getExplosion();
            $explosion->explodeA();

            if ($manager = Main::getInstance()->getRegionManager()) {
                foreach ($explosion->affectedBlocks as $key => $block) {
                    if ($manager->getFromPosition($block->getPosition()->asPosition())?->getFlag(Region::FLAG_EXPLOSION) === false) {
                        unset($explosion->affectedBlocks[$key]);
                    }
                }
            }

            if (!empty($explosion->affectedBlocks)) $explosion->explodeB();
        }
    }

    protected function getExplosion(): Explosion {
        return new Explosion($this->getPosition(), 5, $this);
    }

    public static function getNetworkTypeId(): string
    {
        return "lunarium:dynamite";
    }
}