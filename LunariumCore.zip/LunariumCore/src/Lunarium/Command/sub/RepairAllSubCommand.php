<?php

namespace Lunarium\Command\sub;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

class RepairAllSubCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;

        $xuid = $sender->getXuid();

        if (Utils::getCooldown()->has($xuid, "repair_all")) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez attendre " . Main::getInstance()->intToTime(Utils::getCooldown()->get($xuid, "repair_all"), "§c"));
            return;
        }


        $content = $sender->getInventory()->getContents();
        $itemsRepaired = 0;
        foreach ($content as $slot => $item) {
            if ($item->getTypeId() === VanillaItems::AIR()->getTypeId()) {
                continue;
            }

            if ($item->isNull()) {
                continue;
            }

            if (!$item instanceof Durable) {
                continue;
            }

            $item->setDamage(0);
            $sender->getInventory()->setItem($slot, $item);
            $itemsRepaired++;
        }

        $contentArmor = $sender->getArmorInventory()->getContents();
        foreach ($contentArmor as $slot => $item) {
            if ($item->getTypeId() === VanillaItems::AIR()->getTypeId()) {
                continue;
            }

            if ($item->isNull()) {
                continue;
            }

            if (!$item instanceof Durable) {
                continue;
            }

            $item->setDamage(0);
            $sender->getArmorInventory()->setItem($slot, $item);
            $itemsRepaired++;
        }

        if($itemsRepaired > 1){
            $ranks = [
                "Voyageur" => 60 * 60,
                "Guerrier" => 60 * 30,
                "Lunaire" => 60 * 10
            ];

            Utils::getCooldown()->add($xuid, "repair_all", $ranks[Main::getInstance()->getRank($sender->getName())] ?? 60 * 60);
            $sender->sendMessage(Utils::PREFIX . "§fVous avez réparé §9$itemsRepaired items");
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cVous avez réparé aucuns items");
        }
    }

    public function getPermission(): string
    {
        return "lunarium.repairall";
    }
}