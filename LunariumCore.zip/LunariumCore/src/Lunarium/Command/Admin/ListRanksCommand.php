<?php

namespace Lunarium\Command\Admin;

use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class ListRanksCommand extends Command
{
    public function __construct()
    {
        parent::__construct("listranks", "Permet d'avoir la liste des grades", "/listranks");
        $this->setPermission("lunarium.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if(!$sender->hasPermission($this->getPermissions()[0])){
            $sender->sendMessage(Utils::PREFIX."§cVous n'avez pas accès à cette commande");
            return;
        }

        $ranks = Main::getInstance()->getAllRanks();
        $ranksList = [];

        foreach ($ranks as $rank) {
            $rank = self::formatRank($rank);
            [$color, $bracketsColor] = self::getRankColors($rank);

            $ranksList[] = "{$bracketsColor}[{$color}{$rank}{$bracketsColor}]";
        }

        $sender->sendMessage(Utils::PREFIX . "§fListe des grades §7(§9" . count($ranksList) . "§7)§f : " . implode(" §7| §f", $ranksList));
    }


    public static function formatRank(string $rank): string
    {
        return match ($rank) {
            "Moderateur" => "Modérateur",
            "Super-Moderateur" => "Super-Modérateur",
            "Youtubeur" => "§cYou§4tube",
            default => $rank,
        };
    }

    public static function getRankColors(string $rank): array
    {
        return match ($rank) {
            "Fondateur" => ["§4", "§c"],
            "§cYou§4tube", "Administrateur" => ["§c", "§4"],
            "Super-Modérateur" => ["§2", "§a"],
            "Modérateur" => ["§a", "§2"],
            "Ange", "Guide" => ["§1", "§9"],
            "Builder" => ["§6", "§e"],
            "Responsable", "Divin" => ["§5", "§d"],
            "Roi-Mage" => ["§e", "§6"],
            "Streameur", "Cavalier" => ["§d", "§5"],
            default => ["§7", "§8"],
        };
    }

}