<?php

declare(strict_types=1);

namespace Lunarium\Command\Admin;

use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class IdCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;
        $a = $sender->getInventory()->getItemInHand()->getCustomBlockData();
        $b = $sender->getInventory()->getItemInHand()->getStateId();
        $c = $sender->getInventory()->getItemInHand()->getTypeId();
        $d = $sender->getInventory()->getItemInHand()->getVanillaName();
        $e = $sender->getInventory()->getItemInHand()->getAttackPoints();
        $sender->sendMessage(" CustomData = $a\n StateID = $b\n TypeID = $c\n VanillaName = $d\nPoint d'Attaque = $e");
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}

