<?php

namespace Lunarium\Command\Admin;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
class TPAllCommand extends Command
{
    public function __construct()
    {
        parent::__construct("tpall", "Permet de tp tout le monde", "/tpall");
        $this->setPermission("lunarium.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être connecté");
            return;
        }

        $count = 0;
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if ($sender->getXuid() === $player->getXuid()) continue;
            $player->teleport($sender->getPosition());
            $player->sendMessage(Utils::PREFIX . "§fVous avez été téléporté sur §9{$sender->getName()}");
            $count++;
        }

        $sender->sendMessage(Utils::PREFIX . "§9{$count} joueur" . ($count > 1 ? "s " : " ") . "§f" . ($count > 1 ? "ont" : "à") . " été téléporté sur vous");
    }
}