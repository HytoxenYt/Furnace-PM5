<?php

namespace Lunarium\Command\Admin;

use libIPGeolocation\IPGeolocation;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\args\RawStringArgument;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;

class IPLookupCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new RawStringArgument("ip", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez accès à cette commande");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!isset($args["ip"])) {
            $sender->sendMessage(Utils::PREFIX . "§c" . $this->getUsage());
            return;
        }

        $ip = $args["ip"];
        $country = IPGeolocation::getCountry($ip);
        $continent = IPGeolocation::getContinent($ip);
        $continentCode = IPGeolocation::getContinentCode($ip);
        $city = IPGeolocation::getCity($ip);
        $countryCode = IPGeolocation::getCountryCode($ip);
        $district = IPGeolocation::getDistrict($ip);
        $region = IPGeolocation::getRegion($ip);
        $status = IPGeolocation::getStatus($ip);
        $isProxy = IPGeolocation::isProxy($ip);
        $timezone = IPGeolocation::getLocation($ip, "timezone");
        $regionName = IPGeolocation::getLocation($ip, "regionName");

        $sender->sendMessage(Utils::PREFIX . "§fInformation sur l'IP §d{$ip}");
        $sender->sendMessage("§fPays: §d{$country}");
        $sender->sendMessage("§fContinent: §d{$continent}");
        $sender->sendMessage("§fCode du continent: §d{$continentCode}");
        $sender->sendMessage("§fVille: §d{$city}");
        $sender->sendMessage("§fCode du pays: §d{$countryCode}");
        $sender->sendMessage("§fDistrict: §d{$district}");
        $sender->sendMessage("§fRégion: §d{$region}");
        $sender->sendMessage("§fStatut: §d{$status}");
        $sender->sendMessage("§fTimezone: §d{$timezone}");
        $sender->sendMessage("§fNom de la Région: §d{$regionName}");
        $sender->sendMessage("§fEst-ce un proxy: §d" . ($isProxy ? "Oui" : "Non"));
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}
