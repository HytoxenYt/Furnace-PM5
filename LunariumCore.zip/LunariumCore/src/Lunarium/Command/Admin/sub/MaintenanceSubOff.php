<?php

namespace Lunarium\Command\Admin\sub;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
class MaintenanceSubOff extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $maintenance = Main::getInstance()->maintenanceManager;

        $maintenance->setEnabled(false);
        $sender->sendMessage(Utils::PREFIX . "§fLe mode maintenance a été §cdésactivé");
    }
    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}