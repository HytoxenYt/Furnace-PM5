<?php

namespace Lunarium\Command\Admin\sub;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;

class MaintenanceSubList extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $maintenance = Main::getInstance()->maintenanceManager;

        $sender->sendMessage(implode("\n", [
            "§fListe des joueurs autorisés au mode maintenance :",
            count($maintenance->getList()) > 0 ? ("§d" . implode("§f, §d", $maintenance->getList())) : "§cAucun joueur"
        ]));

    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}