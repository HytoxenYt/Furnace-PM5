<?php

namespace Lunarium\Command\Admin\sub;

use CortexPE\Commando\BaseSubCommand;
use JsonException;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;

class MaintenanceSubOn extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
    }

    /**
     * @throws JsonException
     */
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $maintenance = Main::getInstance()->maintenanceManager;

        $maintenance->setEnabled(true);
        $sender->sendMessage(Utils::$prefix . "§fLe mode maintenance a été §aactivé");
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}