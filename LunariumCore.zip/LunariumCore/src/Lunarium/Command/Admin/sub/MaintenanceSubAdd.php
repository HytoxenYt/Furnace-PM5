<?php

namespace Lunarium\Command\Admin\sub;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseSubCommand;
use JsonException;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;

class MaintenanceSubAdd extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->registerArgument(0, new RawStringArgument("player", false));
    }

    /**
     * @throws JsonException
     */
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $maintenance = Main::getInstance()->maintenanceManager;

        $player = $args["player"] ?? null;

        if (is_null($player)) {
            $sender->sendMessage("§cUsage: /maintenance add <joueur>");
            return;
        }

        if ($maintenance->inList($player)) {
            $sender->sendMessage(Utils::PREFIX . "§fLe joueur §d" . $player . " §ffait déjà parti des joueurs autorisés au mode maintenance");
        } else {
            $maintenance->add($player);
            $sender->sendMessage(Utils::PREFIX . "§fLe joueur §d" . $player . " §fa été §aajouté §faux joueurs autorisés au mode maintenance");
        }
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}