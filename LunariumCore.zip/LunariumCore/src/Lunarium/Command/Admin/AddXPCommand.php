<?php

namespace Lunarium\Command\Admin;

use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\args\IntegerArgument;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class AddXPCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
        $this->registerArgument(1, new IntegerArgument("xp", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez accès à cette commande");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!isset($args["xp"])) {
            $sender->sendMessage(Utils::PREFIX . "§c/addxp <player> <xp>");
            return;
        }

        $xp = $args["xp"];
        $target = $args["player"] ?? $sender;

        if (!$target instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cLe joueur n'existe pas");
            return;
        }

        $target->getXpManager()->addXpLevels($xp);
        if ($target === $sender) {
            $sender->sendMessage(Utils::PREFIX . "§fVous avez ajouté §d" . $xp . " §fniveaux d'xp à vous-même");
        } else $sender->sendMessage(Utils::PREFIX . "§fVous avez ajouté §d" . $xp . " §fniveaux d'xp à §d" . $target->getName());

    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}