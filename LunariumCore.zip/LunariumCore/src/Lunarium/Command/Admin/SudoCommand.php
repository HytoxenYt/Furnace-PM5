<?php

declare(strict_types=1);

namespace Lunarium\Command\Admin;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class SudoCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
        $this->registerArgument(1, new RawStringArgument("command", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;

        if (!isset($args["player"]) || !isset($args["command"])) {
            $sender->sendMessage(Utils::PREFIX . "§c/sudo (joueur) (/commande)");
            return;
        }

        $player = Server::getInstance()->getPlayerByPrefix($args["player"]);
        if ($player instanceof Player) {
            $player->getServer()->dispatchCommand($player, $args["command"]);
            $sender->sendMessage(Utils::PREFIX . "§fLa commande §d{$args["command"]} §fa été exécutée par §d{$player->getName()}");
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cLe joueur indiqué n'est pas connecté");
        }
    }

    public function getPermission(): string
    {
        return "lunarium.sudo";
    }
}

