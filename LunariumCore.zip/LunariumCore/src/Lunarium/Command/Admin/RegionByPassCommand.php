<?php

namespace Lunarium\Command\Admin;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class RegionByPassCommand extends Command
{
    public function __construct()
    {
        parent::__construct("regionbypass", "Permet de contourner les resitrictions des régions");
        $this->setPermission("lunarium.admin");
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {

        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        if (!empty($args)) {
            $player = $args[0];

            if ($player instanceof Player) {
                if (Utils::bypassRegion($player)) {
                    Utils::setRegionBypass($player, false);
                    $player->sendMessage(Utils::PREFIX . "Le contournement des restrictions de zones a été §ddésactivé");
                    $sender->sendMessage(Utils::PREFIX . "Le contournement des restrictions de zones a été §ddésactivé§f pour §d" . $player->getName());
                } else {
                    Utils::setRegionBypass($player,true);
                    $player->sendMessage(Utils::PREFIX . "Le contournement des restrictions de zones a été §dactivé");
                    $sender->sendMessage(Utils::PREFIX . "Le contournement des restrictions de zones a été §dactivé§f pour §d" . $player->getName());
                }
            } else {
                $sender->sendMessage(Utils::PREFIX . "Le joueur spécifié n'est pas en ligne");
            }
        } else {
            if (Utils::bypassRegion($sender)) {
                Utils::setRegionBypass($sender, false);
                $sender->sendMessage(Utils::PREFIX . "Le contournement des restrictions de zones a été §ddésactivé");
            } else {
                Utils::setRegionBypass($sender,true);
                $sender->sendMessage(Utils::PREFIX . "Le contournement des restrictions de zones a été §dactivé");
            }
        }
    }
}
