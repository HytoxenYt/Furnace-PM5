<?php

namespace Lunarium\Command\Admin;

use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;

class AddRankCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new RawStringArgument("name", false));
        $this->registerArgument(1, new RawStringArgument("color", false));

        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!isset($args["name"]) || !isset($args["color"])) {
            $sender->sendMessage(Utils::PREFIX . "§c/addrank <name> <color>");
            return;
        }

        $name = $args["name"];
        $color = $args["color"];

        if (Main::getInstance()->existRank($name)) {
            $sender->sendMessage(Utils::PREFIX . "§fLe grade §d" . $name . "§f existe déjà");
            return;
        }

        Main::getInstance()->addRank($name, $color);
        $sender->sendMessage(Utils::PREFIX . "§fVous venez de créer le grade §d" . $name . "§f avec la couleur §d" . $color);
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}
