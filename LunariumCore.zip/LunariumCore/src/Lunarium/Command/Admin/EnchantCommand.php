<?php

namespace Lunarium\Command\Admin;

use jojoe77777\FormAPI\CustomForm;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\player\Player;

class EnchantCommand extends Command
{
    /** @var Enchantment[] */
    private array $enchants;
    private array $enchantSteps = [
        "0", "1", "2", "3", "4", "5",
        "6", "7", "8", "9", "10", "15",
        "20", "25", "30", "40", "50", "60",
        "70", "80", "90", "100", "200", "300",
        "500", "1000", "2000", "10000"
    ];

    public function __construct()
    {
        parent::__construct("enchant", "Permet d'enchanter un item", "/enchant <joueur>", ["ench"]);
        $this->setPermission("lunarium.admin");

        $enchantments = VanillaEnchantments::getAll();
        sort($enchantments);
        $this->enchants = $enchantments;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission d'utiliser cette commande");
            return;
        }

        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§cCette commande ne peut être exécutée uniquement en jeu");
            return;
        }

        if ($sender->getInventory()->getItemInHand()->getTypeId() !== 0) {
            $this->openEnchantForm($sender);
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez avoir en main un objet à enchanter");
        }
    }

    public function openEnchantForm(Player $player, bool $close = true): void
    {
        $form = new CustomForm(function (Player $player, $data) {
            if (!is_array($data)) return;
            if (count($data) != 4) return;
            /** @var int $enchantKey */
            $enchantKey = $data[1] - 1;
            $level = intval($this->enchantSteps[$data[2]]);
            $keepOpened = boolval($data[3]);

            $item = $player->getInventory()->getItemInHand();

            if ($enchantKey === -1) {
                $player->sendMessage(Utils::PREFIX . "§cAucune modification n'a été apportée à §d" . $item->getVanillaName());
                return;
            }

            $enchant = array_values($this->enchants)[$enchantKey];
            if ($level === 0) {
                if ($item->hasEnchantment($enchant)) {
                    $item->removeEnchantment($enchant);
                    $player->sendMessage(Utils::PREFIX . "§fL'enchantement §d" . array_keys($this->enchants)[$enchantKey] . " §ca été retiré de §d" . $item->getVanillaName());
                    $player->getInventory()->setItemInHand($item);
                } else {
                    $player->sendMessage(Utils::PREFIX . "§fAucune modification n'a été apportée à §f" . $item->getVanillaName());
                }
                return;
            } else {
                $item->addEnchantment(new EnchantmentInstance($enchant, $level));
                $player->getInventory()->setItemInHand($item);
                $player->sendMessage(Utils::PREFIX . "§fL'enchantement §d" . array_keys($this->enchants)[$enchantKey] . " §fde §dniveau " . $level . " §fa été appliqué à §d" . $item->getVanillaName());
            }

            if ($keepOpened) $this->openEnchantForm($player, false);
        });

        $itemName = $player->getInventory()->getItemInHand()->getVanillaName();
        $form->setTitle("§dEnchantement");
        $form->addLabel("Choisissez l'enchantement à appliquer sur §d$itemName");
        $form->addDropdown("Enchantement :", array_merge(["Ne rien modifier"], array_keys($this->enchants)), 0);
        $form->addStepSlider("Niveau :", $this->enchantSteps, 0);
        $form->addToggle("Ne pas fermer", !$close);
        $player->sendForm($form);
    }
}
