<?php

namespace Lunarium\Command\Admin;

use Lunarium\Main;
use Lunarium\Tasks\PlayerTask;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class ClearLagForceCommand extends Command
{

    public function __construct()
    {
        parent::__construct("clearlagforce", "Pouvoir forcer le clearlag", "/clearlagforce");
        $this->setPermission("lunarium.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if(!$sender->hasPermission($this->getPermissions()[0])){
            $sender->sendMessage(Utils::PREFIX."§cVous n'avez accès a cette commande");
            return;
        }
        if(!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX."§cVous devez être un joueur");
            return;
        }

        PlayerTask::execute(Main::getInstance());
        $sender->sendMessage(Utils::PREFIX . "§fLe clearlag à été forcé");
    }
}