<?php

namespace Lunarium\Command\Admin;

use CortexPE\Commando\BaseCommand;
use Lunarium\Command\Admin\sub\MaintenanceSubAdd;
use Lunarium\Command\Admin\sub\MaintenanceSubList;
use Lunarium\Command\Admin\sub\MaintenanceSubOff;
use Lunarium\Command\Admin\sub\MaintenanceSubOn;
use Lunarium\Command\Admin\sub\MaintenanceSubRemove;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;

class MaintenanceCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez accès à cette commande");
        $this->registerSubCommand(new MaintenanceSubAdd("add"));
        $this->registerSubCommand(new MaintenanceSubList("list"));
        $this->registerSubCommand(new MaintenanceSubOff("off"));
        $this->registerSubCommand(new MaintenanceSubOn("on"));
        $this->registerSubCommand(new MaintenanceSubRemove("remove"));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $maintenance = Main::getInstance()->maintenanceManager;

        $sender->sendMessage(Utils::PREFIX . "§fÉtat: " .  ($maintenance->isEnabled() ? "§aActivé" : "§cDésactivé"));
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}
