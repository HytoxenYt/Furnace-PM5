<?php

namespace Lunarium\Command\Admin;

use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\ModalForm;
use jojoe77777\FormAPI\SimpleForm;
use Lunarium\Main;
use Lunarium\Utils\Region;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class RegionCommand extends Command {
    
    public function __construct() {
        parent::__construct("region", "Permet de gérer les régions");
        $this->setPermission("lunarium.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§dVous n'avez accès a cette commande");
            return;
        }

        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§dVous devez être un joueur pour utiliser cette commande");
            return;
        }

        $this->openRegionSelector($sender);
    }

    private function openRegionSelector(Player $player): void
    {
        $regions = array_values(Main::getInstance()->getRegionManager()->getAll());
        $regionLabels = array_map(function (Region $region) {
            $typeLabel = $region->isWorldRegion() ? "Monde" : ($region->isExtendedVertically() ? "Sélection verticale" : "Sélection");
            return $region->getName() . " §d(" . $typeLabel . ") §f| §d". $region->getWorldName() . " §f| §". "Priorité : §d" . $region->getPriority();
        }, $regions);
        array_unshift($regionLabels, "§f[§a+§f] §d" . "Nouvelle région§f");

        $form = new SimpleForm(function (Player $player, $data) use ($regions) {
            if (!is_int($data)) return;
            if ($data === 0) {
                $this->openRegionCreator($player);
            } else {
                $this->openRegionMenu($player, $regions[$data - 1]->getName());
            }
        });
        $message = "§l» §dGESTION DES REGIONS §r§l«";
        $form->setTitle($message);

        $form->setContent("Sélectionnez une région à modifier");
        foreach ($regionLabels as $regionLabel) $form->addButton($regionLabel);
        $player->sendForm($form);
    }

    private function openRegionCreator(Player $player): void
    {
        $form = new CustomForm(function (Player $player, $data) {
            if (!is_array($data)) return;
            if (!is_string($data[1]) || !is_int($data[2])) return;

            $name = $data[1];
            $selection = $data[2];

            if (empty($name)) {
                $player->sendMessage(Utils::PREFIX . "§cVeuillez saisir le nom de la région");
                return;
            }

            if (Main::getInstance()->getRegionManager()->get($name)) {
                $player->sendMessage(Utils::PREFIX . "§cUne autre région portant le même nom existe déjà");
                return;
            }

            $worldRegion = Main::getInstance()->getRegionManager()->getWorldRegion($player->getWorld());
            if ($selection === 0 && $worldRegion) {
                $player->sendMessage(Utils::PREFIX . "§cUne région a déjà été définie pour ce monde. Il s'agit de §d" . $worldRegion->getName() );
                return;
            }

            if ($selection === 0) {
                Main::getInstance()->getRegionManager()->add(new Region(Main::getInstance()->getRegionManager(), $name, 0, $player->getWorld()->getDisplayName()));
                $player->sendMessage(Utils::PREFIX . "La région a été créée");
            } else {
                Utils::setRegionSelection(
                    $player,
                    new Region(Main::getInstance()->getRegionManager(), $name, 0, $player->getWorld()->getDisplayName(), null, null, $selection === 2)
                );
                $player->sendMessage(Utils::PREFIX . "Veuillez sélectionner les bordures de la région");
            }
        });

        $form->setTitle("§l» §dGESTION DES REGIONS §r§l«");
        $form->addLabel("Vous allez créer une nouvelle région");
        $form->addInput("Nom", "Nom de la région");
        $form->addDropdown("Paramètre de sélection", ["Monde entier", "Sélection normale", "Sélection étendue verticalement"], 1);
        $player->sendForm($form);
    }

    private function openRegionMenu(Player $player, string $regionName): void
    {
        $region = Main::getInstance()->getRegionManager()->get($regionName);
        if (!$region) {
            $message = Utils::PREFIX . "§cLa region §d$regionName §fn'existe pas";
            $player->sendMessage($message);
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($regionName) {
            if (!is_int($data)) return;
            if (!Main::getInstance()->getRegionManager()->get($regionName)) {
                $message = Utils::PREFIX . "§cLa region §d$regionName §fn'existe pas";
                $player->sendMessage($message);
                return;
            }

            if ($data === 0) {
                $this->openRegionRename($player, $regionName);
            } elseif ($data === 1) {
                $this->openRegionPrioritySlider($player, $regionName);
            } elseif ($data === 2) {
                $this->openRegionFlagEditor($player, $regionName);
            } elseif ($data === 3) {
                $player->sendMessage(Utils::PREFIX . "Si vous souhaitez faire cela, supprimez la région et créez-en une autre avec les bonnes positions");
            } elseif ($data === 4) {
                $this->openRegionDeleteConfirm($player, $regionName);
            }
        });

        $form->setTitle("§l» §dGESTION DES REGIONS §r§l«");
        $form->setContent("Région : §d" . $region->getName() . "§f | §dType : " . ($region->isWorldRegion() ? "Monde" : ($region->isExtendedVertically() ? "Sélection verticale" : "Sélection")) . "§f | §dMonde : " . $region->getWorldName() . " §f| §dPriorité : " . $region->getPriority());
        $form->addButton("Renommer", SimpleForm::IMAGE_TYPE_PATH, "textures/items/name_tag");
        $form->addButton("Modifier la priorité", SimpleForm::IMAGE_TYPE_PATH, "textures/items/redstone_dust");
        $form->addButton("Éditer les attributs", SimpleForm::IMAGE_TYPE_PATH, "textures/items/book_writable");
        $form->addButton("Modifier la zone", SimpleForm::IMAGE_TYPE_PATH, "textures/items/arrow");
        $form->addButton("§dSUPPRIMER§f", SimpleForm::IMAGE_TYPE_PATH, "textures/items/bucket_lava");
        $player->sendForm($form);
    }

    private function openRegionRename(Player $player, string $regionName): void
    {
        $form = new CustomForm(function (Player $player, $data) use ($regionName) {
            if (!is_array($data)) return;

            $region = Main::getInstance()->getRegionManager()->get($regionName);
            if (!$region) {
                $message = Utils::PREFIX . "§cLa region §d$regionName §fn'existe pas";
                $player->sendMessage($message);
                return;
            }

            $name = $data[0];
            if (!is_string($name)) return;
            if (empty($name) || strtolower($name) === strtolower($regionName)) return;

            if ($region->setName($name)) {
                $player->sendMessage(Utils::PREFIX . "La région §f" . $regionName . " §fa été renommée §f" . $name );
            } else {
                $player->sendMessage(Utils::PREFIX . "§cUne autre région portant le même nom §d" . $name . " §cexiste déjà");
            }
        });

        $form->setTitle("§l» §dGESTION DES REGIONS §r§l«");
        $form->addInput("Nom", $regionName, $regionName);
        $player->sendForm($form);
    }

    private function openRegionPrioritySlider(Player $player, string $regionName): void
    {
        $region = Main::getInstance()->getRegionManager()->get($regionName);
        if (!$region) {
            $message = Utils::PREFIX . "§cLa region §d$regionName §cn'existe pas";
            $player->sendMessage($message);
            return;
        }

        $form = new CustomForm(function (Player $player, $data) use ($regionName) {
            if (!is_array($data)) return;
            if (count($data) !== 2) return;

            $region = Main::getInstance()->getRegionManager()->get($regionName);
            if (!$region) {
                $message = Utils::PREFIX . "§cLa region §d$regionName §cn'existe pas";
                $player->sendMessage($message);
                return;
            }

            $priority = intval($data[1]);
            if ($priority === $region->getPriority()) return;

            $region->setPriority($priority);
            $region->getManager()->save();

            $player->sendMessage(Utils::PREFIX . "La priorité de la région §d" . $region->getName() . " §fa été définie sur §d" . $region->getPriority() );
        });

        $form->setTitle("§l» §dGESTION DES REGIONS §r§l«");
        $form->addLabel("Région : §d" . $region->getName());
        $form->addStepSlider("Priorité", ["0", "1", "2", "3", "4", "5"], $region->getPriority());
        $player->sendForm($form);
    }

    private function openRegionFlagEditor(Player $player, string $regionName): void
    {
        $region = Main::getInstance()->getRegionManager()->get($regionName);
        if (!$region) {
            $message = Utils::PREFIX . "§cLa region §d$regionName §cn'existe pas";
            $player->sendMessage($message);
            return;
        }

        $form = new CustomForm(function (Player $player, $data) use ($regionName) {
            if (!is_array($data)) return;
            $region = Main::getInstance()->getRegionManager()->get($regionName);
            if (!$region) {
                $message = Utils::PREFIX . "§cLa region §d$regionName §cn'existe pas";
                $player->sendMessage($message);
                return;
            }

            $flags = [];
            foreach (array_splice($data, 1, count($data) - 1) as $i => $value) {
                $flagPropertyName = array_keys(Region::FLAG_PROPERTIES)[$i];
                $flagProperty = Region::FLAG_PROPERTIES[$flagPropertyName];
                if ($flagProperty[1] === Region::TYPE_BOOL) {
                    $flags[$flagPropertyName] = boolval($value);
                } elseif ($flagProperty[1] === Region::TYPE_INT) {
                    $flags[$flagPropertyName] = intval($value);
                } elseif ($flagProperty[1] === Region::TYPE_STRING) {
                    $flags[$flagPropertyName] = strval($value);
                }
            }

            $region->setFlags($flags);
            $region->getManager()->save();

            $player->sendMessage(Utils::PREFIX . "Les attributs de la région §d" . $regionName . " §font été sauvegardés");
        });

        $form->setTitle("§l» §dGESTION DES REGIONS §r§l«");
        $form->addLabel("Région sélectionnée : §d" . $regionName . " §f| §dType : " . ($region->isWorldRegion() ? "Monde" : ($region->isExtendedVertically() ? "Sélection verticale" : "Sélection")));

        foreach ($region->getFlags() as $flag => $value) {
            $flagName = Region::FLAG_PROPERTIES[$flag][0];

            if ($flag === Region::FLAG_GAMEMODE) {
                $form->addStepSlider($flagName, ["Survie", "Créatif", "Aventure", "Spectateur"], intval($value));
                continue;
            }

            if (is_bool($value)) {
                $form->addToggle($flagName, $value);
            } else {
                $form->addInput($flagName, "Laisser vide si désactivé", strval($value));
            }
        }

        $player->sendForm($form);
    }

    private function openRegionDeleteConfirm(Player $player, string $regionName): void
    {
        $confirm = new ModalForm(function (Player $player, $data) use ($regionName) {
            if (!is_bool($data)) return;
            if ($data === true) {
                if (Main::getInstance()->getRegionManager()->remove($regionName)) {
                    $player->sendMessage(Utils::PREFIX . "La région §d" . $regionName . " §fa été §dsupprimée§f");
                } else {
                    $player->sendMessage(Utils::PREFIX . "§cUne erreur est survenue lors de la suppression de la région");
                }
            }
        });
        $confirm->setTitle("§dCONFIRMATION");
        $confirm->setContent("Êtes-vous sûr de vouloir supprimer la région §d" . $regionName . "§r ?");
        $confirm->setButton1("§4§lSUPPRIMER");
        $confirm->setButton2("§a§lANNULER");
        $player->sendForm($confirm);
    }
}
