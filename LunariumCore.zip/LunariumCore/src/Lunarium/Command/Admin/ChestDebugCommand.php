<?php

namespace Lunarium\Command\Admin;

use Lunarium\Utils\Utils;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

class ChestDebugCommand extends Command
{
    public function __construct()
    {
        parent::__construct("chestdebug", "Permet de débug un coffre", "/chestdebug");
        $this->setPermission("lunarium.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if($sender instanceof Player){
            $inv = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
            $inv->setName("§dChest Debug");

            $contents = [];
            for ($i = 0; $i < 6 * 9; $i++){
                $contents[$i] = VanillaItems::STICK()->setCount($i)->setCustomName("§l§d".$i);
            }
            $inv->getInventory()->setContents($contents);
            $inv->setListener(Invmenu::readonly());
            $inv->send($sender);
        }
    }
}