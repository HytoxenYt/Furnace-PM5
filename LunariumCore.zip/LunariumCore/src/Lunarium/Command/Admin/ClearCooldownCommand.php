<?php

declare(strict_types=1);

namespace Lunarium\Command\Admin;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Cooldown;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class ClearCooldownCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
        $this->registerArgument(1, new RawStringArgument("cooldown", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $player = $args["player"] ?? null;
        $cooldown = $args["cooldown"];

        if (is_null($player)) {
            $sender->sendMessage(Utils::PREFIX . "§cLe joueur n'existe pas");
            return;
        }
        if (!$player instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cLe joueur n'existe pas");
            return;
        }

        $cooldowns = Utils::getCooldown()->getAll();

        $xuid = $player->getXuid();

        if (!isset($cooldowns[$xuid]) || empty($cooldowns[$xuid])) {
            $sender->sendMessage(Utils::PREFIX . "§d" . $player->getName() . "§f à aucun cooldown");
            return;
        }

        $sender->sendMessage(Utils::PREFIX . "§fVoici vos cooldowns actifs");
        foreach ($cooldowns[$xuid] as $type => $timestamp) {
            if($cooldown == $type){
                $sender->sendMessage(Utils::PREFIX . "§fVous avez supprimé le cooldown §d$cooldown §fde §d" . $player->getName());
                $player->sendMessage(Utils::PREFIX . "§d" . $sender->getName() . "§f vous à supprimé le cooldown §d$cooldown");
                if(Utils::getCooldown()->has($player->getXuid(), $cooldown)) Utils::getCooldown()->remove($player->getXuid(), $cooldown);
            }
        }
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}