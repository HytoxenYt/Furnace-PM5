<?php

namespace Lunarium\Command\Admin;

use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\args\PlayerArgument;
use Lunarium\Listener\Events\PlayerRankEv;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class SetRankCommand extends BaseCommand
{
    public function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
        $this->registerArgument(1, new RawStringArgument("rank", true));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez accès à cette commande");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        $player = $args["player"];
        $rank = $args["rank"];

        $player = Server::getInstance()->getPlayerByPrefix($player);

        if (!$player instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cLe joueur spécifié n'est pas en ligne");
            return;
        }

        if (!Main::getInstance()->existPlayer($player->getName())) {
            $sender->sendMessage(Utils::PREFIX . "§cLe joueur n'existe pas");
            return;
        }

        if (!Main::getInstance()->existRank($rank)) {
            $sender->sendMessage(Utils::PREFIX . "§cLe grade spécifié n'existe pas");
            return;
        }

        Main::getInstance()->setRank($player->getName(), $rank);
        $sender->sendMessage(Utils::PREFIX . "§fVous avez défini le grade §d{$rank}§f au joueur §d" . $player->getName());
        PlayerRankEv::updateNameTag($player);
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}
