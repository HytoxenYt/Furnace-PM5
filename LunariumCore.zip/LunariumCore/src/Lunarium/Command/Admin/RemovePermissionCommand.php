<?php

namespace Lunarium\Command\Admin;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class RemovePermissionCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
        $this->registerArgument(1, new RawStringArgument("permission", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
    }


    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!isset($args["player"]) || !isset($args["permission"])) {
            $sender->sendMessage(Utils::PREFIX . "§c/addpermission <player> <permission>");
            return;
        }

        $playerName = $args["player"];
        $permission = $args["permission"];

        $player = Server::getInstance()->getPlayerByPrefix($playerName);
        $name = $player instanceof Player ? $player->getName() : $playerName;

        if (!Main::getInstance()->existPlayer($name)) {
            $sender->sendMessage(Utils::PREFIX . "§fLe joueur §d" . $name . "§f n'existe pas");
            return;
        }

        Main::getInstance()->removePermission($name, $permission, true);
        $sender->sendMessage(Utils::PREFIX . "Vous avez retiré la permission §d" . $permission . "§f au joueur §d" . $name);
    }

    public function getPermission(): string
    {
        return "lunarium.admin";
    }
}
