<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class ReplyCommand extends Command
{

    public function __construct()
    {
        parent::__construct("reply", "Répondre à un message", "/reply <message>", ["r"]);
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        if (!empty(MessageCommand::$msg[$sender->getName()])) {
            $player = Server::getInstance()->getPlayerByPrefix(MessageCommand::$msg[$sender->getName()]);
            if ($player instanceof Player) {
                if (isset($args[0])) {
                    $msg = "";
                    for ($i = 0; $i < count($args); $i++) {
                        $msg .= $args[$i];
                        $msg .= " ";
                    }
                    $player->sendMessage("§f[§d{$sender->getName()}§f[ -> [§dMoi§f] : {$msg}");
                    $sender->sendMessage("§f[§dMoi§f] -> [§d{$player->getName()}§f] : {$msg}");
                } else $sender->sendMessage(Utils::PREFIX . "§cVeuillez entrer un message");
            } else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'existe pas");
        } else $sender->sendMessage(Utils::PREFIX . "§cVous avez pas de messages récents");
    }
}