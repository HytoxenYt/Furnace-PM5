<?php

namespace Lunarium\Command\Player;

use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;
use Lunarium\Main;
use Lunarium\Managers\MoneyManager;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class ShopCommand extends Command
{
    public function __construct()
    {
        parent::__construct("shop", "Permet d'acheter dans le shop", "/shop");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
            return;
        }

        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        $this->sendShopSellOrBuy($sender);
    }

    public function sendShopAgricultures(Player $player, bool $isSelling): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "shop.yml", Config::YAML);
        $Agricultures = $config->get("Agricultures");

        if ($Agricultures === false || !is_array($Agricultures)) {
            $player->sendMessage(Utils::PREFIX . "§cAucune donnée de Agricultures trouvée dans le fichier de configuration");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($Agricultures, $isSelling) {
            if ($data === null) return;

            $index = $data;
            if (!isset($Agricultures[$index])) {
                $player->sendMessage(Utils::PREFIX . "§cAgricultures invalide sélectionné");
                return;
            }

            $exp = explode("&", $Agricultures[$index]);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le Agricultures: " . $Agricultures[$index]);
                return;
            }

            $itemString = $exp[0];
            $name = $exp[1];
            $price_sell = (int)$exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];

            $item = StringToItemParser::getInstance()->parse($itemString);

            $this->sendItem($player, $price_sell, $price_buy, $item, $name, $isSelling);
        });

        $form->setTitle("§dShop");
        $form->setContent("Vous avez §d" . MoneyManager::getMoneyPlayer($player) . "§f$");

        foreach ($Agricultures as $key => $value) {
            $exp = explode("&", $value);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le Agricultures: " . $value);
                continue;
            }

            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];

            if ($isSelling) {
                if($price_sell === "0"){
                    $form->addButton("§d$name \n§cVente: Pas vendable", 0, $texture);
                }else{
                    $form->addButton("§d$name \n§aVente: $price_sell". "§f$", 0, $texture);
                }
            } else {
                if ($price_buy === "0") {
                    $form->addButton("§d$name \n§cAchat: Pas achetable", 0, $texture);
                } else {
                    $form->addButton("§d$name \n§cAchat: $price_buy". "§f$", 0, $texture);
                }
            }
        }

        $form->sendToPlayer($player);
    }


    public function sendShopBlocks(Player $player, bool $isSelling): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "shop.yml", Config::YAML);
        $Blocks = $config->get("Blocks");

        if ($Blocks === false || !is_array($Blocks)) {
            $player->sendMessage(Utils::PREFIX . "§cAucune donnée de Blocks trouvée dans le fichier de configuration");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($Blocks, $isSelling) {
            if ($data === null) return;

            $index = $data;
            if (!isset($Blocks[$index])) {
                $player->sendMessage(Utils::PREFIX . "§cBlocks invalide sélectionné");
                return;
            }

            $exp = explode("&", $Blocks[$index]);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le Blocks: " . $Blocks[$index]);
                return;
            }

            $itemString = $exp[0];
            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];


            $item = StringToItemParser::getInstance()->parse($itemString);

            $this->sendItem($player, $price_sell, $price_buy, $item, $name, $isSelling);
        });

        $form->setTitle("§dShop");
        $form->setContent("Vous avez §d" . MoneyManager::getMoneyPlayer($player) . "§f$");

        foreach ($Blocks as $key => $value) {
            $exp = explode("&", $value);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le Blocks: " . $value);
                continue;
            }

            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];

            if ($isSelling) {
                if($price_sell === "0"){
                    $form->addButton("§d$name \n§cVente: Pas vendable", 0, $texture);
                }else{
                    $form->addButton("§d$name \n§aVente: $price_sell". "§f$", 0, $texture);
                }
            } else {
                if ($price_buy === "0") {
                    $form->addButton("§d$name \n§cAchat: Pas achetable", 0, $texture);
                } else {
                    $form->addButton("§d$name \n§cAchat: $price_buy". "§f$", 0, $texture);
                }
            }
        }

        $form->sendToPlayer($player);
    }

    public function sendShopColorant(Player $player, bool $isSelling): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "shop.yml", Config::YAML);
        $colorant = $config->get("Colorant");

        if ($colorant === false || !is_array($colorant)) {
            $player->sendMessage(Utils::PREFIX . "§cAucune donnée de minerais trouvée dans le fichier de configuration");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($colorant, $isSelling) {
            if ($data === null) return;

            $index = $data;
            var_dump($data);
            if (!isset($colorant[$index])) {
                $player->sendMessage(Utils::PREFIX . "§cColorant invalide sélectionné");
                return;
            }

            $exp = explode("&", $colorant[$index]);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le Colorant: " . $colorant[$index]);
                return;
            }

            $itemString = $exp[0];
            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];


            $item = StringToItemParser::getInstance()->parse($itemString);

            $this->sendItem($player, $price_sell, $price_buy, $item, $name, $isSelling);
        });

        $form->setTitle("§dShop");
        $form->setContent("Vous avez §d" . MoneyManager::getMoneyPlayer($player) . "§f$");

        foreach ($colorant as $key => $value) {
            $exp = explode("&", $value);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le Colorant: " . $value);
                continue;
            }

            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];

            if ($isSelling) {
                if($price_sell === "0"){
                    $form->addButton("§d$name \n§cVente: Pas vendable", 0, $texture);
                }else{
                    $form->addButton("§d$name \n§aVente: $price_sell". "§f$", 0, $texture);
                }
            } else {
                if ($price_buy === "0") {
                    $form->addButton("§d$name \n§cAchat: Pas achetable", 0, $texture);
                } else {
                    $form->addButton("§d$name \n§cAchat: $price_buy". "§f$", 0, $texture);
                }
            }
        }

        $form->sendToPlayer($player);
    }

    public function sendShopHomeSelling(Player $player): void
    {
        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) return;

            switch ($data) {
                case 0:
                    $this->sendShopBois($player, true);
                    break;
                case 1:
                    $this->sendShopMinerais($player, true);
                    break;
                case 2:
                    $this->sendShopColorant($player, true);
                    break;
                case 3:
                    $this->sendShopBlocks($player, true);
                    break;
                case 4:
                    $this->sendShopAgricultures($player, true);
                    break;
                default:
                    break;
            }
        });
        $form->setTitle("§dShop");
        $form->addButton("Bois");
        $form->addButton("Minerais");
        $form->addButton("Colorant");
        $form->addButton("Blocks");
        $form->addButton("Agricultures");
        $form->sendToPlayer($player);
    }
    public function sendShopHomeBuying(Player $player): void
    {
        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) return;

            switch ($data) {
                case 0:
                    $this->sendShopBois($player, false);
                    break;
                case 1:
                    $this->sendShopMinerais($player, false);
                    break;
                case 2:
                    $this->sendShopColorant($player, false);
                    break;
                case 3:
                    $this->sendShopBlocks($player, false);
                    break;
                case 4:
                    $this->sendShopAgricultures($player, false);
                    break;
                default:
                    break;
            }
        });
        $form->setTitle("§dShop");
        $form->addButton("Bois");
        $form->addButton("Minerais");
        $form->addButton("Colorant");
        $form->addButton("Blocks");
        $form->addButton("Agricultures");
        $form->sendToPlayer($player);
    }
    public function sendShopSellOrBuy(Player $player): void
    {
        $simpleForm = new SimpleForm(function (Player $player, $data) {
            if ($data === null) return;

            switch ($data) {
                case 0:
                    $this->sendShopHomeBuying($player);
                    break;
                case 1:
                    $this->sendShopHomeSelling($player);
                    break;
            }
        });

        $simpleForm->setTitle("§dShop");
        $simpleForm->addButton("Acheter");
        $simpleForm->addButton("Vendre");
        $simpleForm->sendToPlayer($player);
    }

    public function sendShopMinerais(Player $player, bool $isSelling): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "shop.yml", Config::YAML);
        $minerais = $config->get("Minerais");

        if ($minerais === false || !is_array($minerais)) {
            $player->sendMessage(Utils::PREFIX . "§cAucune donnée de minerais trouvée dans le fichier de configuration");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($minerais, $isSelling) {
            if ($data === null) return;

            $index = $data;

            if (!isset($minerais[$index])) {
                $player->sendMessage(Utils::PREFIX . "§cMinerai invalide sélectionné");
                return;
            }

            $exp = explode("&", $minerais[$index]);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le minerai: " . $minerais[$index]);
                return;
            }

            $itemString = $exp[0];
            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];

            if($price_buy === "0" || $price_sell === "0"){
                return;
            }

            $item = StringToItemParser::getInstance()->parse($itemString);

            $this->sendItem($player, (int) $price_sell, (int) $price_buy, $item, $name, $isSelling);
        });

        $form->setTitle("§dShop");
        $form->setContent("Vous avez §d" . MoneyManager::getMoneyPlayer($player) . "§f$");

        foreach ($minerais as $key => $value) {
            $exp = explode("&", $value);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le minerai: " . $value);
                continue;
            }

            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];

            if ($isSelling) {
                if($price_sell === "0"){
                    $form->addButton("§d$name \n§cVente: Pas vendable", 0, $texture);
                }else{
                    $form->addButton("§d$name \n§aVente: $price_sell". "§f$", 0, $texture);
                }
            } else {
                if ($price_buy === "0") {
                    $form->addButton("§d$name \n§cAchat: Pas achetable", 0, $texture);
                } else {
                    $form->addButton("§d$name \n§cAchat: $price_buy". "§f$", 0, $texture);
                }
            }
        }

        $form->sendToPlayer($player);
    }

    public function sendShopBois(Player $player, bool $isSelling): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "shop.yml", Config::YAML);
        $bois = $config->get("Bois");

        if ($bois === false || !is_array($bois)) {
            $player->sendMessage(Utils::PREFIX . "§cAucune donnée de bois trouvée dans le fichier de configuration");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($bois, $isSelling) {
            if ($data === null) return;

            $index = $data;
            if (!isset($bois[$index])) {
                $player->sendMessage(Utils::PREFIX . "§cbois invalide sélectionné");
                return;
            }

            $exp = explode("&", $bois[$index]);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le bois: " . $bois[$index]);
                return;
            }

            $itemString = $exp[0];
            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];

            if($price_buy === "0") {
                $player->sendMessage(Utils::PREFIX . "§cCe bois n'est pas achetable");
                return;
            }

            if($price_sell === "0") {
                $player->sendMessage(Utils::PREFIX . "§cCe bois n'est pas vendable");
                return;
            }
            $item = StringToItemParser::getInstance()->parse($itemString);

            $this->sendItem($player, $price_sell, $price_buy, $item, $name, $isSelling);
        });

        $form->setTitle("§dShop");
        $form->setContent("Vous avez §d" . MoneyManager::getMoneyPlayer($player) . "§f$");

        foreach ($bois as $key => $value) {
            $exp = explode("&", $value);
            if (count($exp) < 5) {
                $player->sendMessage(Utils::PREFIX . "§cFormat de données invalide pour le bois: " . $value);
                continue;
            }

            $name = $exp[1];
            $price_sell = $exp[2];
            $texture = $exp[3];
            $price_buy = $exp[4];

            if ($isSelling) {
                if($price_sell === "0"){
                    $form->addButton("§d$name \n§cVente: Pas vendable", 0, $texture);
                }else{
                    $form->addButton("§d$name \n§aVente: $price_sell". "§f$", 0, $texture);
                }
            } else {
                if ($price_buy === "0") {
                    $form->addButton("§d$name \n§cAchat: Pas achetable", 0, $texture);
                } else {
                    $form->addButton("§d$name \n§cAchat: $price_buy". "§f$", 0, $texture);
                }

            }
        }

        $form->sendToPlayer($player);
    }

    public function sendItem(Player $player, int $price_sell, int $price_buy, Item $item, string $name, bool $isSelling): void
    {
        $customForm = new CustomForm(function (Player $player, $data) use ($price_sell, $price_buy, $item, $name, $isSelling) {
            if ($data === null) return;

            $quantity = (int)$data[1];

            if ($isSelling) {
                $price = $price_sell;
                $totalCost = $price * $quantity;

                $countInInventory = Utils::getItemInInventory($player, $item);
                if ($countInInventory < $quantity) {
                    $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez d'objets à vendre");
                    return;
                }

                $player->getInventory()->removeItem($item->setCount($quantity));
                MoneyManager::addMoney($player, $totalCost);
                $player->sendMessage(Utils::PREFIX . "§fVous avez vendu §d" . $quantity . "x " . $name . "§f pour §d" . $totalCost . "§f$");

                $this->sendItem($player, $price_sell, $price_buy, $item, $name, $isSelling);
            } else {
                $price = $price_buy;
                $totalCost = $price * $quantity;

                if ($totalCost > MoneyManager::getMoneyPlayer($player)) {
                    $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez d'argent");
                    return;
                }

                $item->setCount($quantity);
                if ($player->getInventory()->canAddItem($item)) {
                    $player->getInventory()->addItem($item);
                    MoneyManager::removeMoney($player, $totalCost);
                    $player->sendMessage(Utils::PREFIX . "§fVous avez acheté §d" . $quantity . "x " . $name . "§f pour §d" . $totalCost . "§f$");
                } else {
                    $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez de place dans votre inventaire");
                }

                $this->sendItem($player, $price_sell, $price_buy, $item, $name, $isSelling);

            }
        });

        $customForm->setTitle("§dShop §f- §d" . $name);
        $customForm->addLabel("§fVous avez §d" . MoneyManager::getMoneyPlayer($player) . "\n" .
            "§fPrix: §d" . ($isSelling ? $price_sell : $price_buy) . "\n" .
            "§fVous pouvez en " . ($isSelling ? "vendre" : "acheter") . " au maximum: §d" . floor(($isSelling ? Utils::getItemInInventory($player, $item) : MoneyManager::getMoneyPlayer($player)) / ($isSelling ? 1 : $price_buy)) . "\n" .
            "§fVous avez §d" . Utils::getItemInInventory($player, $item) . "x " . $name . " §fdans votre inventaire");
        $customForm->addSlider("Combien en voulez-vous " . ($isSelling ? "vendre" : "acheter") . " ?", 1, 64, 1);
        $customForm->sendToPlayer($player);
    }
}
