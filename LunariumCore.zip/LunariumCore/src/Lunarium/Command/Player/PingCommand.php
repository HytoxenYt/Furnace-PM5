<?php

namespace Lunarium\Command\Player;

use CortexPE\Commando\args\OptionArgument;
use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class PingCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", true));
        $this->setPermission("lunarium.basic");
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande.");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!isset($args["player"])) {
            if ($sender instanceof Player) {
                $sender->sendMessage(Utils::PREFIX . "§fVous avez " . $this->ColorPing($sender->getNetworkSession()->getPing()));
            } else {
                $sender->sendMessage(Utils::PREFIX . "§cVeuillez spécifier un joueur.");
            }
            return;
        }

        if ($args["player"] === "all") {
            $onlinePlayers = Server::getInstance()->getOnlinePlayers();
            foreach ($onlinePlayers as $player) {
                $sender->sendMessage(Utils::PREFIX . "§d" . $player->getName() . "§f a " . $this->ColorPing($player->getNetworkSession()->getPing()));
            }
            return;
        }

        $player = Server::getInstance()->getPlayerByPrefix($args["player"]);
        if ($player !== null) {
            $sender->sendMessage(Utils::PREFIX . "§d" . $player->getName() . "§f a " . $this->ColorPing($player->getNetworkSession()->getPing()));
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cLe joueur §d" . $args["player"] . "§c n'existe pas ou n'est pas en ligne");
        }
    }

    private function ColorPing(int $ping): string
    {
        if ($ping >= 300) {
            return "§c" . $ping . " ms";
        } elseif ($ping >= 200) {
            return "§e" . $ping . " ms";
        } elseif ($ping >= 100) {
            return "§6" . $ping . " ms";
        } else {
            return "§a" . $ping . " ms";
        }
    }
    
    public function getPermission()
    {
        return "lunarium.basic";
    }
}
