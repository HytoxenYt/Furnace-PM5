<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\GameRulesChangedPacket;
use pocketmine\network\mcpe\protocol\types\BoolGameRule;
use pocketmine\player\Player;

class XYZCommand extends Command
{
    public bool $bool = false;

    public function __construct()
    {
        parent::__construct("xyz", "Permet d'activé les coordonnées", "/xyz");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof Player) return;

        if ($this->bool === false) {
            $this->bool = true;
            $sender->sendMessage(Utils::PREFIX . "§fVous affichez vos §dcoordonnées");
            $pk = new GameRulesChangedPacket();
            $pk->gameRules = ["showcoordinates" => new BoolGameRule(true, false)];
            $sender->getNetworkSession()->sendDataPacket($pk);
        } else {
            $this->bool = false;
            $sender->sendMessage(Utils::PREFIX . "§fVous cachez vos §dcoordonnées");
            $pk = new GameRulesChangedPacket();
            $pk->gameRules = ["showcoordinates" => new BoolGameRule(false, false)];
            $sender->getNetworkSession()->sendDataPacket($pk);
        }
    }
}