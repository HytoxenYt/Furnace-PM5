<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class EnderChestCommand extends Command
{

    public function __construct()
    {
        parent::__construct("ec", "Permet de voir votre ec", "/ec", ["enderchest"]);
        $this->setPermission("lunarium.ec");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if(!$sender->hasPermission($this->getPermissions()[0])){
            $sender->sendMessage(Utils::PREFIX."§cVous n'avez accès a cette commande");
            return;
        }

        if(!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX."§cVous devez être un joueur");
            return;
        }

        self::openEnderChest($sender);

    }
    private static function openEnderChest(Player $player): void{
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->setName("Ender Chest");
        $inv = $menu->getInventory();
        $inv->setContents($player->getEnderInventory()->getContents());
        $menu->setListener(function(InvMenuTransaction $transaction) use($player): InvMenuTransactionResult{
            $player->getEnderInventory()->setItem($transaction->getAction()->getSlot(), $transaction->getIn());
            return $transaction->continue();
        });
        $menu->send($player);
    }

}