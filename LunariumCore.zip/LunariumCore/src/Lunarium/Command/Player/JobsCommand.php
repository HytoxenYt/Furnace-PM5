<?php

namespace Lunarium\Command\Player;

use jojoe77777\FormAPI\SimpleForm;
use Lunarium\Managers\JobsManager;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;

class JobsCommand extends Command
{
    public function __construct()
    {
        parent::__construct("jobs", "Permet de voir les jobs", "/jobs", ["métier", "job"]);
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) return;

        $this->jobsMenu($sender);
    }

    public function jobsMenu(Player $player): void
    {
        $form = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;

            switch ($data) {
                case 0:
                    $this->jobsChoosed($player, "Mineur");
                    break;
                case 1:
                    $this->jobsChoosed($player, "Assassin");
                    break;
                case 2:
                    $this->jobsChoosed($player, "Fermier");
                    break;
            }
        });
        $form->setTitle("§dJobs");
        $form->setContent("§fAppuyez sur un des boutons ci-dessous pour voir vos statistiques et les informations du métier en question");
        $form->addButton("Mineur\n" . self::getProgressBar($player, "Mineur"), 0, "textures/ui/diamond_pickaxe");
        $form->addButton("Assassin\n" . self::getProgressBar($player, "Assassin"), 0, "textures/ui/diamond_sword");
        $form->addButton("Fermier\n" . self::getProgressBar($player, "Fermier"), 0, "textures/ui/diamond_hoe");
        $form->sendToPlayer($player);
    }


    public function jobsChoosed(Player $player, string $job): void
    {
        $level = JobsManager::getLevel($player, $job);
        $maxLevel = JobsManager::getMaxLevel();
        $xp = JobsManager::getXp($player, $job);
        $maxXp = JobsManager::getMaxXp($player, $job);
        $nextReward = JobsManager::getReward($job, $level);
        $nextRewardDisplay = "§cAucune récompense pour le prochain niveau";

        if ($nextReward) {
            foreach ($nextReward as $reward) {
                $rewardParts = explode("&", $reward);

                $rewardType = trim($rewardParts[0]);
                $rewardValue = trim($rewardParts[1]);

                if (isset($rewardParts[0]) && isset($rewardParts[1])) {
                    if ($rewardType === "xp") {
                        $nextRewardDisplay = "§d" . $rewardValue . "§f niveau d'xp";
                    } elseif ($rewardType === "money") {
                        $nextRewardDisplay = "§d" . $rewardValue . " $";
                    } elseif ($rewardType === "perm") {
                        $nextRewardDisplay = "§d" . trim($rewardParts[2]);
                    } else {
                        $item = StringToItemParser::getInstance()->parse($rewardType);
                        if ($item) {
                            if (isset($rewardParts[2]) && isset($rewardParts[3])) {
                                $enchantmentId = intval($rewardParts[2]);
                                $enchantmentLevel = intval($rewardParts[3]);
                                $enchantment = EnchantmentIdMap::getInstance()->fromId($enchantmentId);
                                if ($enchantment) {
                                    $item->addEnchantment(new EnchantmentInstance($enchantment, $enchantmentLevel));
                                    $nextRewardDisplay = "§d" . $rewardValue . " x " . $item->getName();
                                }
                            }
                        }
                    }
                }
            }
        }


        $remainingExp = $maxXp - $xp;

        $form = new SimpleForm(function (Player $player, $data) use ($job) {
            if (is_null($data)) return;

            switch ($data){
                case 2:
                    $this->rewards($player, $job);
                    break;
                case 3:
                    $this->info($player, $job);
                    break;
            }
        });
        $form->setTitle("§dJobs §f- §d$job");
        $form->setContent("§fVous êtes niveau §d{$level}§f/§d{$maxLevel}\n§fPour passer au niveau §d" . ($level + 1) . " §fil faut encore §d$remainingExp §fexp \n\nLa prochaine récompense est: §d$nextRewardDisplay");
        $form->addButton("Niveau: §d{$level}§f/§d25");
        $form->addButton("Exp: §d{$xp}§f/§d$maxXp");
        $form->addButton("Récompenses");
        $form->addButton("Comment xp ?");
        $form->sendToPlayer($player);
    }

    public function rewards(Player $player, string $job): void
    {
        $rewardsConfig = JobsManager::getIntoConfig("Jobs")[$job]["rewards"];
        $form = new SimpleForm(function (Player $player, $data) use ($job) {
            if (is_null($data)) return;
        });

        $form->setTitle("§dJobs §f- §d$job");
        $form->setContent("§fVous avez obtenu les suivantes récompenses:\n\n");

        foreach ($rewardsConfig as $index => $rewardArray) {
            $reward = $rewardArray[0];
            $buttonText = "Niveau§d " . ($index + 1);
            $rewards = explode("&", $reward);
            $rewardsBtn = "Aucune";

            if ($rewards[0] === "xp") {
                $rewardsBtn = "§d" . $rewards[1] . " level";
            } elseif ($rewards[0] === "money") {
                $rewardsBtn = "§d" . $rewards[1] . " $";
            } elseif ($rewards[0] === "perm") {
                $rewardsBtn = "§d" . $rewards[1] . " perm";
            } else {
                $item = StringToItemParser::getInstance()->parse($rewards[0]);
                if ($item) {
                    if (isset($rewards[2]) && isset($rewards[3])) {
                        $enchantmentId = intval($rewards[2]);
                        $enchantmentLevel = intval($rewards[3]);
                        $enchantment = EnchantmentIdMap::getInstance()->fromId($enchantmentId);
                        if ($enchantment) {
                            $rewardsBtn = "§d" . $rewards[1] . " x " . $item->getName() . " " . $player->getLanguage()->translate($enchantment->getName()) . " " . $enchantmentLevel;
                        }
                    } else {
                        $rewardsBtn = "§d" . $rewards[1] . " x " . $item->getName();
                    }
                }
            }

            $form->addButton($buttonText . "\n" . $rewardsBtn, -1, "", $index);
        }

        $form->sendToPlayer($player);
    }


    public static function getProgressBar(Player $player, string $job): string
    {
        $level = JobsManager::getLevel($player, $job);
        $xp = JobsManager::getXp($player, $job);

        $nextXp = JobsManager::getIntoConfig("Jobs")[$job]["XpPerLevel"][$level - 1];

        if ($level === 25) {
            return "§cNiveau maximum atteint";
        } else {
            $progress = intval(max(1, round((($xp / $nextXp) * 100) / 2, 2)));
            return "§a" . str_repeat("|", $progress) . "§c" . str_repeat("|", 50 - $progress);
        }
    }

    public function info(Player $player, string $job): void
    {
        $xp = JobsManager::getXp($player, $job);
        $maxXp = JobsManager::getMaxXp($player, $job);
        $remainingExp = $maxXp - $xp;
        $message = "";
        switch ($job) {
            case "Mineur":
                $message = "§fNiveau: §d" . JobsManager::getLevel($player, $job) . "§f/§d25\n§fXP: §d" . JobsManager::getXp($player, $job) . "§f/§d" . $remainingExp . "\n\n§fComment augmenter l'XP de ce métier ?\n\n§d- §fCharbon: §d1 §fXP\n§d- §fFer: §d4 §fXP\n§d- §fOr: §d10 §fXP\n§d- §fDiamant: §d15 §fXP\n§d- §fRedstone: §d1 §fXP\n§d- §fRedstone: §d3 §fXP\n§d- §fLapis-Lazuli: §d3 §fXP\n\n§fSi vous avez ces rôles, vous avez un bonus\n§fCavalier: +§d1.25%%\n§fRoi-Mage: +§d1.50%%\n§fAnge: +§d1.75%%\n§fDivin: +§d2%%";
                break;
            case "Fermier":
                $message = "§fNiveau: §d" . JobsManager::getLevel($player, $job) . "§f/§d25\n§fXP: §d" . JobsManager::getXp($player, $job) . "§f/§d" . $remainingExp . "\n\n§fComment augmenter l'XP de ce métier ?\n\n§d- §fPatate: §d2 §fXP\n§d- §fCarotte: §d2 §fXP\n§d- §fBlé: §d1 §fXP\n§d- §fMelon: §d5 §fXP\n§d- §fCitrouille: §d5 §fXP\n§d- §fFraise: §d3 §fXP\n§d- §fCoton: §d3 §fXP\n§d- §fTomate: §d3 §fXP\n\n§fSi vous avez ces rôles, vous avez un bonus\n§fCavalier: +§d1.25%%\n§fRoi-Mage: +§d1.50%%\n§fAnge: +§d1.75%%\n§fDivin: +§d2%%";
                break;
            case "Assassin":
                $message = "§fNiveau: §d" . JobsManager::getLevel($player, $job) . "§f/§d25\n§fXP: §d" . JobsManager::getXp($player, $job) . "§f/§d" . $remainingExp . "\n\n§fComment augmenter l'XP de ce métier ?\n\n§d- §fJoueur: §d10 §fXP (si il a une série §d10§f XP)\n§d- §fAssistance sur un kill: §d5 §fXP\n§d- §fChaque 10 sur votre série: §d7.5 §fXP\n§d- §fGagné un KoTH: §d100 §fXP\n\n§fSi vous avez ces rôles, vous avez un bonus\n§fCavalier: +§d1.25%%\n§fRoi-Mage: +§d1.50%%\n§fAnge: +§d1.75%%\n§fDivin: +§d2%%";
                break;
        }

        $form = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;
        });
        $form->setContent("Voici les informations concernant le métier de §d$job\n\n$message");
        $form->sendToPlayer($player);
    }
}