<?php

namespace Lunarium\Command\Player;

use customiesdevs\customies\item\CustomiesItemFactory;
use Lunarium\LunaMod\Item\CustomItem;
use Lunarium\Managers\MoneyManager;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class CashCommand extends Command
{

    public function __construct()
    {
        parent::__construct("cash", "Permet de convertir de l'argent en billet");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }

        $int = $args[0];
        if (!isset($int)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez marquez un nombre");
            return;
        }


        if (!is_numeric($int)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez marquez un nombre");
            return;
        }

        if (MoneyManager::getMoneyPlayer($sender) >= $int) {
            $item = CustomiesItemFactory::getInstance()->get(CustomItem::BILLET);
            $item->getNamedTag()->setInt("money", $int);
            $item->setCustomName("§fBillet de §d" . $int . "§f");

            if ($sender->getInventory()->canAddItem($item)) {
                MoneyManager::removeMoney($sender, $int);
                $sender->getInventory()->addItem($item);
                $sender->sendMessage(Utils::PREFIX . "§fVous avez convertis §d" . $int . "§f$ en §dbillet");
            } else {
                $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas de place dans votre inventaire");
            }
        } else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez d'argent");
    }
}