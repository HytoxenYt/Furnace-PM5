<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\Position;
use pocketmine\world\WorldException;

class RTPCommand extends Command
{
    public function __construct()
    {
        parent::__construct("rtp", "Se téléporter aléatoirement sur la map", "/rtp");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }
        $y = 200;
        $foundSafeLocation = false;
        $targetPosition = null;
        while (!$foundSafeLocation) {
            $xv = rand(1, 2);
            $x = ($xv === 1) ? rand(-1000, -2500) : rand(1000, 2500);

            $zv = rand(1, 2);
            $z = ($zv === 1) ? rand(-1000, -2500) : rand(1000, 2500);

            $chunkX = $x >> 4;
            $chunkZ = $z >> 4;

            if (!$sender->getWorld()->isChunkLoaded($chunkX, $chunkZ)) {
                $sender->getWorld()->loadChunk($chunkX, $chunkZ);
            }

            try {
                $targetPosition = $sender->getWorld()->getSafeSpawn(new Vector3($x, $y, $z));
                if ($targetPosition !== null) {
                    $foundSafeLocation = true;
                }
            } catch (WorldException $e) {
                var_dump($e->getMessage());
            }
        }
        $sender->teleport($targetPosition);
        $sender->sendMessage(Utils::PREFIX . "§fVous avez été téléporté aléatoirement");

    }
}