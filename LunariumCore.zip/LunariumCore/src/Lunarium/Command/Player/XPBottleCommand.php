<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

class XPBottleCommand extends Command
{

    public function __construct()
    {
        parent::__construct("xpbottle", "Tranformez vos xps en bouteille d'expérience", "/xpbottle <xp>", ["xp"]);
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if(!($sender instanceof Player)){
            $sender->sendMessage(Utils::PREFIX."§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        if(!isset($args[0])){
            $sender->sendMessage(Utils::PREFIX."§cVeuillez entrer un nombre");
            return;
        }

        if(!is_numeric($args[0])){
            $sender->sendMessage(Utils::PREFIX."§cVeuillez entrer un nombre");
            return;
        }

        if ($sender->getXpManager()->getXpLevel() > 0) {
            $lvl = intval($args[0]);
            if($sender->getXpManager()->getXpLevel() >= $lvl){
                $item = VanillaItems::EXPERIENCE_BOTTLE();
                $item->setCustomName("§fBouteille d'expérience §d({$lvl})");
                if($sender->getInventory()->canAddItem($item)){
                    $sender->getInventory()->addItem($item);
                    $sender->sendMessage(Utils::PREFIX. "Vous avez transformé §d{$lvl} XP §fen bouteille d'xp");
                    $sender->getXpManager()->subtractXpLevels($lvl);
                }else{
                    $sender->sendMessage(Utils::PREFIX. "§cVotre inventaire est plein");
                }
            }else $sender->sendMessage(Utils::PREFIX. "§cVous n'avez pas autant d'XP");
        } else {
            $sender->sendMessage(Utils::PREFIX."§cVous n'avez pas assez de niveaux");
        }
    }
}