<?php

namespace Lunarium\Command\Player;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;

class BlockCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct(Main::getInstance(), "block", "Permet de bloquer un joueur");
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        $config = new Config(Main::getInstance()->getDataFolder() . "block_player.yml", Config::YAML);

        $name = $args["joueur"];

        if (!isset($name)) {
            $sender->sendMessage(Utils::PREFIX . "§cVeuillez entrer un joueur");
            return;
        }

        $target = Server::getInstance()->getPlayerByPrefix($name);
        if (!$target instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'existe pas");
            return;
        }

        if ($config->exists($sender->getName())) {
            if (isset($config->get($sender->getName())[$target->getName()])) {
                $players = $config->get($sender->getName());
                unset($players[$target->getName()]);
                $config->set($sender->getName(), $players);
                $config->save();
                $sender->sendMessage(Utils::PREFIX . "§fVous avez bien débloqué §d" . $target->getName());
                $target->sendMessage(Utils::PREFIX . "§d{$sender->getName()}§f vous à débloqué");
            }else {
                $players = $config->get($sender->getName());
                $players[$target->getName()] = true;
                $config->set($sender->getName(), $players);
                $config->save();
                $sender->sendMessage(Utils::PREFIX . "§fVous avez bien bloqué §d" . $target->getName());
                $target->sendMessage(Utils::PREFIX . "§d{$sender->getName()}§f vous a été bloqué");
            }
        }else {
            $config->set($sender->getName(), array($target->getName() => true));
            $config->save();
            $sender->sendMessage(Utils::PREFIX . "§fVous avez bien bloqué §d" . $target->getName());
            $target->sendMessage(Utils::PREFIX . "§d{$sender->getName()}§f vous a été bloqué");
        }
    }


    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("joueur", false));
    }

    public function getPermission(): string
    {
        return "lunarium.basic";
    }
}