<?php

namespace Lunarium\Command\Player;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class TPAhereCommand extends BaseCommand
{

    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
        $this->setPermission($this->getPermission());
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!isset($args["player"])) {
            $sender->sendMessage(Utils::PREFIX . "§cVeuillez entrer un joueur");
            return;
        }

        if (!Server::getInstance()->getPlayerByPrefix($args["player"])) {
            $sender->sendMessage(Utils::PREFIX . "§cLe joueur indiqué n'est pas connecté");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être connecté");
            return;
        }

        $player = $args["player"];
        if (isset($player)) {
            $player = Server::getInstance()->getPlayerByPrefix($player);
            if ($player instanceof Player) {
                TPACommand::$invitation[$player->getName()] = ["player" => $sender->getName(), "time" => time() + 30, "here" => true];
                $player->sendMessage(Utils::PREFIX . "Vous avez reçu une demande de déplacement de§d {$sender->getName()} sur vous\n Vous avez§d 30 seconde(s) §fpour faire§d /tpaccept");
                $sender->sendMessage(Utils::PREFIX . "Vous avez envoyer une demande de déplacement au joueur §d{$player->getName()}");
            } else $sender->sendMessage(Utils::PREFIX . "§cLe joueur indiqué n'est pas connecté !");
        } else $sender->sendMessage(Utils::PREFIX . "§cVous devez indiquer un joueur !");
    }

    public function getPermission()
    {
        return "lunarium.basic";
    }
}