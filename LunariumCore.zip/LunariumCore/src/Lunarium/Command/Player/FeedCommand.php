<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FeedCommand extends Command
{
    public function __construct()
    {
        parent::__construct("feed", "Permet d'être rassasier", "/feed");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if ($sender instanceof Player) {
            $sender->getHungerManager()->setFood($sender->getHungerManager()->getMaxFood());
            $sender->getHungerManager()->setSaturation(20);
            $sender->sendMessage(Utils::PREFIX . "§fVous avez été rassasier");
        } else $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
    }
}