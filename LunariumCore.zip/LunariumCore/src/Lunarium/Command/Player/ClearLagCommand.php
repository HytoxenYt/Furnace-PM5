<?php

namespace Lunarium\Command\Player;

use Lunarium\Main;
use Lunarium\Tasks\PlayerTask;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class ClearLagCommand extends Command
{

    public function __construct()
    {
        parent::__construct("clearlagtime", "Pouvoir voir dans combien de temps passe le clearlag suivant", "/clearlagtime", ["nextclear"]);
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if(!$sender->hasPermission($this->getPermissions()[0])){
            $sender->sendMessage(Utils::PREFIX."§cVous n'avez accès a cette commande");
            return;
        }

        if(!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX."§cVous devez être un joueur");
            return;
        }

        $sender->sendMessage(Utils::PREFIX . "§fLe clearlag est dans §9" . Main::getInstance()->intToTime(PlayerTask::getTimeLeft()));
    }
}