<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class RenameCommand extends Command
{
    public function __construct()
    {
        parent::__construct("rename", "Permet de renommer votre item", "/rename <nom>", []);
        $this->setPermission("lunarium.rename");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès à cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        if (count($args) > 0) {
            $name = implode(" ", $args);

            if (!in_array(strtolower($name), ["fdp", "ntm"])) {
                if (preg_match("/^[a-zA-Z0-9 ]+$/", $name)) {
                    $item = $sender->getInventory()->getItemInHand();
                    $item->setCustomName($name);
                    $sender->getInventory()->setItemInHand($item);

                    $sender->sendMessage(Utils::PREFIX . "§aVotre item a été renommé en : §f" . $name);
                } else {
                    $sender->sendMessage(Utils::PREFIX . "§cLe nom ne peut contenir que des lettres, des chiffres et des espaces");
                }
            } else {
                $sender->sendMessage(Utils::PREFIX . "§cCe nom est interdit");
            }
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cUtilisation : /rename <nom>");
        }
    }
}
