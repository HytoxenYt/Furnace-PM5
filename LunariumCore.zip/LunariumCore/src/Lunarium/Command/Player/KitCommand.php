<?php

namespace Lunarium\Command\Player;

use jojoe77777\FormAPI\SimpleForm;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Managers\KitManager;

class KitCommand extends Command
{
    public function __construct()
    {
        parent::__construct("kit", "Permet d'avoir des kits", "/kit", ["kits"]);
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }

        $this->showKits($sender);
    }

    public function showKits(Player $player): void
    {
        $form = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) {
                return;
            }

            switch ($data) {
                case 0:
                    KitManager::giveKitJoueur($player);
                    break;
                case 1:
                    if ($player->hasPermission("lunarium.youtubeur")) {
                        KitManager::giveKitYoutubeur($player);
                    } else $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
                    break;
                case 2:
                    if ($player->hasPermission("lunarium.streameur")) {
                        KitManager::giveKitStreameur($player);
                    } else $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
                    break;
                case 3:
                    if ($player->hasPermission("lunarium.cavalier")) {
                        KitManager::giveKitCavalier($player);
                    } else $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
                    break;
                case 4:
                    if ($player->hasPermission("lunarium.roi-mage")) {
                        KitManager::giveKitRoiMage($player);
                    } else $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
                    break;
                case 5:
                    if ($player->hasPermission("lunarium.ange")) {
                        KitManager::giveKitAnge($player);
                    } else $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
                    break;
                case 6:
                    if ($player->hasPermission("lunarium.lunaire")) {
                        KitManager::giveKitLunaire($player);
                    } else $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
                    break;
            }
        });
        $form->setTitle("§9Kits");
        $form->setContent("Bienvenue dans le menu des kits. Ici, vous pouvez choisir un kit si vous en avez la permission");
        $form->addButton("Kit Joueur\n§aPossédé");
        if ($player->hasPermission("lunarium.youtubeur")) {
            $form->addButton("Kit Youtubeur\n§aPossédé");
        } else $form->addButton("Kit Youtubeur\n§cNon Possédé");

        if ($player->hasPermission("lunarium.streameur")) {
            $form->addButton("Kit Streameur\n§aPossédé");
        } else {
            $form->addButton("Kit Streameur\n§cNon Possédé");
        }

        if ($player->hasPermission("lunarium.cavalier")) {
            $form->addButton("Kit Cavalier\n§aPossédé");
        } else {
            $form->addButton("Kit Cavalier\n§cNon Possédé");
        }

        if ($player->hasPermission("lunarium.roi-mage")) {
            $form->addButton("Kit Roi-Mage\n§aPossédé");
        } else {
            $form->addButton("Kit Roi-Mage\n§cNon Possédé");
        }

        if ($player->hasPermission("lunarium.ange")) {
            $form->addButton("Kit Ange\n§aPossédé");
        } else {
            $form->addButton("Kit Ange\n§cNon Possédé");
        }

        if ($player->hasPermission("lunarium.lunaire")) {
            $form->addButton("Kit Lunaire\n§aPossédé");
        } else {
            $form->addButton("Kit Lunaire\n§cNon Possédé");
        }

        $form->sendToPlayer($player);
    }
}