<?php

declare(strict_types=1);

namespace Lunarium\Command\Player;

use CortexPE\Commando\BaseCommand;
use Lunarium\Command\sub\RepairAllSubCommand;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;
use pocketmine\player\Player;

class RepairCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerSubCommand(new RepairAllSubCommand("all"));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;

        $item = $sender->getInventory()->getItemInHand();
        if (!$item instanceof Durable) {
            $sender->sendMessage(Utils::PREFIX . "§fVous ne pouvez pas réparé cette item");
            return;
        }

        $item->setDamage(0);
        $sender->getInventory()->setItemInHand($item);
        $sender->sendMessage(Utils::PREFIX .  "§fVotre item a été réparé");
    }

    public function getPermission(): string
    {
        return "lunarium.repair";
    }
}

