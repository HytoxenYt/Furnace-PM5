<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class ListCommand extends Command
{

    public function __construct()
    {
        parent::__construct("list", "Permet de voir la liste des joueurs connectés", "/list");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        $players = [];
        $staffplayers = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $players[] = $player->getName();
            if ($player->hasPermission("lunarium.staff")) {
                $staffplayers[] = $player->getName();
            }
        }
        $sender->sendMessage(Utils::PREFIX . "§fListe des joueurs connectés : §d" . implode("§f, §d", $players) . "\n\n" . Utils::PREFIX . "§fListe des joueurs en staff : §d" . implode("§f, §d", $staffplayers));
    }
}