<?php

declare(strict_types=1);

namespace Lunarium\Command\Player;

use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\lang\Translatable;
use pocketmine\player\Player;

class NightVisionCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;
        $effects = $sender->getEffects();
        if ($effects->has(VanillaEffects::NIGHT_VISION())) {
            $effects->remove(VanillaEffects::NIGHT_VISION());
            $sender->sendMessage(Utils::PREFIX . "§fVous avez désactivé la vision");
        } else {
            $effects->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 99999999, 3, false));
            $sender->sendMessage(Utils::PREFIX . "§fVous avez activé la vision");
        }
    }

    public function getPermission(): string
    {
        return "lunarium.basic";
    }
}

