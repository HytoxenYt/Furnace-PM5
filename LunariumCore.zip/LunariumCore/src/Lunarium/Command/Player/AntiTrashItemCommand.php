<?php

namespace Lunarium\Command\Player;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class AntiTrashItemCommand extends Command
{
    public static array $antitrash = [];

    public function __construct()
    {
        parent::__construct("antitrashitem", "Active ou désactive le drop des cobblestone", "/antitrashitem", ["antitrash", "cobblestone", "drops"]);
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cCette commande est uniquement utilisable par les joueurs");
            return;
        }

        $playerName = $sender->getXuid();
        if (isset(self::$antitrash[$playerName]) && self::$antitrash[$playerName] === true) {
            self::$antitrash[$playerName] = false;
            $sender->sendMessage(Utils::PREFIX . "§fVous avez §cdésactivé §fle drop de cobblestone");
        } else {
            self::$antitrash[$playerName] = true;
            $sender->sendMessage(Utils::PREFIX . "§fVous avez §aactivé §fle drop de cobblestone");
        }
    }
}
