<?php

namespace Lunarium\Command\Player;

use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\math\AxisAlignedBB;
use pocketmine\player\Player;

class NearCommand extends Command
{
    public function __construct()
    {
        parent::__construct("near", "Savoir quels sont les joueurs proches", "/near");
        $this->setPermission("lunarium.near");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if(!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX."§cVous devez être un joueur");
            return;
        }
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
            return;
        }

        $cooldown = Utils::getCooldown()->has($sender->getXuid(), "near");
        if ($cooldown) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez attendre §d" . Main::getInstance()->intToTime(Utils::getCooldown()->get($sender->getXuid(), "near"), "§c"));
            return;
        }


        $rank = Main::getInstance()->getRank($sender);
        $cooldown = 60 * 25;
        $block = 100;
        switch($rank) {
            case "Cavalier":
                $cooldown = 60 * 60;
                $block = 100;
                break;
            case "Roi-Mage":
                $cooldown = 60 * 30;
                $block = 125;
                break;
            case "Ange":
                $cooldown = 60 * 15;
                $block = 150;
                break;
            case "Divin":
                $cooldown = 60 * 5;
                $block = 200;
                break;
        }
        Utils::getCooldown()->add($sender->getXuid(), "near", $cooldown);

        $near = $this->getNearPlayers($sender, $block);
        if(count($near) === 0){
            $sender->sendMessage(Utils::PREFIX . "§fIl y'a aucun joueur au alentour de §d$block blocs");
        }else {
            $sender->sendMessage(Utils::PREFIX . "§fListe des joueurs proches : §d" . implode("§f, §d", $near));
        }
    }
    public function getNearPlayers(Player $player, int $radius = null): ?array{

        $players = [];
        foreach($player->getWorld()->getNearbyEntities(new AxisAlignedBB($player->getPosition()->getFloorX() - $radius, $player->getPosition()->getFloorY() - 250, $player->getPosition()->getFloorZ() - $radius, $player->getPosition()->getFloorX() + $radius, $player->getPosition()->getFloorY() + 250, $player->getPosition()->getFloorZ() + $radius), $player) as $e){
            if($e instanceof Player){
                if($e === $player) continue;
                $distance = round($player->getPosition()->distance($e->getPosition()));
                $players[] = "§f" . $e->getName() . " §f(§d{$distance}§f)";
            }
        }
        return $players;
    }
}