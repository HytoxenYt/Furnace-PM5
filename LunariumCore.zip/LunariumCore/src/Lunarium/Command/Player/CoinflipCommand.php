<?php

namespace Lunarium\Command\Player;

use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;
use Lunarium\Main;
use Lunarium\Managers\MoneyManager;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class CoinflipCommand extends Command
{
    public static array $coinsflip = [];
    public static array $coinsflipplayer = [];
    public function __construct()
    {
        parent::__construct('coinflip', 'Accéder au menu des coinflips', '/coinflip');
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
            return;
        }

        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        $this->showCoinsflipInterface($sender);
    }
    public function showCoinsflipInterface(Player $player)
    {
        $simpleForm = new SimpleForm(function (Player $player,$data){
            if (is_null($data)) return;

            switch ($data) {
                case 0:
                    if (key_exists($player->getName(), self::$coinsflip)) $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas créer plusieurs coinflip en même temps");
                    $this->showCoinsflipCreateInterface($player);
                    break;
                case 1:
                    if (empty(self::$coinsflip))  $player->sendMessage(Utils::PREFIX . "§cIl n'y a aucun coinflip de disponible pour le moment");
                    $this->showCoinsflipJoinInterface($player);
                    break;
            }
        });
        $simpleForm->setTitle("§dCoinflip");
        $simpleForm->setContent("Misez votre argent pour obtenir le double");
        $simpleForm->addButton("Créer");
        $count = count(self::$coinsflip);
        $simpleForm->addButton("Rejoindre\n §f(§d{$count}§f) ". ($count > 1 ? "coinflips" : "coinflip"). " en cours");
        $simpleForm->sendToPlayer($player);
    }
    public function showCoinsflipCreateInterface(Player $player):void
    {
        $customForm = new CustomForm(function (Player $player, $data){
            if (is_null($data)) return;
            if (empty($data)) return;
            $price = $data[1];
            if(!is_numeric($price)){
                $player->sendMessage(Utils::PREFIX . "§cVous devez entrer un nombre");
                return;
            }

            if($price <= 1){
                $player->sendMessage(Utils::PREFIX . "§cLe nombre doit être supérieur à 1");
                return;
            }

            $config = new Config(Main::getInstance()->getDataFolder() . "coinfip.yml", Config::YAML);
            if ($config->get($player->getName()) - time() <= 0) {
                if (MoneyManager::getMoneyPlayer($player->getName()) >= $price) {
                    self::$coinsflip[$player->getName()] = $price;
                    MoneyManager::removeMoney($player->getName(), $price);
                    $config->set($player->getName(), time() + 60 * 10);
                    $config->save();
                    $player->sendMessage(Utils::PREFIX . "Vous avez créer un coinflip d'une valeur de §d{$price}§f$");
                } else {
                    $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez d'argent pour rejoindre ce coinflip");
                }
            } else {
                $time = $config->get($player->getName()) - time();
                $player->sendMessage(Utils::PREFIX . "§cVous devez encore attendre ". Main::getInstance()->intToTime($this, "§c") ."§c avant de pouvoir créer un nouveau coinflip");
            }
        });
        $customForm->setTitle("§dCoinflip");
        $customForm->addLabel("Choisissez le prix du coinflip");
        $customForm->addInput("Prix");
        $customForm->sendToPlayer($player);
    }
    public function showCoinsflipJoinInterface(Player $player):void
    {
        $simpleForm = new SimpleForm(function (Player $player, $data){
            if (is_null($data)) return;

            $key = array_keys(self::$coinsflipplayer[$player->getName()])[$data];
            if (!key_exists($key, self::$coinsflip)) $player->sendMessage(Utils::PREFIX . "§cCe coinflip a déjà été pris par un autre joueur");
            $name = array_keys(self::$coinsflipplayer[$player->getName()])[$data];
            $price = array_values(self::$coinsflipplayer[$player->getName()])[$data];
            if (MoneyManager::getMoneyPlayer($player->getName()) >= $price) {
                if (!($name == $player->getName())) {
                    $finalprice = $price * 2;
                    $sort = mt_rand(1, 2);
                    MoneyManager::removeMoney($player->getName(), $price);
                    unset(self::$coinsflip[$name]);
                    if ($sort == 1) {
                        foreach ($player->getServer()->getOnlinePlayers() as $players){
                            $players->sendMessage(Utils::PREFIX."§d{$name} §fa remporté un coinflip contre §d{$player->getName()}§f d'une valeur de §d{$finalprice}§f$");
                        }
                        MoneyManager::addMoney($name, $finalprice);
                    }
                    if ($sort == 2) {
                        foreach ($player->getServer()->getOnlinePlayers() as $players){
                            $players->sendMessage(Utils::PREFIX."§d{$player->getName()} §fa remporté un coinflip contre §d{$name}§f d'une valeur de §d{$finalprice}§f$");
                        }
                        MoneyManager::addMoney($player->getName(), $finalprice);
                    }
                } else {
                    $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas rejoindre votre propre coinflip");
                }
            } else {
                $player->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez d'argent pour rejoindre ce coinflip");
            }

        });
        $simpleForm->setTitle("§dCoinflip");
        $simpleForm->setContent("Rejoignez une partie de coinflip pour tentez d'obtenir le double");
        self::$coinsflipplayer[$player->getName()] = self::$coinsflip;
        foreach (self::$coinsflip as $name => $price){
            $simpleForm->addButton("§f{$name}: §d{$price}§f$");
        }
        $simpleForm->sendToPlayer($player);

    }
}