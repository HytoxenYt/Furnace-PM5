<?php

namespace Lunarium\Command\Player;

use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;
use Lunarium\Managers\MoneyManager;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class LotteryCommand extends Command
{

    public function __construct()
    {
        parent::__construct("lottery", "Ouvrir le menu de la lotterie", "/lottery", ["loto", "lotterie"]);
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être connecté");
            return;
        }

        $this->sendLotteryInterface($sender);
    }

    public function sendLotteryInterface(Player $player): void
    {
        $ui = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;
            switch ($data) {
                case 0:
                    if (isset(Utils::$lotteryp[$player->getName()])) {
                        if (Utils::$lotteryp[$player->getName()] >= 50000) {
                            $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas mettre plus de 50000§f$");
                            return;
                        }
                    }
                    self::sendLotteryMiseInterface($player);
                    break;
            }
        });
        $sommes = Utils::$lottery;
        if (isset(Utils::$lotteryp[$player->getName()])) {
            $selfsommes = Utils::$lotteryp[$player->getName()];
        } else {
            $selfsommes = 0;
        }
        if ($sommes > 0) {
            $pourcent = $sommes / 100;
            $pourcent = round($selfsommes / $pourcent, 2);
        } else {
            $pourcent = 0;
        }
        $timeRestant = Utils::$lotterietime;
        $annee = intval(abs($timeRestant / 31536000));
        $timeRestant = $timeRestant - ($annee * 31536000);
        $mois = intval(abs($timeRestant / 2635200));
        $timeRestant = $timeRestant - ($mois * 2635200);
        $jours = intval(abs($timeRestant / 86400));
        $timeRestant = $timeRestant - ($jours * 86400);
        $heures = intval(abs($timeRestant / 3600));
        $timeRestant = $timeRestant - ($heures * 3600);
        $minutes = intval(abs($timeRestant / 60));
        $secondes = intval(abs($timeRestant - $minutes * 60));
        if ($heures > 0) {
            $formatTemp = "§5{$heures} heure(s) §fet §5{$minutes} minute(s)";
        } else if ($minutes > 0) {
            $formatTemp = "§5{$minutes} minute(s) §fet§5 {$secondes} seconde(s)";
        } else {
            $formatTemp = "§5{$secondes} seconde(s)";
        }
        $ui->setTitle("§l§dLotterie");
        $ui->setContent("Miser votre argent\n\n§fSommes actuelle: §5{$sommes}$\n§fVotre sommes: §5{$selfsommes}$\n§fFin dans: §5{$formatTemp}\n§fVous avez: §5{$pourcent}%% §fde chances de gagner");
        $ui->addButton("§5Miser", 0, "textures/ui/lottery");
        $ui->addButton("§cRetour");
        $ui->sendToPlayer($player);
    }

    public static function sendLotteryMiseInterface(Player $player): void
    {
        $ui = new CustomForm(function (Player $player, $data) {
            if (is_null($data)) return;
            if (empty($data)) return;
            $prix = (int)$data[1];
            if (MoneyManager::getMoneyPlayer($player) >= $prix) {
                MoneyManager::removeMoney($player, $prix);
                Utils::$lottery = Utils::$lottery + $prix;
                if (isset(Utils::$lotteryp[$player->getName()])) {
                    Utils::$lotteryp[$player->getName()] = Utils::$lotteryp[$player->getName()] + $prix;
                    $player->sendMessage(Utils::PREFIX . "Vous avez bien misé §5{$prix}§f$ dans la lotterie, bonne chance");
                } else {
                    Utils::$lotteryp[$player->getName()] = $prix;
                    $player->sendMessage(Utils::PREFIX . "Vous avez bien misé §5{$prix}§f$ dans la lotterie, bonne chance");
                }
            } else {
                $player->sendMessage(Utils::PREFIX . "Vous n'avez pas assez d'argent pour misez §5{$prix}§f$");
            }
        });
        $ui->setTitle("§5Lotterie");
        $sommes = Utils::$lottery;
        if (isset(Utils::$lotteryp[$player->getName()])) {
            $selfsommes = Utils::$lotteryp[$player->getName()];
        } else {
            $selfsommes = 0;
        }
        if ($sommes > 0) {
            $pourcent = $sommes / 100;
            $pourcent = round($selfsommes / $pourcent, 2);
        } else {
            $pourcent = 0;
        }
        $ui->addLabel("Miser votre argent\n\n§fSommes actuelle: §5{$sommes}§f$\n§fVotre sommes: §5{$selfsommes}§f$\n§fVous avez: §5{$pourcent}%% §fde chances de gagner");
        if (isset(Utils::$lotteryp[$player->getName()])) {
            $prix = Utils::$lotteryp[$player->getName()];
        } else {
            $prix = 0;
        }
        $max = 50000 - $prix;
        $ui->addInput("Mise", 1, $max);
        $ui->sendToPlayer($player);
    }
}