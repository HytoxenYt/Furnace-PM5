<?php

namespace Lunarium\Command\Player;

use Lunarium\Tasks\PlayerTask;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class SeeChunkCommand extends Command
{

    public function __construct()
    {
        parent::__construct("seechunk", "Permet d'activer la voir les chunks", "/seechunk");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        if(isset(PlayerTask::$seeChunk[$sender->getXuid()])){
            $sender->sendMessage(Utils::PREFIX. "Vous avez désactivé les délimitations des chunks");
            unset(PlayerTask::$seeChunk[$sender->getXuid()]);
        }else{
            $sender->sendMessage(Utils::PREFIX. "Vous avez activé les délimitations des chunks");
            PlayerTask::$seeChunk[$sender->getXuid()] = true;
        }
    }
}