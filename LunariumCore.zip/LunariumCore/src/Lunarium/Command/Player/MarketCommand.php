<?php

namespace Lunarium\Command\Player;

use CortexPE\DiscordWebhookAPI\Embed;
use CortexPE\DiscordWebhookAPI\Message;
use CortexPE\DiscordWebhookAPI\Webhook;
use Lunarium\Main;
use Lunarium\Managers\InterfaceManager;
use Lunarium\Managers\MoneyManager;
use Lunarium\Utils\Utils;
use pocketmine\block\VanillaBlocks;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class MarketCommand extends Command
{
    public function __construct()
    {
        parent::__construct("auction", "Accéder a l'hôtel des ventes", "/auction", ["hdv", "market", "ah"]);
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }
        if (isset($args[0])) {
            if (strtolower($args[0]) === "sell" && isset($args[1])) {
                if (is_numeric($args[1])) {
                    if (intval($args[1]) <= 99999999 && intval($args[1]) >= 1) {
                        if (MoneyManager::getMoneyPlayer($sender) >= intval((intval($args[1]) / 100) * Utils::getAuctionHouseTaxes($sender))) {
                            MoneyManager::removeMoney($sender, intval((intval($args[1]) / 100) * Utils::getAuctionHouseTaxes($sender)));
                            $aunctions = new Config(Main::getInstance()->getDataFolder() . "auction.json", Config::JSON);
                            $count = 0;
                            foreach ($aunctions->getAll() as $auction => $value) {
                                if (explode(":", $auction[3]) === $sender->getName()) $count++;
                            }

                            if ($count < Utils::getAuctionLimit($sender)) {
                                if (!in_array($sender->getInventory()->getItemInHand()->getTypeId(), [VanillaBlocks::BEDROCK()->asItem()->getTypeId(), VanillaBlocks::AIR()->asItem()->getTypeId()])) {
                                    $price = intval($args[1]);
                                    $count = $sender->getInventory()->getItemInHand()->getCount();
                                    $name = Utils::getItemName($sender->getInventory()->getItemInHand());
                                    $enchantment = [];
                                    foreach ($sender->getInventory()->getItemInHand()->getEnchantments() as $enchantm) {
                                        $id = EnchantmentIdMap::getInstance()->toId($enchantm->getType());
                                        $level = $enchantm->getLevel();
                                        $enchName = Utils::getEnchantName($id);
                                        $enchantment[] = "§5$enchName §f=> §5$level";
                                    }

                                    $embed = new Embed();
                                    $embed->setTitle("Hôtel de Vente - **{$name}**");
                                    $embed->setDescription("**{$sender->getName()}** à vendu **{$count}** **{$name}** pour **{$price}$**\n" . (isset($enchantment) ? "Enchantements: " . implode(" ", $enchantment) : "**Aucun enchantement**"));
                                    $embed->setAuthor("Pyritia - Hôtel de Vente");
                                    $embed->setTimestamp(new \DateTime());
                                    $msg = new Message();
                                    $msg->addEmbed($embed);
                                    $wbk = new Webhook("https://discord.com/api/webhooks/1336457816176590849/vJi08Z1cv6JkVzMX8weX969pCPdkLnqOZXbt_xoD9e-V1iy7jvk55n8ymxjN_-dttVZD");
                                    $wbk->send($msg);
                                    $time = time() + 432000;
                                    $sender->sendMessage(Utils::PREFIX . "§fVous avez vendu §5$count $name §fà §5{$price}§f$");
                                    $rand = rand(0, 999999);
                                    $item = $sender->getInventory()->getItemInHand();
                                    $auction = bin2hex(Utils::ItemSerialize($item));
                                    $aunctions->set("$price:::$name:::$time:::{$sender->getName()}:::$rand", $auction);
                                    $aunctions->save();
                                    $sender->getInventory()->setItemInHand(VanillaItems::AIR());
                                } else $sender->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas vendre ça");
                            } else $sender->sendMessage(Utils::PREFIX . "§cVous avez atteint votre limite de vente");
                        } else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas assez d'argent pour la taxe qui s'élève à §5" . intval((intval($args[1]) / 100) * Utils::getAuctionHouseTaxes($sender)) . "§f$");
                    } else $sender->sendMessage(Utils::PREFIX . "§cVous devez entrer un prix compris entre §51§f$ §fet §599999999§f$");
                } else $sender->sendMessage(Utils::PREFIX . "§fVous devez entrer un nombre entier");
            } else $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §5/hdv sell <prix> §cpour mettre en vente un objet dans l'hôtel de vente");
        } else InterfaceManager::AuctionMenu($sender);
    }
}