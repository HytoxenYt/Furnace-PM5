<?php

namespace Lunarium\Command\Player;

use jojoe77777\FormAPI\SimpleForm;
use Lunarium\LunaMod\CustomRecipe;
use Lunarium\Utils\Loaders\ItemsLoader;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\Block;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\crafting\ExactRecipeIngredient;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat as C;

class CraftsCommand extends Command  {
    public function __construct() {
        parent::__construct("crafts", "Permet de voir les crafts des items");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if (!$sender instanceof Player) return;

        $form = new SimpleForm(function (Player $player, $data) {
            if (!is_int($data)) return;

            $list = $this->buildItemList();
            if ($data < 0 or $data >= count($list)) return;

            /** @var CustomRecipe $obj */
            $obj = $list[$data];

            /** @var ShapedRecipe|ShapedRecipe[] $r */
            $r = $obj::getRecipe();
            if (is_array($r)) {
                $sublist = [];
                foreach ($r as $v)
                    $sublist[] = $v->getResults()[0];

                $subForm = new SimpleForm(function (Player $player, $data) use ($sublist) {
                    if (!is_int($data)) return;
                    if ($data < 0 or $data >= count($sublist)) return;

                    /** @var CustomRecipe $obj */
                    $obj = $sublist[$data];
                    /** @var ShapedRecipe[] $r */
                    $r = $obj::getRecipe();

                    $this->openCraftInventory($player, $r[$data]->getIngredientMap(), $r[$data]->getResults()[0]);
                });

                foreach ($sublist as $v)
                    $subForm->addButton($v->getName(), SimpleForm::IMAGE_TYPE_PATH, "textures/ui/recipe_book_icon");

                $subForm->setTitle("§d» §fLISTE DES RECETTES §d«");
                $subForm->setContent("§fIl existe des dérivés de §d" . $obj->getName());
                $player->sendForm($subForm);
            } else {
                $this->openCraftInventory($player, $r->getIngredientMap(), $r->getResults()[0]);
            }
        });

        /** @var Item|Block $obj */
        foreach ($this->buildItemList() as $obj)
            $form->addButton($obj->getName(), SimpleForm::IMAGE_TYPE_PATH, "textures/ui/recipe_book_icon");

        $form->setTitle("§d» §fLISTE DES RECETTES §d«");
        $sender->sendForm($form);
    }

    private function buildItemList(): array {
        $list = [];
        foreach (ItemsLoader::getCustomItems() as $item) {
            if ($item instanceof CustomRecipe) {
                $r = $item::getRecipe();
                if (is_array($r)) {
                    if (!empty($r))
                        $list[] = $item;
                } else {
                    $list[] = $item;
                }
            }
        }
        return $list;
    }

    /**
     * @param Player $player
     * @param Item[][] $ingredientMap
     * @param Item $result
     */
    private function openCraftInventory(Player $player, array $ingredientMap, Item $result) {
        $content = [];

        $l1min = 2;
        $l1max = 4;
        $l2min = 11;
        $l2max = 13;
        $l3min = 20;
        $l3max = 22;
        $craftSlot = 15;

        $convertIngredients = function (array $row): array {
            return array_map(function ($ingredient) {
                if ($ingredient instanceof ExactRecipeIngredient) {
                    return $ingredient->getItem();
                }
                return $ingredient;
            }, $row);
        };

        if (isset($ingredientMap[0])) {
            $line = $convertIngredients($ingredientMap[0]);
            for ($i = $l1min; $i <= $l1max; $i++) {
                if (isset($line[$i - $l1min])) {
                    $content[$i] = $line[$i - $l1min];
                }
            }
        }

        if (isset($ingredientMap[1])) {
            $line = $convertIngredients($ingredientMap[1]);
            for ($i = $l2min; $i <= $l2max; $i++) {
                if (isset($line[$i - $l2min])) {
                    $content[$i] = $line[$i - $l2min];
                }
            }
        }

        if (isset($ingredientMap[2])) {
            $line = $convertIngredients($ingredientMap[2]);
            for ($i = $l3min; $i <= $l3max; $i++) {
                if (isset($line[$i - $l3min])) {
                    $content[$i] = $line[$i - $l3min];
                }
            }
        }

        $content[$craftSlot] = $result;

        $inv = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $inv->getInventory()->setContents($content);
        $inv->setListener(InvMenu::readonly());
        $inv->send($player, "§fAffichage de la recette");
    }

}