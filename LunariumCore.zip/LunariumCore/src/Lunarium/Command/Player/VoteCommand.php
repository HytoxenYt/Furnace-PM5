<?php /** @noinspection PhpUnused */

namespace Lunarium\Command\Player;

use CortexPE\Commando\BaseCommand;
use Lunarium\Main;
use Lunarium\Managers\VotePartyManager;
use Lunarium\Tasks\VoteRequestTask;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
class VoteCommand extends BaseCommand
{
    private static string $key = "ZuSYZNhZsv8CWb06AXowi5JBDJoFhCg7PKX";
    public static string $link = "minecraftpocket-servers.com/server/129887";

    public static function getResult(string $name, string $type, ?int $result): void
    {
        $player = Main::getInstance()->getServer()->getPlayerExact($name);

        if (!$player instanceof Player) {
            return;
        }

        if ($type === "object") {
            if ($result === 1) {
                self::sendPlayer($player, "action");
            } else {
                $message = match ($result) {
                    0 => Utils::PREFIX . "§cVous n'avez pas encore voté, rendez-vous sur §9". self::$link,
                    default => Utils::PREFIX . "§cVous avez déjà voté pour le serveur"
                };

                $player->sendMessage($message);
            }
        } else if ($type === "action") {
            if ($result === 1) {
                self::sendVoteReward($player);
            } else {
                $player->sendMessage(Utils::PREFIX . "§cVous avez déjà voté les 24 dernières heures");
            }
        }
    }

    public static function sendPlayer(Player $player, string $type = "object"): void
    {
        $user = str_replace(" ", "_", $player->getName());
        $api = "https://minecraftpocket-servers.com/api/?";

        $query = match ($type) {
            "object" => "object=votes&element=claim&key=" . self::$key . "&username=" . $user,
            "action" => "action=post&object=votes&element=claim&key=" . self::$key . "&username=" . $user,
            default => null
        };

        if (!is_null($query)) {
            Main::getInstance()->getServer()->getAsyncPool()->submitTask(new VoteRequestTask($player->getName(), $type, $api . $query));
        }
    }

    public static function sendVoteReward(Player $player): void
    {
        VotePartyManager::addVoteParty();

        $randKeys = mt_rand(1, 2);
        Main::getInstance()->getServer()->broadcastMessage(Utils::PREFIX . "§9" . $player->getName() . "§f a voté §fet à reçu §9$randKeys §fclé" . ($randKeys > 1 ? "s " : " ") . "vote");
        $player->sendMessage(Utils::PREFIX . "§fVous avez reçu §9$randKeys §fclé" . ($randKeys > 1 ? "s " : " ") . "vote");


    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player) {
            self::sendPlayer($sender);
        }
    }

    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
    }

    public function getPermission(): string
    {
        return "lunarium.basic";
    }
}