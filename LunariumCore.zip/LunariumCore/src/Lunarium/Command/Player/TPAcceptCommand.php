<?php

namespace Lunarium\Command\Player;

use Lunarium\Tasks\TeleportationTask;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\player\Player;
use pocketmine\Server;

class TPAcceptCommand extends Command
{
    public function __construct()
    {
        parent::__construct("tpaccept", "Permet d'accepter une demande de téléportation", "/tpaccept");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être connecté");
            return;
        }

        if($sender instanceof Player){
            if(!empty(TPACommand::$invitation[$sender->getName()])){
                if(TPACommand::$invitation[$sender->getName()]["time"] > time()){
                    $player = Server::getInstance()->getPlayerByPrefix(TPACommand::$invitation[$sender->getName()]["player"]);
                    if($player instanceof Player){
                        if(TPACommand::$invitation[$sender->getName()]["here"]){
                            new TeleportationTask($sender, $player->getPosition(), Utils::PREFIX . "Vous avez été téléporté");
                        }else new TeleportationTask($player, $sender->getPosition(), Utils::PREFIX . "Vous avez été téléporté");
                        unset(TPACommand::$invitation[$sender->getName()]);
                    }else $sender->sendMessage(Utils::PREFIX . "§cLe joueur indiqué n'est pas connecté");
                }else $sender->sendMessage(Utils::PREFIX . "§cLa demande de téléportation a expiré");
            }else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez aucune demande de téléportation");
        }else $sender->sendMessage(Utils::PREFIX . "§cVous devez être connecté");
    }
}