<?php

namespace Lunarium\Command\Player;

use CortexPE\Commando\BaseCommand;
use Lunarium\Listener\PlayerListener;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\lang\Translatable;
use pocketmine\player\Player;
use pocketmine\world\Position;

class BackCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;

        if (!isset(PlayerListener::$coords[$sender->getXuid()])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas de lieu de mort");
            return;
        }

        $coords = PlayerListener::$coords[$sender->getXuid()];

        $ranks = [
            "Voyageur" => 60 * 60,
            "Guerrier" => 60 * 30,
            "Lunaire" => 60 * 10
        ];

        Utils::getCooldown()->add($sender->getXuid(), "back", $ranks[Main::getInstance()->getRank($sender->getName())] ?? 60 * 60);
        $world = $sender->getServer()->getWorldManager()->getWorldByName($coords[3]);
        if (!$world) {
            $sender->sendMessage(Utils::PREFIX . "§cLe monde de votre dernier lieu de mort n'existe plus");
            return;
        }

        $sender->teleport(new Position($coords[0], $coords[1], $coords[2], $world));
        $sender->sendMessage(Utils::PREFIX . "§fVous avez été téléporté à votre dernier lieu de mort");
    }

    public function getPermission(): string
    {
        return "lunarium.back";
    }
}
