<?php

namespace Lunarium\Command\Player;

use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class BourseCommand extends Command
{
    public function __construct()
    {
        parent::__construct("bourse", "Connaître les prix de la bourse d'aujourd'hui");
        $this->setPermission("lunarium.basic");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
            return;
        }

        $message = Utils::PREFIX . "§fVoici la bourse d'aujourd'hui\n";
        $config = new Config(Main::getInstance()->getDataFolder() . "shop.yml");

        $categories = [
            "Agricultures" => $config->get("Agricultures", []),
            "Minerais" => $config->get("Minerais", [])
        ];

        foreach ($categories as $category => $items) {
            if (is_array($items)) {
                foreach ($items as $item) {
                    if (is_string($item)) {
                        $vente = explode("&", $item);
                        if (count($vente) >= 2) {
                            $culture = $vente[1];
                            $prix = $vente[2];
                            $message .= "§d{$culture} §f: §d{$prix}\n";
                        }
                    }
                }
            }
        }

        $sender->sendMessage($message);
    }
}