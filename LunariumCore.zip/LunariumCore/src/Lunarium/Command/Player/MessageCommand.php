<?php

namespace Lunarium\Command\Player;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;

class MessageCommand extends BaseCommand
{
    public static array $msg = [];

    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
        $this->registerArgument(1, new TextArgument("message", false));
        $this->setPermission($this->getPermission());
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez accès a cette commande");
            return;
        }

        $config = new Config(Main::getInstance()->getDataFolder() . "block_player.yml", Config::YAML);

        if (!($sender instanceof Player)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour utiliser cette commande");
            return;
        }

        if (isset($args["player"])) {
            $player = Server::getInstance()->getPlayerByPrefix($args["player"]);
            if ($player instanceof Player) {
                $playerReal = $player->getName();
                if ((isset($config->get($player)[$sender->getName()]))) {
                    $sender->sendMessage(Utils::PREFIX . "§cL'utilisateur vous a bloqué");
                    return;
                }
                if (isset($config->get($sender->getName())[$playerReal])) {
                    $sender->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas envoyer de message à un utilisateur que vous avez bloqué");
                    return;
                }
                if (isset($args["message"]) && !empty($args["message"])) {
                    $msg = implode(" ", array_slice($args, 1));
                    self::$msg[$sender->getName()] = $player->getName();
                    self::$msg[$player->getName()] = $sender->getName();
                    $sender->sendMessage("§f[§dMoi§f] -> [§d{$player->getName()}§f] : {$msg}");
                    $player->sendMessage("§f[§d{$sender->getName()}§f] -> [§dMoi§f] : {$msg}");
                } else {
                    $sender->sendMessage(Utils::PREFIX . "§cVeuillez entrer un message");
                }
            } else {
                $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'existe pas");
            }
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cVeuillez entrer un joueur");
        }

    }

    public function getPermission(): string
    {
        return "lunarium.basic";
    }
}