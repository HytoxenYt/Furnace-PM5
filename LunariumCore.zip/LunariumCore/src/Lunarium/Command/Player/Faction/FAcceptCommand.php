<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Utils\Utils;

class FAcceptCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;
        
        if (!Main::getInstance()->getFactionManager()->isInFaction($sender)) {
            if (Main::getInstance()->getFactionManager()->hasInvitationPlayer($sender)) {
                if (Main::getInstance()->getFactionManager()->isValidInvitation($sender)) {
                    Main::getInstance()->getFactionManager()->addMemberInFaction(Main::getInstance()->getFactionManager()->getFactionInvite($sender), $sender);
                    $sender->sendMessage(Utils::PREFIX . "Vous avez rejoins la faction §d" . Main::getInstance()->getFactionManager()->getFactionInvite($sender));
                } else $sender->sendMessage(Utils::PREFIX . "§cL'invitation n'est plus valide");
            } else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas d'invitation");
        } else $sender->sendMessage(Utils::PREFIX . "§cVous êtes déjà dans une faction");
    }
}