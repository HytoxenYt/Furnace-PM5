<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FPlayerCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", true));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player) {
            if (isset($args["player"])) {
                $player = Main::getInstance()->getServer()->getPlayerByPrefix($args["player"]);
                if ($player instanceof Player) $name = $player->getName(); else $name = $args["player"];
                if (Main::getInstance()->getFactionManager()->isInFaction($name)) {
                    $sender->sendMessage(Utils::PREFIX . "§d" . $name . " §fest dans la faction §d" . Main::getInstance()->getFactionManager()->getFactionPlayer($name) . " §fet il à §d" . Main::getInstance()->getFactionManager()->getPowerPlayer($name) . " powers");
                } else $sender->sendMessage(Utils::PREFIX . "§fVous êtes dans la faction §dAucune§f et vous avez §d" . Main::getInstance()->getFactionManager()->getPowerPlayer($name) . " powers");
            } else {
                if (Main::getInstance()->getFactionManager()->isInFaction($sender)) {
                    $sender->sendMessage(Utils::PREFIX . "§fVous êtes dans la faction §d" . Main::getInstance()->getFactionManager()->getFactionPlayer($sender) . " §fet vous avez §d" . Main::getInstance()->getFactionManager()->getPowerPlayer($sender) . " powers");
                } else $sender->sendMessage(Utils::PREFIX . "§fVous êtes dans la faction §dAucune§f et vous avez §d" . Main::getInstance()->getFactionManager()->getPowerPlayer($sender) . " powers");
            }
        } else $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour faire cette commande");
    }
}