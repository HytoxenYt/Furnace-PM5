<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FKickCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }
        if(Main::getInstance()->getFactionManager()->isInFaction($sender)){
            if(Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "KICK")){
                if(isset($args["player"])){
                    $player = Main::getInstance()->getServer()->getPlayerByPrefix($args["player"]);
                    if ($player instanceof Player) $name = $player->getName(); else $name = $args["player"];
                    if(Main::getInstance()->getFactionManager()->isInFaction($name)){
                        if(Main::getInstance()->getFactionManager()->getFactionPlayer($name) === Main::getInstance()->getFactionManager()->getFactionPlayer($sender)){
                            Main::getInstance()->getFactionManager()->removeMemberInFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $name);
                            $sender->sendMessage(Utils::PREFIX . "§fVous avez bien kick §d" . $name . " §fde votre faction");
                        }else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'est pas dans votre faction");
                    }else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'est pas dans votre faction");
                }else $sender->sendMessage(Utils::PREFIX . "§cVous devez renseigner un joueur");
            }else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission de kick des joueurs");
        }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
    }
}