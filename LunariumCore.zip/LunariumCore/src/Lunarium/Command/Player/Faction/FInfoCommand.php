<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FInfoCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new RawStringArgument("faction", true));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }
        $faction = "";
        if (isset($args["faction"])) {
            $faction = $args["faction"];
            if (!Main::getInstance()->getFactionManager()->existFaction($faction)) {
                $sender->sendMessage(Utils::PREFIX . "§cLa faction §d$faction §cn'existe pas");
                return;
            }
        } else {
            if (Main::getInstance()->getFactionManager()->isInFaction($sender)) {
                $faction = Main::getInstance()->getFactionManager()->getFactionPlayer($sender);
            } else {
                $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
                return;
            }
        }
        $members = [];
        foreach (Main::getInstance()->getFactionManager()->getAllMembersFaction($faction) as $member => $rank) {
            $members[] = $member;
        }
        $sender->sendMessage(Utils::PREFIX . "§fInformations sur la faction §d" . $faction);
        $sender->sendMessage("- §fChef: §d" . Main::getInstance()->getFactionManager()->getOwnerFaction($faction));
        $sender->sendMessage("- §fMembres: §d" . implode(", ", $members) . " §f: Membre(s) total: §d" . count(Main::getInstance()->getFactionManager()->getAllMembersFaction($faction)) . " §f(§d" . $this->getOnlineMembersFaction($faction) . " §fconnectés)");
        $sender->sendMessage("- §fPowers: §d" . Main::getInstance()->getFactionManager()->getPowerFaction($faction));
        $sender->sendMessage("- §fNiveaux: §d" . Main::getInstance()->getFactionManager()->getNiveauFaction($faction));
        $description = Main::getInstance()->getFactionManager()->getDescriptionFaction($faction);
        if (!empty($description)) {
            $sender->sendMessage("- §fDescription: §d" . $description);
        } else {
            $sender->sendMessage("- §fDescription: §dAucune");
        }
        $allies = Main::getInstance()->getFactionManager()->getAlliesFaction($faction);
        if (!empty($allies)) {
            $sender->sendMessage("- §fAlliés: §d" . implode(", ", $allies));
        } else {
            $sender->sendMessage("- §fAlliés: §dAucun");
        }
        $sender->sendMessage("- §fCréer le §d" . Main::getInstance()->getFactionManager()->getAgeFaction($faction)["Jour"]);
    }

    public function getOnlineMembersFaction(string $faction): int
    {
        $online = 0;
        foreach (Main::getInstance()->getFactionManager()->getAllMembersFaction($faction) as $member => $rank) {
            if (Main::getInstance()->getServer()->getPlayerByPrefix($member) !== null) {
                $online++;
            }
        }
        return $online;
    }
}