<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FRenameCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new TextArgument("nom"));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!isset($args["nom"])) {
            $sender->sendMessage(Utils::PREFIX . "§cVeuillez mettre un nom");
            return;
        }
        if ($sender instanceof Player) {
            if (Main::getInstance()->getFactionManager()->isInFaction($sender)) {
                if (Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "RENAME")) {
                    Main::getInstance()->getFactionManager()->renameFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $args["nom"]);
                    $sender->sendMessage(Utils::PREFIX . "§fVous avez bien défini le nouveau nom de votre faction");
                } else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission de faire ça");
            } else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
        }
    }
}