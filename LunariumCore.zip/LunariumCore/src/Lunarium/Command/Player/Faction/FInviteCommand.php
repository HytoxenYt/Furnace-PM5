<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class FInviteCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }
        if (Main::getInstance()->getFactionManager()->isInFaction($sender)) {
            if (Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "INVITE")) {
                if (Main::getInstance()->getFactionManager()->countPlayerInFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender)) === 20) {
                    $sender->sendMessage(Utils::PREFIX . "§cVotre faction est pleine");
                    return;
                }

                $player = Server::getInstance()->getPlayerByPrefix($args["player"]);
                if($player instanceof Player) {
                    if (!Main::getInstance()->getFactionManager()->isInFaction($player)) {
                        Main::getInstance()->getFactionManager()->invitePlayerInFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $player);
                        $sender->sendMessage(Utils::PREFIX . "§fVous avez invité §d" . $player->getName() . " §fdans votre faction");
                        $player->sendMessage(Utils::PREFIX . "§d" . $sender->getName() . " §fvous à invité dans sa faction");
                    } else $sender->sendMessage(Utils::PREFIX . "§d" . $player->getName() . " §cest déjà dans une faction");
                }else $sender->sendMessage(Utils::PREFIX . "§cLe joueur §d" . $args["player"] . " §cest introuvable");
            }else $sender->sendMessage(Utils::PREFIX."§cVous n'avez pas la permission d'utiliser cette commande");
        }else $sender->sendMessage(Utils::PREFIX."§cVous n'êtes pas dans une faction");
    }
}