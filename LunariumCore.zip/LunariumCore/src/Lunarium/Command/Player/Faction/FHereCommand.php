<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Utils\Utils;

class FHereCommand extends BaseSubCommand
{
    protected function prepare(): void
    {

    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player) {
            $factionAPI = Main::getInstance()->getFactionManager();

            if($factionAPI->isChunkClaim($sender->getPosition())){
                $chunkClaim = $factionAPI->getFactionClaim($sender->getPosition());
                $sender->sendMessage(Utils::PREFIX . "§fCe chunk est claim par la faction §d" . $chunkClaim);
            }else {
                $sender->sendMessage(Utils::PREFIX . "§fCe chunk n'est pas claim");
            }
        }
    }
}