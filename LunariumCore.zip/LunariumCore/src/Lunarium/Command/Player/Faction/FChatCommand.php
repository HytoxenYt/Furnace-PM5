<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Managers\FactionManager;
use Lunarium\Utils\Utils;

class FChatCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        // TODO: Implement prepare() method.
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }
        if (Main::getInstance()->getFactionManager()->isInFaction($sender)) {
            if (Main::getInstance()->getFactionManager()->getChatPlayer($sender) === "global") {
                FactionManager::$chat[$sender->getName()] = $sender->getName();
                $sender->sendMessage(Utils::PREFIX . "§fVous parlez dans le chat de votre faction");
            } else {
                if (Main::getInstance()->getFactionManager()->getChatPlayer($sender) === "faction") {
                    unset(FactionManager::$chat[$sender->getName()]);
                    $sender->sendMessage(Utils::PREFIX . "§fVous ne parlez plus dans le §dchat global");
                } else $sender->sendMessage(Utils::PREFIX . "§cTu doit quitté le §dchat alliance");
            }
        } else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
    }
}