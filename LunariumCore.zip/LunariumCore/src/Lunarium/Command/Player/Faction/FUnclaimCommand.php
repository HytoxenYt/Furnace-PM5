<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FUnclaimCommand extends BaseSubCommand

{
    protected function prepare(): void
    {

    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if($sender instanceof Player){
            if(Main::getInstance()->getFactionManager()->isInFaction($sender)){
                if(Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "UNCLAIM")){
                    if(Main::getInstance()->getFactionManager()->isChunkClaim($sender->getPosition())){
                        if(Main::getInstance()->getFactionManager()->getFactionClaim($sender->getPosition()) === Main::getInstance()->getFactionManager()->getFactionPlayer($sender)){
                            Main::getInstance()->getFactionManager()->unclaimChunk($sender->getPosition());
                            $sender->sendMessage(Utils::PREFIX . "§fVous avez bien unclaim le chunk");
                        }else $sender->sendMessage(Utils::PREFIX . "§cCe chunk ne vous appartient pas");
                    }else $sender->sendMessage(Utils::PREFIX . "§cCe chunk n'est pas claim");
                }else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission de unclaim des chunks");
            }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
        }else $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour executer cette commande");
    }
}