<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Managers\FactionManager;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FAllyAcceptCommand extends BaseSubCommand
{
    protected function prepare(): void
    {

    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }
        if(Main::getInstance()->getFactionManager()->isInFaction($sender)){
            if(Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "ALLY")){
                if(Main::getInstance()->getFactionManager()->hasInvitationAlly(Main::getInstance()->getFactionManager()->getFactionPlayer($sender))){
                    if(Main::getInstance()->getFactionManager()->isValidInvitationAlly(Main::getInstance()->getFactionManager()->getFactionPlayer($sender))){
                        if(!Main::getInstance()->getFactionManager()->isAlly(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), FactionManager::$invitation_ally[Main::getInstance()->getFactionManager()->getFactionPlayer($sender)]["faction"])){
                            Main::getInstance()->getFactionManager()->addAllyFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), FactionManager::$invitation_ally[Main::getInstance()->getFactionManager()->getFactionPlayer($sender)]["faction"]);
                            $sender->sendMessage(Utils::PREFIX . "§fVous avez bien accepté l'alliance avec la faction §d" . FactionManager::$invitation_ally[Main::getInstance()->getFactionManager()->getFactionPlayer($sender)]["faction"]);
                        }else $sender->sendMessage(Utils::PREFIX . "§cVotre faction est déjà allié avec cette faction");
                    }else $sender->sendMessage(Utils::PREFIX . "§cL'invitation à expiré");
                }else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas d'invitation");
            }else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission d'accepter des alliances");
        }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
    }
}