<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Managers\FactionManager;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Utils\Utils;

class FAllyChatCommand extends BaseSubCommand
{
    protected function prepare(): void
    {

    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if($sender instanceof Player){
            if(Main::getInstance()->getFactionManager()->isInFaction($sender)){
                if(Main::getInstance()->getFactionManager()->getChatPlayer($sender) === "global"){
                    FactionManager::$chat_ally[$sender->getName()] = $sender->getName();
                    $sender->sendMessage(Utils::PREFIX . "§fVous parlez dans le chat allié");
                }else{
                    if(Main::getInstance()->getFactionManager()->getChatPlayer($sender) === "ally"){
                        unset(FactionManager::$chat_ally[$sender->getName()]);
                        $sender->sendMessage(Utils::PREFIX . "§fVous ne parlez plus dans le chat allié");
                    }else $sender->sendMessage(Utils::PREFIX . "§cVous devez quitté le chat faction");
                }
            }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
        }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas un joueur");
    }
}