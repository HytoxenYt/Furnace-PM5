<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use pocketmine\command\CommandSender;

class FMissionCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        // TODO: Implement prepare() method.
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        /**if ($sender instanceof Player) {

            if (Lunarium::getInstance()->getFactionAPI()->isInFaction($sender)) {
                $quest = Lunarium::getInstance()->getFactionAPI()->getQuests(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($sender));
                $invmenu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
                $invmenu->setName("§9Missions de Faction");
                $number = [0, 1, 2, 3, 4, 5, 6, 7, 8, 18, 19, 20, 21, 22, 23, 24, 25, 26];
                foreach ($number as $slot) {
                    $invmenu->getInventory()->setItem($slot, VanillaBlocks::STAINED_GLASS_PANE()->setColor(DyeColor::PINK)->asItem());
                }
                $invmenu->getInventory()->setItem(17, VanillaItems::PAPER()->setLore(["\n§fLes missions se renouvellent toutes les 7 jours"])->setCustomName("§6Missions de Faction"));
                $invmenu->getInventory()->setItem(9, VanillaBlocks::GRASS()->asItem()->setCustomName("§6Mission 1")->setLore(
                    [
                        "§fObjectif: §9" . $quest[1]["description"],
                        "§fProgression: §9" . $quest[1]["progression"] . "§f/§9" . $quest[1]["objectif"],
                        "§fRécompense: §9" . $quest[1]["reward"]["money"] . "§f$",
                        "§fStatut: §9" . $quest[1]["finish"],
                    ]
                ));

                $invmenu->getInventory()->setItem(11, VanillaItems::STICK()->setCustomName("§6Mission 2")->setLore(
                    [
                        "§fObjectif: §9" . $quest[2]["description"],
                        "§fProgression: §9" . $quest[2]["progression"] . "§f/§9" . $quest[2]["objectif"],
                        "§fRécompense: §9" . $quest[2]["reward"]["money"] . "§f$",
                        "§fStatut: §9" . $quest[2]["finish"],
                    ]
                ));

                $invmenu->getInventory()->setItem(13, VanillaBlocks::COBBLESTONE()->asItem()->setCustomName("§6Mission 3")->setLore(
                    [
                        "§fObjectif: §9" . $quest[3]["description"],
                        "§fProgression: §9" . $quest[3]["progression"] . "§f/§9" . $quest[3]["objectif"],
                        "§fRécompense: §9" . $quest[3]["reward"]["money"] . "§f$",
                        "§fStatut: §9" . $quest[3]["finish"],
                    ]
                ));

                $invmenu->getInventory()->setItem(15, VanillaBlocks::ENCHANTING_TABLE()->asItem()->setCustomName("§6Mission 4")->setLore(
                    [
                        "§fObjectif: §9" . $quest[4]["description"],
                        "§fProgression: §9" . $quest[4]["progression"] . "§f/§9" . $quest[4]["objectif"],
                        "§fRécompense: §9" . $quest[4]["reward"]["money"] . "§f$",
                        "§fStatut: §9" . $quest[4]["finish"],
                    ]
                ));

                $invmenu->getInventory()->setItem(17, VanillaBlocks::STONE()->asItem()->setCustomName("§6Mission 5")->setLore(
                    [
                        "§fObjectif: §9" . $quest[5]["description"],
                        "§fProgression: §9" . $quest[5]["progression"] . "§f/§9" . $quest[5]["objectif"],
                        "§fRécompense: §9" . $quest[5]["reward"]["money"] . "§f$",
                        "§fStatut: §9" . $quest[5]["finish"],
                    ]
                ));

                $invmenu->setListener(function (InvMenuTransaction $transaction): InvMenuTransactionResult {
                    if ($transaction->getItemClicked()->getTypeId() === VanillaBlocks::GRASS()->asItem()->getTypeId()) {
                        if (Lunarium::getInstance()->getFactionAPI()->getFinishQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 1) === "§cNon terminé") {
                            $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous n'avez pas finis la quête n°§91");
                        } else {
                            if (Lunarium::getInstance()->getFactionAPI()->getQuests(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()))[1]["recup"] === "false") {
                                $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez récupéré la récompense de la quête n°§91");
                                $factionOwner = Lunarium::getInstance()->getFactionAPI()->getOwnerFaction(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()));
                                $player = Lunarium::getInstance()->getServer()->getPlayerByPrefix($factionOwner);
                                if ($player !== null) {

                                    MoneyManager::addMoney($player, Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 1));
                                    $player->sendMessage(Utils::$prefix . "§fVotre faction a finis la quête §9n°1§f et le chef de faction à gagné §9" . Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 1) . "§f$");
                                    Lunarium::getInstance()->getFactionAPI()->setRecupQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 1, "true");
                                }
                            } else {
                                $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez déjà récupéré la récompense de la quête n°§91");

                            }
                        }
                        return $transaction->discard();
                    }

                    if ($transaction->getItemClicked()->getTypeId() === VanillaItems::STICK()->getTypeId()) {
                        if (Lunarium::getInstance()->getFactionAPI()->getFinishQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 2) === "§cNon terminé") {
                            $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous n'avez pas finis la quête n°§92");
                        } else {
                            $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez récupéré la récompense de la quête n°§92");
                            $factionOwner = Lunarium::getInstance()->getFactionAPI()->getOwnerFaction(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()));
                            $player = Lunarium::getInstance()->getServer()->getPlayerByPrefix($factionOwner);
                            if ($player !== null) {
                                MoneyManager::addMoney($player, Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 2));
                                $player->sendMessage(Utils::$prefix . "§fVotre faction a finis la quête §9n°2§f et le chef de faction à gagné §9" . Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 2) . "§f$");
                            }
                        }
                        return $transaction->discard();
                    }

                    if ($transaction->getItemClicked()->getTypeId() === VanillaBlocks::COBBLESTONE()->asItem()->getTypeId()) {
                        if (Lunarium::getInstance()->getFactionAPI()->getFinishQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 3) === "§cNon terminé") {
                            $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous n'avez pas finis la quête n°§93");
                        } else {
                            if (Lunarium::getInstance()->getFactionAPI()->getQuests(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()))[3]["recup"] === "false") {
                                $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez récupéré la récompense de la quête n°§93");
                                $factionOwner = Lunarium::getInstance()->getFactionAPI()->getOwnerFaction(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()));
                                $player = Lunarium::getInstance()->getServer()->getPlayerByPrefix($factionOwner);
                                if ($player !== null) {
                                    MoneyManager::addMoney($player, Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 3));
                                    $player->sendMessage(Utils::$prefix . "§fVotre faction a finis la quête §9n°3§f et le chef de faction à gagné §9" . Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 3) . "§f$");
                                    Lunarium::getInstance()->getFactionAPI()->setRecupQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 3, "true");
                                }
                            } else {
                                $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez déjà récupéré la récompense de la quête n°§93");

                            }
                        }
                        return $transaction->discard();
                    }

                    if ($transaction->getItemClicked()->getTypeId() === VanillaBlocks::ENCHANTING_TABLE()->asItem()->getTypeId()) {
                        if (Lunarium::getInstance()->getFactionAPI()->getFinishQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 4) === "§cNon terminé") {
                            $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous n'avez pas finis la quête n°§94");
                        } else {
                            if (Lunarium::getInstance()->getFactionAPI()->getQuests(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()))[4]["recup"] === "false") {
                                $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez récupéré la récompense de la quête n°§94");
                                $factionOwner = Lunarium::getInstance()->getFactionAPI()->getOwnerFaction(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()));
                                $player = Lunarium::getInstance()->getServer()->getPlayerByPrefix($factionOwner);
                                if ($player !== null) {

                                    MoneyManager::addMoney($player, Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 4));
                                    $player->sendMessage(Utils::$prefix . "§fVotre faction a finis la quête §9n°4§f et le chef de faction à gagné §9" . Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 4) . "§f$");
                                    Lunarium::getInstance()->getFactionAPI()->setRecupQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 4, "true");
                                }
                            } else {
                                $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez déjà récupéré la récompense de la quête n°§94");

                            }
                        }
                        return $transaction->discard();
                    }

                    if ($transaction->getItemClicked()->getTypeId() === VanillaBlocks::STONE()->asItem()->getTypeId()) {
                        if (Lunarium::getInstance()->getFactionAPI()->getFinishQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 5) === "§cNon terminé") {
                            $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous n'avez pas finis la quête n°§95");
                        } else {
                            if (Lunarium::getInstance()->getFactionAPI()->getQuests(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()))[5]["recup"] === "false") {
                                $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez récupéré la récompense de la quête n°§95");
                                $factionOwner = Lunarium::getInstance()->getFactionAPI()->getOwnerFaction(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()));
                                    $player = Lunarium::getInstance()->getServer()->getPlayerByPrefix($factionOwner);
                                if ($player !== null) {
                                    MoneyManager::addMoney($player, Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 5));
                                    $player->sendMessage(Utils::$prefix . "§fVotre faction a finis la quête §9n°5§f et le chef de faction à gagné §9" . Lunarium::getInstance()->getFactionAPI()->getRewardMoneyQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 5) . "§f$");
                                    Lunarium::getInstance()->getFactionAPI()->setRecupQuest(Lunarium::getInstance()->getFactionAPI()->getFactionPlayer($transaction->getPlayer()), 5, "true");
                                }
                            } else {
                                $transaction->getPlayer()->sendMessage(Utils::$prefix . "§fVous avez déjà récupéré la récompense de la quête n°§95");

                            }
                        }
                        return $transaction->discard();
                    }
                    return $transaction->discard();
                });
                $invmenu->send($sender);
            }
        }
         */
    }
}