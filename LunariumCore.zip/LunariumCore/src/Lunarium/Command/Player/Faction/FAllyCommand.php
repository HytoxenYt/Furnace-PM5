<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Utils\Utils;

class FAllyCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new RawStringArgument("faction", false));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player) {
            if (Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "ALLY")) {
                if (isset($args["faction"])) {
                    if (Main::getInstance()->getFactionManager()->existFaction($args["faction"])) {
                        if (!Main::getInstance()->getFactionManager()->isAlly(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $args["faction"])) {
                            if (Main::getInstance()->getFactionManager()->countAllyFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender)) === 5) {
                                $sender->sendMessage(Utils::PREFIX . "§cVotre faction à atteint le nombre maximum d'alliance");
                                return;
                            }
                            Main::getInstance()->getFactionManager()->inviteAlly(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $args["faction"]);
                            $sender->sendMessage(Utils::PREFIX . "§aVous avez envoyé une invitation d'alliance à la faction §d" . $args["faction"]);
                            Main::getInstance()->getFactionManager()->sendChatFaction($args["faction"], Utils::PREFIX . "§cLa faction §d" . Main::getInstance()->getFactionManager()->getFactionPlayer($sender) . " §fvous à demandé une alliance");
                        } else $sender->sendMessage(Utils::PREFIX . "§cVotre faction est déjà allié avec cette faction");
                    } else $sender->sendMessage(Utils::PREFIX . "§cCette faction n'existe pas");
                } else $sender->sendMessage(Utils::PREFIX . "§cVeuillez mettre une faction");
            } else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission de faire ça");
        } else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas un joueur");
    }
}