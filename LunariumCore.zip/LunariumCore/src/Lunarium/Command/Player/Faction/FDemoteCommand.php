<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FDemoteCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (isset($args["player"])) {
            if ($sender instanceof Player) {
                if (Main::getInstance()->getFactionManager()->isInFaction($sender)) {
                    if (Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "DEMOTE")) {
                        $player = Main::getInstance()->getServer()->getPlayerByPrefix($args["player"]);
                        if ($player instanceof Player) $name = $player->getName(); else $name = $args["player"];
                        if (Main::getInstance()->getFactionManager()->isInFaction($name)) {
                            if (Main::getInstance()->getFactionManager()->getFactionPlayer($sender) === Main::getInstance()->getFactionManager()->getFactionPlayer($name)) {
                                if (Main::getInstance()->getFactionManager()->getOwnerFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender)) !== $name) {
                                    if (Main::getInstance()->getFactionManager()->getRankPlayerInFaction($name) !== "chef") {
                                        Main::getInstance()->getFactionManager()->demotePlayerInFaction($name);
                                        $sender->sendMessage(Utils::PREFIX . "§fVous avez bien rétrogradé §d" . $name . " §fdans votre faction");
                                    } else $sender->sendMessage(Utils::PREFIX . "§cCe joueur est déjà au grade minimum");
                                } else $sender->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas rétrograder le chef de la faction");
                            } else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'est pas dans votre faction");
                        } else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'est pas dans votre faction");
                    } else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission de rétrograder des joueurs");
                } else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
            } else $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour executer cette commande");
        }
    }
}