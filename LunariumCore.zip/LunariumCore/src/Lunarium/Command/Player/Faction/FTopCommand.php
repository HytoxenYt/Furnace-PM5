<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Managers\FactionManager;
use Lunarium\Utils\Utils;
use pocketmine\player\Player;
use pocketmine\command\CommandSender;

class FTopCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new IntegerArgument("page", true));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $page = 1;

        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }

        $page1 = $args["page"];
        if(isset($page1)){
            if(is_numeric($page1)) {
                $this->sendListOfTop10FactionsTo($sender, intval($page1));
            }
        }else{
            $this->sendListOfTop10FactionsTo($sender, $page);
        }
    }

    public function sendListOfTop10FactionsTo(Player $s, $page = 1): void
    {
        $api = Main::getInstance()->getFactionManager();

        $factions = [];
        foreach (FactionManager::$data->getAll() as $faction => $data) {
            $factions[$faction] = $api->getPowerFaction($faction);
        }

        arsort($factions);
        $maxpages = intval(abs(count($factions) / 10));
        $reste = count($factions) % 10;
        if ($reste > 0) {
            $maxpage = $maxpages + 1;
        } else {
            $maxpage = $maxpages;
        }
        if ($page == 1) {
            $deptop = 1;
            $fintop = 11;
            $page = 1;
        } else {
            $deptop = (($page - 1) * 10) + 1;
            $fintop = (($page - 1) * 10) + 11;
            $page = $page;
        }
        if ($page > $maxpage){
            $s->sendMessage(Utils::PREFIX . "§cVeuillez spécifier une page entre §91§f et§9 {$maxpage}");
            return;
        }
        $top = 1;

        $s->sendMessage("§1- §fListe des factions avec le plus de powers §9[{$page}/{$maxpage}] §1-");
        $s->sendMessage("\n");
        foreach ($factions as $faction => $power) {
            if ($top === $fintop) break;
            if ($top >= $deptop) {
                $members = $api->getAllMembersFaction($faction);
                $memberCount = is_array($members) ? count($members) : 0;

                $s->sendMessage("§9#{$top} §f- §9{$faction} §favec §9{$power} power" . ($power > 1 ? "s" : "") . " §fet §9{$memberCount} joueur" . ($memberCount > 1 ? "s" : ""));
            }
            $top++;
        }
        $s->sendMessage("\n");
        $s->sendMessage(Utils::PREFIX . "Vous devez faire §9/f top (numéro de page) §fpour voir la liste des factions les plus puissantes");
    }
}