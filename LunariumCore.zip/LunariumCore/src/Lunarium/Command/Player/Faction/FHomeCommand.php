<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Lunarium;
use Lunarium\Utils\Utils;

class FHomeCommand extends BaseSubCommand
{
    protected function prepare(): void
    {

    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player) {
            if (Main::getInstance()->getFactionManager()->isInFaction($sender)) {
                if (Main::getInstance()->getFactionManager()->hasHomeFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender))) {
                    $sender->teleport(Main::getInstance()->getFactionManager()->getPositionHomeFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender)));
                    $sender->sendMessage(Utils::PREFIX . "§fVous avez été téléporté au home de votre faction");
                } else $sender->sendMessage(Utils::PREFIX . "§cVotre faction n'a pas de home");
            } else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
        } else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas un joueur");
    }
}