<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Utils\Utils;

class FCreateCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new RawStringArgument("faction", false));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }

        $faction = $args["faction"] ?? null;

        if ($faction) {
            $length = strlen($faction);
            if ($length < 3 || $length > 20) {
                $sender->sendMessage(Utils::PREFIX . "§cLe nom de la faction doit contenir entre 3 et 20 caractères");
                return;
            }

            if (!Main::getInstance()->getFactionManager()->isInFaction($sender)) {
                if (!Main::getInstance()->getFactionManager()->existFaction($faction)) {
                    Main::getInstance()->getFactionManager()->createFaction($faction, $sender);
                } else {
                    $sender->sendMessage(Utils::PREFIX . "La faction §d{$faction}§c existe déjà");
                }
            } else {
                $sender->sendMessage(Utils::PREFIX . "Vous êtes déjà dans une faction");
            }
        } else {
            $sender->sendMessage(Utils::PREFIX . "Vous devez indiquer une faction");
        }
    }
}
