<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FLeaveCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        // TODO: Implement prepare() method.
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }
        if(Main::getInstance()->getFactionManager()->isInFaction($sender)) {
            if (Main::getInstance()->getFactionManager()->getOwnerFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender)) !== $sender->getName()) {
                Main::getInstance()->getFactionManager()->removeMemberInFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $sender);
                $sender->sendMessage(Utils::PREFIX."§fVous avez bien quitté la faction");
            }else $sender->sendMessage(Utils::PREFIX."§cVous ne pouvez pas quitter votre faction car vous êtes le chef");
        }else $sender->sendMessage(Utils::PREFIX."§cVous n'êtes pas dans une faction");
    }
}