<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FUnallyCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new RawStringArgument("faction", false));
    }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if($sender instanceof Player){
            if(Main::getInstance()->getFactionManager()->isInFaction($sender)){
                if(Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "ALLY")){
                    if(isset($args["faction"])){
                        if(Main::getInstance()->getFactionManager()->existFaction($args["faction"])){
                            if(Main::getInstance()->getFactionManager()->isAlly(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $args["faction"])){
                                Main::getInstance()->getFactionManager()->removeAllyFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $args["faction"]);
                                $sender->sendMessage(Utils::PREFIX . "§fVous avez bien rompu l'alliance avec la faction §d".$args["faction"]);
                            }else $sender->sendMessage(Utils::PREFIX . "§cCette faction n'est pas allié avec vous");
                        }else $sender->sendMessage(Utils::PREFIX . "§cCette faction n'existe pas");
                    }else $sender->sendMessage(Utils::PREFIX . "§cVeuillez mettre une faction");
                }else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission de faire ça");
            }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
        }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas un joueur");
    }
}