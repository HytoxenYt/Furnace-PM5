<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use Lunarium\Lunarium;
use Lunarium\Utils\Utils;

class FDisbandCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new RawStringArgument("faction", false));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }
        if (!$sender->hasPermission("lunarium.admin") || !Server::getInstance()->isOp($sender->getName())) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission d'utiliser cette commande");
            return;
        }
        if (isset($args["faction"])) {
            if (Main::getInstance()->getFactionManager()->existFaction($args["faction"])) {
                Main::getInstance()->getFactionManager()->deleteFaction($args["faction"]);
                $sender->sendMessage(Utils::PREFIX . "§fVous avez bien §dsupprimé§f la faction §d" . $args["faction"]);
            } else $sender->sendMessage(Utils::PREFIX . "§cCette faction n'existe pas");
        } else $sender->sendMessage(Utils::PREFIX . "§cVous devez renseigner une faction");
    }
}