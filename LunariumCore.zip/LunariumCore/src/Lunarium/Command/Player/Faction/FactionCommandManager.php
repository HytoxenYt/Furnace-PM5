<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;

class FactionCommandManager extends BaseCommand
{
    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->registerSubCommand(new FAcceptCommand("accept", "Accepter une invitation dans une faction"));
        $this->registerSubCommand(new FAllyCommand("ally", "Allier une faction"));
        $this->registerSubCommand(new FAllyAcceptCommand("allyaccept", "Accepter une demande d'alliance"));
        $this->registerSubCommand(new FAllyChatCommand("allychat", "Parler dans le chat allié"));
        $this->registerSubCommand(new FChatCommand("chat", "Parler dans le chat de faction"));
        $this->registerSubCommand(new FClaimCommand("claim", "Claim un chunk"));
        $this->registerSubCommand(new FCreateCommand("create", "Créer une faction"));
        $this->registerSubCommand(new FDeleteCommand("delete", "Supprimer une faction"));
        $this->registerSubCommand(new FDemoteCommand("demote", "Rétrograder un membre de la faction"));
        $this->registerSubCommand(new FDescriptionCommand("description", "Définir la description de la faction"));
        $this->registerSubCommand(new FDisbandCommand("disband", "Dissoudre une faction"));
        $this->registerSubCommand(new FHomeCommand("home", "Téléportation au home de la faction"));
        $this->registerSubCommand(new FInfoCommand("info", "Voir les informations d'une faction"));
        $this->registerSubCommand(new FInviteCommand("invite", "Inviter un joueur dans la faction"));
        $this->registerSubCommand(new FKickCommand("kick", "Exclure un joueur de la faction"));
        $this->registerSubCommand(new FLeadCommand("lead", "Passer le lead de la faction"));
        $this->registerSubCommand(new FLeaveCommand("leave", "Quitter une faction"));
        $this->registerSubCommand(new FPlayerCommand("player", "Voir les informations d'un joueur"));
        $this->registerSubCommand(new FPromoteCommand("promote", "Promouvoir un membre de la faction"));
        $this->registerSubCommand(new FSethomeCommand("sethome", "Définir le home de la faction"));
        $this->registerSubCommand(new FTopCommand("top", "Voir le top des factions"));
        $this->registerSubCommand(new FUnallyCommand("unally", "Rompre une alliance"));
        $this->registerSubCommand(new FUnclaimCommand("unclaim", "UnclaimFinder un chunk"));
        //$this->registerSubCommand(new FMissionCommand("mission", "Voir vos missions"));
        $this->registerSubCommand(new FRenameCommand("rename", "Renommer votre faction"));
        $this->registerSubCommand(new FHereCommand("here", "Voir quel faction possède le claim"));
    }

    public function getPermission(): string
    {
        return "faction.use";
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $sender->sendMessage(Utils::PREFIX . "§fVoici toutes les commandes de faction");
        foreach($this->getSubCommands() as $command){
            $sender->sendMessage("§d/f {$command->getName()} §f- {$command->getDescription()}");
        }
    }
}