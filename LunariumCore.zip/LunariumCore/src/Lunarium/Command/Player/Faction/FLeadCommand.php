<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class FLeadCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", true));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player){
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur");
            return;
        }
        if(Main::getInstance()->getFactionManager()->isInFaction($sender)){
            if(Main::getInstance()->getFactionManager()->getOwnerFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender)) === $sender->getName()){
                if(isset($args["player"])){
                    $player = Server::getInstance()->getPlayerByPrefix($args["player"]);
                    if($player instanceof Player) $name = $player->getName(); else $name = $args["player"];
                    if(Main::getInstance()->getFactionManager()->isInFaction($name)){
                        if(Main::getInstance()->getFactionManager()->getFactionPlayer($name) === Main::getInstance()->getFactionManager()->getFactionPlayer($sender)){
                            Main::getInstance()->getFactionManager()->setOwnerFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender), $name);
                            $sender->sendMessage(Utils::PREFIX . "§fVous avez bien donné la faction à §d" . $name);
                            if($player instanceof Player) $player->sendMessage(Utils::PREFIX . "§fVous êtes le chef de la faction §d" . Main::getInstance()->getFactionManager()->getFactionPlayer($sender));
                        }else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'est pas dans votre faction");
                    }else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'est pas dans votre faction");
                }else $sender->sendMessage(Utils::PREFIX . "§cVous devez renseigner un joueur");
            }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas le chef de la faction");
        }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
    }
}