<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Lunarium\Utils\Utils;

class FClaimCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        // TODO: Implement prepare() method.
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player) {
            $factionAPI = Main::getInstance()->getFactionManager();

            if ($factionAPI->isInFaction($sender)) {
                if ($factionAPI->hasPermissionInFaction($sender, "CLAIM")) {
                    if (!$factionAPI->isChunkClaim($sender->getPosition())) {
                        $faction = $factionAPI->getFactionPlayer($sender);
                        $claimCount = $factionAPI->countClaimFaction($faction);
                        $power = 100 + ($claimCount * 500);
                        if ($claimCount < 9) {
                            if ($factionAPI->getPowerFaction($faction) >= $power) {
                                $factionAPI->claimChunk($faction, $sender->getPosition());
                                $sender->sendMessage(Utils::PREFIX . "§aVotre faction a claim ce chunk");
                            } else {
                                $sender->sendMessage(Utils::PREFIX . "§fVous avez besoin de §d$power powers §fpour claim une zone");
                            }
                        } else {
                            $sender->sendMessage(Utils::PREFIX . "§fVotre faction a atteint le nombre maximum de claims");
                        }

                    } else {
                        $sender->sendMessage(Utils::PREFIX . "§cCe chunk est déjà claim");
                    }
                } else {
                    $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission de claim des chunks");
                }
            } else {
                $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
            }
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour exécuter cette commande");
        }
    }
}