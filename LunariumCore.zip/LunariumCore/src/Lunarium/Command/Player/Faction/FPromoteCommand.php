<?php

namespace Lunarium\Command\Player\Faction;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseSubCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FPromoteCommand extends BaseSubCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("player", false));
    }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if($sender instanceof Player){
            if(isset($args["player"])){
                if(Main::getInstance()->getFactionManager()->isInFaction($sender)){
                    if(Main::getInstance()->getFactionManager()->hasPermissionInFaction($sender, "PROMOTE")){
                        $player = Main::getInstance()->getServer()->getPlayerByPrefix($args["player"]);
                        if ($player instanceof Player) $name = $player->getName(); else $name = $args["player"];
                        if(Main::getInstance()->getFactionManager()->isInFaction($name)){
                            if(Main::getInstance()->getFactionManager()->getFactionPlayer($name) === Main::getInstance()->getFactionManager()->getFactionPlayer($sender)){
                                if(Main::getInstance()->getFactionManager()->getOwnerFaction(Main::getInstance()->getFactionManager()->getFactionPlayer($sender)) !== $name){
                                    if(Main::getInstance()->getFactionManager()->getRankPlayerInFaction($name) !== "chef"){
                                        Main::getInstance()->getFactionManager()->promotePlayerInFaction($name);
                                        $sender->sendMessage(Utils::PREFIX . "§fVous avez bien promu §d" . $name . " §fdans votre faction");
                                    }else $sender->sendMessage(Utils::PREFIX . "§cCe joueur est déjà au grade maximum");
                                }else $sender->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas promouvoir le chef de la faction");
                            }else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'est pas dans votre faction");
                        }else $sender->sendMessage(Utils::PREFIX . "§cCe joueur n'est pas dans votre faction");
                    }else $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas la permission de promouvoir des joueurs");
                }else $sender->sendMessage(Utils::PREFIX . "§cVous n'êtes pas dans une faction");
            }else $sender->sendMessage(Utils::PREFIX . "§cVous devez spécifier un joueur");
        }else $sender->sendMessage(Utils::PREFIX . "§cVous devez être un joueur pour executer cette commande");
    }
}