<?php

namespace Lunarium\Command\Staff;

use Lunarium\Main;
use Lunarium\Utils\Utils;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;

class UnbanCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new RawStringArgument("joueur", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $joueur = $args["joueur"];

        if (!isset($joueur)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §d/unban (joueur)");
            return;
        }

        if (Main::getInstance()->getSanctionManager()->isBanned(strtolower($joueur))) {
            $sender->sendMessage(Utils::PREFIX . "§d" . $joueur . "§f à été débannis");
            Main::getInstance()->getSanctionManager()->DeleteBan(strtolower($joueur));
        } else {
            $sender->sendMessage(Utils::PREFIX . "§d" . $joueur . "§c n'est pas bannis");
        }
    }

    public function getPermission(): string
    {
        return "lunarium.unban";
    }
}