<?php

namespace Lunarium\Command\Staff;

use Lunarium\Main;
use Lunarium\Managers\DiscordManager;
use Lunarium\Managers\WebhookManager;
use Lunarium\Utils\Utils;
use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;

class BanCommand extends BaseCommand
{

    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("joueur", false));
        $this->registerArgument(1, new RawStringArgument("time",false));
        $this->registerArgument(2, new TextArgument("raison",false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $player = $args["joueur"];
        $time = $args["time"];
        $raison = $args["raison"];

        if (!isset($player) or !isset($time) or !isset($raison)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §d/ban (joueur) (temps <30d>) (raison <cheat>)");
            return;
        }

        if (!ctype_alnum($time)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §d/ban (joueur) (temps <30d>) (raison <cheat>)");
            return;
        }

        $val = substr($time, -1);
        if ($val == "y") {
            $temp = time() + ((int)$time * 31536000);
            $FormatTemp = (int)$time . " an" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "M") {
            $temp = time() + ((int)$time * 2635200);
            $FormatTemp = (int)$time . " mois";
        } else if ($val == "w") {
            $temp = time() + ((int)$time * 604800);
            $FormatTemp = (int)$time . " semaine" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "d") {
            $temp = time() + ((int)$time * 86400);
            $FormatTemp = (int)$time . " jour" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "h") {
            $temp = time() + ((int)$time * 3600);
            $FormatTemp = (int)$time . " heure" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "m") {
            $temp = time() + ((int)$time * 60);
            $FormatTemp = (int)$time . " minute" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "s") {
            $temp = time() + ((int)$time);
            $FormatTemp = (int)$time . " seconde" . ((int)$time > 1 ? "s" : "");
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cVeuillez entrer un temps valide dont §d1w, 1d, 1h, 1m, 1s");
            return;
        }

        $raison = [];
        for ($i = 2; $i < count($args); $i++) {
            $raison[] = $args["raison"];
        }
        $raison = implode(" ", $raison);

        if (empty($raison)) {
            $raison = "Aucune raison";
        }

        $playerExact = Server::getInstance()->getPlayerExact($player);

        if($playerExact instanceof Player){
            $deviceId = $playerExact->getPlayerInfo()->getExtraData()["DeviceId"];
            $clientRandomId = $playerExact->getPlayerInfo()->getExtraData()["ClientRandomId"];
            $uuid = $playerExact->getUniqueId()->toString();
            $xuid = $playerExact->getXuid();
            $ip = $playerExact->getNetworkSession()->getIp();
            $id = $this->generateRandomID(6);

            $playerExact->kick(Utils::PREFIX . "§fVous avez été banni du serveur\n§fID: §d$id\n§fRaison: §d{$raison}\n§fTemps restant: §d{$FormatTemp}\n§fStaff: §d{$sender->getName()}", Utils::PREFIX . "§fVous avez été banni du serveur\n§fID: §d$id\n§fRaison: §d{$raison}\n§fTemps restant: §d{$FormatTemp}\n§fStaff: §d{$sender->getName()}");

            DiscordManager::sendEmbed("**Banissement**\n**ID:** {$id}\n**Joueur:** {$playerExact->getName()}.\n**Staff:** {$sender->getName()}.\n**Raison:** {$raison}.\n**Temps:** {$FormatTemp}", WebhookManager::BAN);

            $ban = "{$sender->getName()}:{$temp}:{$raison}:{$deviceId}:{$id}:{$clientRandomId}:{$uuid}:{$xuid}:{$ip}";
            Main::getInstance()->getSanctionManager()->InsertBan(strtolower($playerExact->getName()), $ban);

            Server::getInstance()->broadcastMessage(Utils::PREFIX . "§d" . $playerExact->getName() . "§f à été banni par §d{$sender->getName()} §fpour §d{$raison}");
        } else {
            $id = $this->generateRandomID(6);

            $config = new Config(Main::getInstance()->getDataFolder() . "secure.yml", Config::YAML);

            if (!$config->exists($player)) {
                $sender->sendMessage(Utils::PREFIX . "§d$player §cn'existe pas");
                return;
            }

            if(!$config->exists($player, "xuid")){
                $sender->sendMessage(Utils::PREFIX . "§d$player §cn'existe pas");
                return;
            }

            $infos = [
                "xuid" => $config->getNested($player . ".xuid"),
                "uuid" => $config->getNested($player . ".uuid"),
                "cid" => $config->getNested($player . ".cid"),
                "ip" => $config->getNested($player . ".ip"),
                "deviceid" => $config->getNested($player . ".deviceid"),
            ];

            $target = Server::getInstance()->getPlayerByPrefix($player);

            if($target instanceof Player){
                $target->kick(Utils::PREFIX . "§fVous avez été banni du serveur\n§fID: §d$id\n§fRaison: §d{$raison}\n§fTemps restant: §d{$FormatTemp}\n§fStaff: §d{$sender->getName()}\n§ddiscord.gg/nagasaki", Utils::PREFIX . "§fVous avez été banni du serveur\n§fID: §d$id\n§fRaison: §d{$raison}\n§fTemps restant: §d{$FormatTemp}\n§fStaff: §d{$sender->getName()}\n§ddiscord.gg/nagasaki");
            }

            DiscordManager::sendEmbed("**Banissement**\n**ID:** {$id}\n**Joueur:** {$player}.\n**Staff:** {$sender->getName()}.\n**Raison:** {$raison}.\n**Temps:** {$FormatTemp}", WebhookManager::BAN);

            $ban = "{$sender->getName()}:{$temp}:{$raison}:{$infos["deviceid"]}:{$id}:{$infos["cid"]}:{$infos["uuid"]}:{$infos["xuid"]}:{$infos["ip"]}";
            Main::getInstance()->getSanctionManager()->InsertBan(strtolower($player), $ban);

            Server::getInstance()->broadcastMessage(Utils::PREFIX . "§d" . $player . "§f à été banni par §d{$sender->getName()} §fpour §d{$raison}");
        }
    }


    public function generateRandomID($length): string
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomID = '#';

        for ($i = 0; $i < $length; $i++) {
            $randomID .= $characters[rand(0, $charactersLength - 1)];
        }

        return $randomID;
    }

    public function getPermission(): string
    {
        return "lunarium.ban";
    }
}