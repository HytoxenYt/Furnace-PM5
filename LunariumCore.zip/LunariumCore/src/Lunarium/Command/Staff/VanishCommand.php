<?php

namespace Lunarium\Command\Staff;

use CortexPE\Commando\BaseCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class VanishCommand extends BaseCommand
{
    public static array $vanish = [];

    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if ($sender instanceof Player) {
            if (in_array($sender->getName(), VanishCommand::$vanish)) {
                foreach (Main::getInstance()->getServer()->getOnlinePlayers() as $player) {
                    $player->showPlayer($sender);
                }

                unset(VanishCommand::$vanish[array_search($sender->getName(), VanishCommand::$vanish)]);
                $sender->sendMessage(Utils::PREFIX . "Vous êtes désormais visible aux yeux des autres joueurs");
            } else {
                foreach (Main::getInstance()->getServer()->getOnlinePlayers() as $player) {
                    if ($player->hasPermission("lunarium.staff") || $player->getName() === $sender->getName()) {
                        continue;
                    }

                    $player->hidePlayer($sender);
                }

                VanishCommand::$vanish[] = $sender->getName();
                $sender->sendMessage(Utils::PREFIX . "Vous êtes désormais invisible aux yeux des autres joueurs");
            }
        }
    }

    public function getPermission(): string
    {
        return "lunarium.vanish";
    }
}