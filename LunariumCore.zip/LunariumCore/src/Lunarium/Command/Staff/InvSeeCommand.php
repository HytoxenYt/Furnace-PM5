<?php

namespace Lunarium\Command\Staff;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Utils;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\lang\Translatable;
use pocketmine\player\Player;
use pocketmine\Server;

class InvSeeCommand extends BaseCommand
{

    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("joueur", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }


    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;

        $joueur = $args["joueur"];

        if (!isset($joueur)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §d/invsee (joueur)");
            return;
        }

        $target = Server::getInstance()->getPlayerByPrefix($joueur);
        if ($target instanceof Player) {
            $inv = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
            $inv->setName("§fInventaire de §d" . $target->getName());
            $inv->setListener(InvMenu::readonly());
            $inv->getInventory()->setContents($target->getInventory()->getContents());
            for ($i = 36; $i < 9 * 6; $i++) {
                $inv->getInventory()->setItem($i, VanillaBlocks::BARRIER()->asItem()->setCustomName("§r§c--"));
            }
            $inv->getInventory()->setItem(52, $target->getArmorInventory()->getBoots());
            $inv->getInventory()->setItem(50, $target->getArmorInventory()->getLeggings());
            $inv->getInventory()->setItem(48, $target->getArmorInventory()->getChestplate());
            $inv->getInventory()->setItem(46, $target->getArmorInventory()->getHelmet());
            $inv->send($sender);
        } else $sender->sendMessage(Utils::PREFIX . "§d" . $target . "§c n'est pas connecté");
    }

    public function getPermission(): string
    {
        return "lunarium.invsee";
    }
}