<?php

namespace Lunarium\Command\Staff;

use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class LockChatCommand extends Command
{
    public static bool $chat = false;
    public function __construct()
    {
        parent::__construct('lockchat', 'Permet de bloquer le chat', '/lockchat');
        $this->setPermission("lunarium.lockchat");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender->hasPermission($this->getPermissions()[0])) {
            $sender->sendMessage(Utils::PREFIX . "§cVous n'avez pas accès à cette commande");
            return;
        }

        self::$chat = !self::$chat;
        $status = self::$chat ? "verrouillé" : "déverrouillé";
        Server::getInstance()->broadcastMessage(Utils::PREFIX . "§fLe chat a été §d{$status} §fpar §d{$sender->getName()}");
    }
}