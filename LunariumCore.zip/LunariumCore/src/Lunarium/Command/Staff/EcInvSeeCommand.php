<?php

namespace Lunarium\Command\Staff;

use CortexPE\Commando\args\PlayerArgument;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class EcInvSeeCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("joueur", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if(!$sender instanceof Player) return;

        $joueur = $args["joueur"];
        if (!isset($joueur)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §d/ecinvsee (joueur)");
            return;
        }

        $player = Server::getInstance()->getPlayerByPrefix($joueur);
        if($player instanceof Player) {
            $inv = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
            $inv->setName("§fEnderChest de §d" . $player->getName());
            $inv->setListener(InvMenu::readonly());
            $inv->getInventory()->setContents($player->getEnderInventory()->getContents());
            $inv->send($sender);
        }else $sender->sendMessage(Utils::PREFIX . "§d" . $joueur . "§c n'est pas connecté");

    }

    public function getPermission(): string
    {
        return "lunarium.ecinvsee";
    }
}