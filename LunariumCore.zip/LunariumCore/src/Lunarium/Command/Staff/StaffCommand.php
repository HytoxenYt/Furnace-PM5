<?php

namespace Lunarium\Command\Staff;

use CortexPE\Commando\BaseCommand;
use Lunarium\API\StaffAPI;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\Server;
use pocketmine\lang\Translatable;
use pocketmine\player\Player;

class StaffCommand extends BaseCommand {

    protected function prepare(): void
    {
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;
        if (StaffAPI::isStaff($sender)){
            StaffAPI::removeStaff($sender);
        }else{
            StaffAPI::setStaff($sender);
        }
    }

    public function getPermission(): string
    {
       return "lunarium.staffmode";
    }
}