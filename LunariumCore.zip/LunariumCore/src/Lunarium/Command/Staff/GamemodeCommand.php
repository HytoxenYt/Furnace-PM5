<?php

namespace Lunarium\Command\Staff;


use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\args\GamemodeArgument;
use Lunarium\Utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\Server;

class GamemodeCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new GamemodeArgument("mode", false));
        $this->registerArgument(1, new PlayerArgument("player", true));
        $this->setPermission($this->getPermission());
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if(!$sender instanceof Player) return;

        $gameMode = GameMode::fromString($args["mode"]);
        if(is_null($gameMode)){
            $sender->sendMessage(Utils::PREFIX . "§cVous devez indiquez un gamemode");
            return;
        }

        if(isset($args["player"])) {
            $target = Server::getInstance()->getPlayerExact($args["player"]);
            if(!$target instanceof Player || !$target->isConnected()) {
                $sender->sendMessage(Utils::PREFIX . "§d" . $args["player"] . " §cn'est pas un joueur");
                return;
            }

            if(strtolower($sender->getName()) === strtolower($target->getName())) {
                $sender->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas vous indiquez vous-même");
                return;
            }

            $sender->sendMessage(Utils::PREFIX . "§fVous avez §d" . $target->getName() . "§f en " . $gameMode->getEnglishName());
            $target->sendMessage(Utils::PREFIX . "§d" . $sender->getName() . "§f vous à mis en §d " . $gameMode->getEnglishName());
            $target->setGamemode($gameMode);
            return;
        }

        $sender->sendMessage(Utils::PREFIX . "§fVous êtes en §d" . $gameMode->getEnglishName());
        $sender->setGamemode($gameMode);
    }

    public function getPermission(): string
    {
        return "lunarium.gamemode";
    }
}