<?php

namespace Lunarium\Command\Staff;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Utils\Utils;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\lang\Translatable;
use pocketmine\player\Player;
use pocketmine\Server;

class FreezeCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("joueur", false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;

        $joueur = $args["joueur"];

        if (!isset($joueur)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §d/freeze (joueur)");
            return;
        }

        $target = Server::getInstance()->getPlayerByPrefix($joueur);
        if ($target instanceof Player) {
            if ($target->hasNoClientPredictions()) {
                $target->setNoClientPredictions(false);
                $sender->sendMessage(Utils::PREFIX . "§fLe joueur §d{$target->getName()}§f viens d'être unfreeze");
            } else {
                $target->setNoClientPredictions();
                $sender->sendMessage(Utils::PREFIX . "§fLe joueur §d{$target->getName()}§f viens d'être freeze");
            }
        } else $sender->sendMessage(Utils::PREFIX . "§d" . $joueur . "§c n'est pas connecté");
    }

    public function getPermission(): string
    {
        return "lunarium.freeze";
    }
}