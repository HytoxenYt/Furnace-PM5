<?php

namespace Lunarium\Command\Staff;

use CortexPE\Commando\args\PlayerArgument;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseCommand;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class MuteCommand extends BaseCommand
{
    protected function prepare(): void
    {
        $this->registerArgument(0, new PlayerArgument("joueur", false));
        $this->registerArgument(1, new RawStringArgument("time",false));
        $this->registerArgument(2, new TextArgument("raison",false));
        $this->setPermission($this->getPermission());
        $this->setPermissionMessage(Utils::PREFIX . "§cVous n'avez pas la permission");
    }


    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $player = $args["joueur"];
        $time = $args["time"];
        $raison = $args["raison"];

        if (!isset($player) or !isset($time) or !isset($raison)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §d/mute (joueur) (temps <10m>) (raison <flood>)");
            return;
        }

        if (!ctype_alnum($time)) {
            $sender->sendMessage(Utils::PREFIX . "§cVous devez faire §d/mute (joueur) (temps <10m>) (raison <flood>)");
            return;
        }

        $val = substr($time, -1);
        if ($val == "y") {
            $temp = time() + ((int)$time * 31536000);
            $FormatTemp = (int)$time . " an" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "M") {
            $temp = time() + ((int)$time * 2635200);
            $FormatTemp = (int)$time . " mois";
        } else if ($val == "w") {
            $temp = time() + ((int)$time * 604800);
            $FormatTemp = (int)$time . " semaine" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "d") {
            $temp = time() + ((int)$time * 86400);
            $FormatTemp = (int)$time . " jour" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "h") {
            $temp = time() + ((int)$time * 3600);
            $FormatTemp = (int)$time . " heure" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "m") {
            $temp = time() + ((int)$time * 60);
            $FormatTemp = (int)$time . " minute" . ((int)$time > 1 ? "s" : "");
        } else if ($val == "s") {
            $temp = time() + ((int)$time);
            $FormatTemp = (int)$time . " seconde" . ((int)$time > 1 ? "s" : "");
        } else {
            $sender->sendMessage(Utils::PREFIX . "§cVeuillez entrer un temps valide dont §d1w, 1d, 1h, 1m, 1s");
            return;
        }

        $raison = [];
        for ($i = 2; $i < count($args); $i++) {
            $raison[] = $args["raison"];
        }
        $raison = implode(" ", $raison);

        if (empty($raison)) {
            $raison = "Aucune raison";
        }

        $playerExact = Server::getInstance()->getPlayerExact($player);

        if ($playerExact instanceof Player) {
            if (Main::getInstance()->getSanctionManager()->isMuted(strtolower($player->getName()))) {
                $sender->sendMessage(Utils::PREFIX . "§cLe joueur §d" . $player->getName() . " §cest déjà mute");
                return;
            }
            $raison = [];
            for ($i = 2; $i < count($args); $i++) {
                $raison[] = $args[$i];
            }
            $raison = implode(" ", $raison);
            $mute = "{$sender->getName()}:$temp:$raison";
            Main::getInstance()->getSanctionManager()->InsertMute(strtolower($player->getName()), $mute);
            $player->sendMessage(Utils::PREFIX . "Vous avez été mute par §d" . $sender->getName() . " §fpour §d" . $raison . "§f pendant §d" . $FormatTemp);
            $sender->sendMessage(Utils::PREFIX . "Vous avez mute le joueur §d" . $player->getName() . " §fpendant §d" . $FormatTemp);
            Server::getInstance()->broadcastMessage(Utils::PREFIX . "§d" . $player->getName() . "§f a été mute par §d" . $sender->getName() . " §fpour §d" . $raison . "§f pendant§d" . $FormatTemp);
        }
    }

    public function getPermission(): string
    {
        return "lunarium.mute";
    }
}