<?php

namespace Lunarium\Listener;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\item\CustomiesItemFactory;
use jojoe77777\FormAPI\CustomForm;
use libIPGeolocation\IPGeolocation;
use Lunarium\Command\Staff\LockChatCommand;
use Lunarium\LunaMod\Blocks\CustomBlockIds;
use Lunarium\LunaMod\Item\CustomItem;
use Lunarium\LunaMod\Item\UnclaimFinder\UnclaimFinderVert;
use Lunarium\LunaMod\Item\UnclaimFinder\UnclaimFinderViolet;
use Lunarium\LunaMod\Item\Utility\HandGlider;
use Lunarium\LunaMod\Item\Utility\SeedPlanter;
use Lunarium\Main;
use Lunarium\Managers\DiscordManager;
use Lunarium\Managers\DrawerManager;
use Lunarium\Managers\JobsManager;
use Lunarium\Managers\MoneyManager;
use Lunarium\Managers\WebhookManager;
use Lunarium\newEffectInstance;
use Lunarium\Tasks\ChatEventGameTask;
use Lunarium\Tasks\UnclaimFinderTask;
use Lunarium\Utils\Utils;
use Lunarium\Entity\Player as CustomPlayer;
use pocketmine\block\Air;
use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Farmland;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerToggleSneakEvent;
use pocketmine\event\player\PlayerToggleSprintEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Durable;
use pocketmine\item\Item;
use pocketmine\item\ItemBlock;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\player\XboxLivePlayerInfo;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;
use pocketmine\world\sound\BlazeShootSound;
use pocketmine\world\sound\EndermanTeleportSound;
use pocketmine\world\World;
use Webmozart\PathUtil\Path;

class PlayerListener implements Listener
{
    public static array $coords = [];
    public static array $xp = [];
    public array $using_vert = [];
    public array $using_violet = [];
    public static array $players = [];
    public array $spectators = [];
    private array $cooldowns = [];


    public function onChat(PlayerChatEvent $event): void
    {
        $player = $event->getPlayer();
        $message = $event->getMessage();

        if ($this->isBadWord($message)) {
            $this->cancelWithMessage($event, $player, "§cVous avez écrit un mot interdit §f(§d{$message}§f)");
            return;
        }

        if ($this->handleMute($player, $event)) {
            return;
        }

        if (LockChatCommand::$chat && !$this->canBypassChatLock($player)) {
            $this->cancelWithMessage($event, $player, "§cVous ne pouvez pas parler, le chat est verrouillé");
            return;
        }

        if (!$this->handleChatGameEvent($player, $message)) {
            $event->cancel();
        }
    }

    private function handleChatGameEvent(Player $player, string $message): bool
    {
        if (ChatEventGameTask::$claim || !$this->isChatGameActive()) {
            return true;
        }

        $success = match (ChatEventGameTask::$event) {
            "texte" => $message === ChatEventGameTask::$code,
            "calcul", "shuffle" => $message === ChatEventGameTask::$reponse,
            default => false,
        };

        if ($success) {
            $this->rewardChatGameWinner($player, $message);
            return false;
        }

        return true;
    }

    private function isChatGameActive(): bool
    {
        return in_array(ChatEventGameTask::$event, ["texte", "calcul", "shuffle"], true);
    }

    private function rewardChatGameWinner(Player $player, string $message): void
    {
        $name = $player->getName();
        $event = ChatEventGameTask::$event;

        $rewardMessage = match ($event) {
            "texte" => "ayant recopié le mot §d{$message}§f en premier",
            "calcul" => "calculant §d" . ChatEventGameTask::$calcul . "§f en premier",
            "shuffle" => "retrouvant le mot §d{$message}§f en premier",
            default => "",
        };

        Main::getInstance()->getServer()->broadcastMessage(Utils::PREFIX . "§d{$name}§f a gagné §d5.000$ §fen {$rewardMessage}");
        MoneyManager::addMoney($name, 5000);
        ChatEventGameTask::$claim = true;
    }

    private function isBadWord(string $message): bool
    {
        static $badwords = null;

        if ($badwords === null) {
            $config = new Config(Main::getInstance()->getDataFolder() . "banned-word.yml", Config::YAML);
            $badwords = $config->get("banned-words", []);
        }

        return in_array($message, $badwords, true);
    }

    private function cancelWithMessage(PlayerChatEvent $event, Player $player, string $message): void
    {
        $event->cancel();
        $player->sendMessage(Utils::PREFIX . $message);
    }

    private function canBypassChatLock(Player $player): bool
    {
        return $player->hasPermission("lunarium.admin") || Server::getInstance()->isOp($player->getName());
    }

    private function handleMute(Player $player, PlayerChatEvent $event): bool
    {
        $name = strtolower($player->getName());
        $sanctionManager = Main::getInstance()->getSanctionManager();

        if (!$sanctionManager->isMuted($name)) {
            return false;
        }

        [$staff, $time, $reason] = explode(":", $sanctionManager->GetMute($name));
        $currentTime = time();

        if ($currentTime >= (int)$time) {
            $sanctionManager->DeleteMute($name);
            return false;
        }

        $timeRemaining = $time - $currentTime;
        $player->sendMessage(Utils::PREFIX . "§cVous êtes encore mute pendant §d" . Main::getInstance()->intToTime($timeRemaining, "§c") . " §cpour §d{$reason}§c par §d{$staff}");
        $event->cancel();

        return true;
    }

    public function onJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        $playerName = $player->getName();
        $xuid = $player->getXuid();

        if (!$player->hasPlayedBefore()) {
            $this->handleFirstJoin($player);
        }

        if (Utils::getCooldown()->has($xuid, "freeze")) {
            $this->handleFreezeReconnect($player);
        }

        $this->initializeJobs($playerName);

        $this->checkAndStart($player, $player->getInventory()->getItemInHand());

        $item = $player->getInventory()->getItemInHand();
        $playereffect = $player->getEffects();

        if ($item instanceof HandGlider) {
            if ($playereffect->has(VanillaEffects::LEVITATION())) {
                $player->getEffects()->remove(VanillaEffects::LEVITATION());
                $player->resetFallDistance();
            }
        }

        Server::getInstance()->broadcastMessage(TextFormat::DARK_GRAY . "[§a+" . TextFormat::DARK_GRAY . "] §a" . $player->getName() . " §fs'est connecté");
    }

    private function handleFirstJoin(Player $player): void
    {
        $server = Server::getInstance();
        $playerName = $player->getName();

        $player->sendTitle("§f- §5Lunarium§f -", "Bienvenue sur §5Lunarium");

        // Remplace Path::join(...) par une concaténation
        $path = $server->getDataPath() . "players";
        if(!is_dir($path)){
            mkdir($path);
        }

        $playerCount = count(glob($path . "/*")) + 1;
        $server->broadcastMessage(Utils::PREFIX . "§d" . $playerName . "§f nous a rejoint, il est le §d{$playerCount}ème joueur");
    }

    private function handleFreezeReconnect(Player $player): void
    {
        $server = Server::getInstance();
        $playerName = $player->getName();

        $player->setNoClientPredictions();
        $player->sendMessage(Utils::PREFIX . "§cVous avez déconnecté en plein freeze");

        $onlineStaff = array_filter(
            $server->getOnlinePlayers(),
            fn($p) => $p->hasPermission("lunarium.staff") || $server->isOp($p->getName())
        );

        foreach ($onlineStaff as $staff) {
            $staff->sendMessage(Utils::PREFIX . "§d" . $playerName . "§f s'est reconnecté en étant freeze");
            $staff->getWorld()->addSound($staff->getPosition(), new EndermanTeleportSound());
        }
    }



    private function initializeJobs(string $playerName): void
    {
        $dataFolder = Main::getInstance()->getDataFolder() . "Jobs/";

        if (!is_dir($dataFolder)) {
            mkdir($dataFolder, 0777, true);
        }

        $jobs = [JobsManager::MINEUR, JobsManager::FERMIER, JobsManager::BUCHERON, JobsManager::ASSASSIN];

        foreach ($jobs as $job) {
            $configPath = "{$dataFolder}{$job}.json";
            $config = new Config($configPath, Config::JSON);

            if (!$config->exists($playerName)) {
                $config->setNested($playerName, [
                    '0' => 0,
                    '1' => 1,
                    'rewardsReceived' => array_fill(1, 25, 0),
                ]);
                $config->save();
            }
        }
    }

    public function onQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        $event->setQuitMessage("");
        Server::getInstance()->broadcastMessage(TextFormat::DARK_GRAY . "[§c-" . TextFormat::DARK_GRAY . "] §c" . $player->getName() . " §fs'est déconnecté");

        $this->stopCaveBlock($event->getPlayer());

        $playereffect = $player->getEffects();
        if ($playereffect->has(VanillaEffects::LEVITATION())) {
            $player->getEffects()->remove(VanillaEffects::LEVITATION());
            $player->resetFallDistance();
        }
    }

    public function onCommand(CommandEvent $event): void
    {

    }

    public function onPlayerItemHeld(PlayerItemHeldEvent $event): void
    {
        $item = $event->getItem();
        $player = $event->getPlayer();

        if ($item->getTypeId() == CustomItem::PLANEUR) {
            $newEffect = new newEffectInstance(VanillaEffects::LEVITATION(), 9999 * 9999, -4, false);
            $player->getEffects()->add($newEffect);
        } else {
            $player->getEffects()->remove(VanillaEffects::LEVITATION());
            $player->resetFallDistance();
        }

        $this->checkAndStart($player, $item);
    }

    public function onDeath(PlayerDeathEvent $event): void
    {
        $player = $event->getPlayer();
        $pos = $player->getPosition();
        $lastDamage = $player->getLastDamageCause();
        $damager = null;

        self::$coords[$player->getXuid()] = [
            $pos->x,
            $pos->y,
            $pos->z,
            $pos->getWorld()->getDisplayName()
        ];

        $killStreak = new Config(Main::getInstance()->getDataFolder() . "killstreak.yml", Config::YAML);

        if ($lastDamage instanceof EntityDamageByEntityEvent) {
            $damager = $lastDamage->getDamager();
            if ($damager instanceof Player) {
                $damagerName = $damager->getName();
                $playerName = $player->getName();

                $killStreakCount = $killStreak->get($damagerName, 0);
                $xpToAdd = $killStreakCount >= 10 ? 20 : 10;

                JobsManager::addXp($damager, JobsManager::ASSASSIN, $xpToAdd);
                /*
                 * soon: stats
                 *
                 * StatsManager::setStats($damager, "kill");
                StatsManager::setStats($player, "death");*/

                $killStreak->set($damagerName, $killStreakCount + 1);
                $killStreak->set($playerName, 0);
                $killStreak->save();
            }
        }

        $rank = Main::getInstance()->getRank($player);
        if (in_array($rank, ["Guerrier", "Lunaire"])) {
            self::$xp[$player->getXuid()] = $player->getXpManager()->getCurrentTotalXp();
        }

        $cause = $lastDamage?->getCause();
        $event->setDeathMessage("");

        $deathMessages = [
            EntityDamageEvent::CAUSE_PROJECTILE => "§f» §d{$player->getName()} §fs'est fait tirer dessus par une flèche venant de §d" . ($damager instanceof Player ? $damager->getName() : "quelqu'un"),
            EntityDamageEvent::CAUSE_SUICIDE => "§f» §d{$player->getName()} §fest mort(e)",
            EntityDamageEvent::CAUSE_VOID => "§f» §d{$player->getName()} §fest tombé(e) dans le vide",
            EntityDamageEvent::CAUSE_FALL => "§f» §d{$player->getName()} §fest tombé(e) de haut",
            EntityDamageEvent::CAUSE_SUFFOCATION => "§f» §d{$player->getName()} §fa suffoqué(e) dans un bloc",
            EntityDamageEvent::CAUSE_LAVA => "§f» §d{$player->getName()} §fs'est noyé(e) dans la lave",
            EntityDamageEvent::CAUSE_FIRE => "§f» §d{$player->getName()} §fs'est fait brûler vif",
            EntityDamageEvent::CAUSE_FIRE_TICK => "§f» §d{$player->getName()} §fa péri dans les flammes",
            EntityDamageEvent::CAUSE_DROWNING => "§f» §d{$player->getName()} §fs'est noyé(e)",
            EntityDamageEvent::CAUSE_CONTACT => "§f» §d{$player->getName()} §fs'est fait piquer par un cactus",
            EntityDamageEvent::CAUSE_BLOCK_EXPLOSION => "§f» §d{$player->getName()} §fs'est fait exploser",
            EntityDamageEvent::CAUSE_ENTITY_EXPLOSION => "§f» §d{$player->getName()} §fs'est fait exploser",
            EntityDamageEvent::CAUSE_MAGIC => "§f» §d{$player->getName()} §fs'est fait tuer par la magie",
        ];

        $broadcastMessage = $deathMessages[$cause] ?? "§f» §d{$player->getName()} §fest mort(e)";

        Server::getInstance()->broadcastTip($broadcastMessage);
    }

    public function PlayerRespawnEv(PlayerRespawnEvent $event): void
    {
        $player = $event->getPlayer();
        $rank = Main::getInstance()->getRank($player);

        if (in_array($rank, ["Guerrier", "Lunaire"])) {
            $player->getXpManager()->setCurrentTotalXp(self::$xp[$player->getXuid()]);
        }
    }


    public function onDamage(EntityDamageByEntityEvent $event): void
    {
        $event->setAttackCooldown(10.0);
        $event->setKnockBack(0.400);
    }

    public function onPlayerPreLogin(PlayerPreLoginEvent $event): void
    {
        $name = strtolower($event->getPlayerInfo()->getUsername());
        $ip = $event->getIp();

        $config = new Config(Main::getInstance()->getDataFolder() . "secure.yml", Config::YAML);
        $player = $event->getPlayerInfo();
        if ($player instanceof XboxLivePlayerInfo) {
            $config->set($player->getXuid(), [
                "uuid" => $player->getUuid()->toString(),
                "ip" => $event->getIp(),
                "cid" => $player->getExtraData()["ClientRandomId"],
                "pseudo" => $player->getUsername(),
                "deviceid" => $player->getExtraData()["DeviceId"]
            ]);
            $config->set($player->getUsername(), [
                "uuid" => $player->getUuid()->toString(),
                "ip" => $event->getIp(),
                "cid" => $player->getExtraData()["ClientRandomId"],
                "xuid" => $player->getXuid(),
                "deviceid" => $player->getExtraData()["DeviceId"]
            ]);
            $config->save();
        }
        $getBanInfo = function ($identifier) {
            $ban = Main::getInstance()->getSanctionManager()->GetBan($identifier);
            return $ban ? explode(":", $ban) : null;
        };

        $handleBan = function ($ban, $identifier, $event) {
            $staff = $ban[0];
            $time = $ban[1];
            $raison = $ban[2];
            $id = $ban[4];
            $timeRestant = $time - time();
            $FormatTemp = Main::getInstance()->intToTime($timeRestant);

            if ($timeRestant <= 0) {
                Main::getInstance()->getSanctionManager()->DeleteBan($identifier);
                if ($identifier === $event->getIp()) {
                    Main::getInstance()->getSanctionManager()->DeleteBanIP($event->getIp());
                }
            } else {
                $event->setKickFlag(PlayerPreLoginEvent::KICK_FLAG_PLUGIN,
                    Utils::PREFIX . "§fVous avez été banni du serveur\n§fID: §d$id\n§fRaison: §d{$raison}\n§fTemps restant: §d{$FormatTemp}\n§fStaff: §d{$staff}",
                    Utils::PREFIX . "§fVous avez été banni du serveur\n§fID: §d$id\n§fRaison: §d{$raison}\n§fTemps restant: §d{$FormatTemp}\n§fStaff: §d{$staff}");
            }
        };

        $ban = Main::getInstance()->getSanctionManager()->isBanned($name) ? $getBanInfo($name) : null;
        if ($ban) {
            $handleBan($ban, $name, $event);
            return;
        }

        if (Main::getInstance()->getSanctionManager()->isBannedIP($ip)) {
            $banName = Main::getInstance()->getSanctionManager()->GetBanIP($ip);
            $ban = $getBanInfo($banName);
            if ($ban) {
                $handleBan($ban, $banName, $event);
            }
        }

        foreach (Main::getInstance()->getSanctionManager()->getAllBans() as $banKey => $banValue) {
            $banDetails = explode(":", $banValue);
            $bannedIp = $banDetails[8] ?? null;
            $bannedClientRandomId = $banDetails[5] ?? null;
            $bannedDeviceId = $banDetails[3] ?? null;

            if (
                ($event->getIp() === $bannedIp) ||
                ($player->getExtraData()["DeviceId"] === $bannedDeviceId) ||
                ($player->getExtraData()["ClientRandomId"] === $bannedClientRandomId)
            ) {
                $staff = $banDetails[0] ?? "Inconnu";
                $remainingTime = Main::getInstance()->intToTime($banDetails[1] ?? 0, "§f");
                $reason = $banDetails[2] ?? "Aucune raison";
                $banId = $banDetails[4] ?? "Inconnu";

                DiscordManager::sendMessage($event->getPlayerInfo()->getUsername() . " (" . $event->getIp() . ") à essayé de se connecté en étant bannis ($bannedIp) id: $banId", WebhookManager::DOUBLE_COMPTE);

                $event->setKickFlag(
                    PlayerPreLoginEvent::KICK_FLAG_PLUGIN,
                    Utils::PREFIX . "§cVous essayez de vous connecter en étant déjà banni\n"
                    . "§fID: §d{$banId}\n"
                    . "§fRaison: §d{$reason}\n"
                    . "§fTemps restant: §d{$remainingTime}\n"
                    . "§fStaff: §d{$staff}\n"
                    . "§ddiscord.gg/lunarium",
                    Utils::PREFIX . "§cVous essayez de vous connecter en étant déjà banni\n"
                    . "§fID: §d{$banId}\n"
                    . "§fRaison: §d{$reason}\n"
                    . "§fTemps restant: §d{$remainingTime}\n"
                    . "§fStaff: §d{$staff}\n"
                    . "§ddiscord.gg/lunarium"
                );
                return;
            }
        }

        if (Main::getInstance()->maintenanceManager->isEnabled()) {
            if (!in_array($event->getPlayerInfo()->getUsername(), Main::getInstance()->maintenanceManager->getList())) {
                $event->setKickFlag(PlayerPreLoginEvent::KICK_FLAG_PLUGIN, TextFormat::colorize(implode(TextFormat::EOL, [
                    "&d&l---- MAINTENANCE ----",
                    "",
                    " &r&fVous pourrez de nouveau",
                    "jouer lorsque nous aurons",
                    "       terminé. A bientôt."
                ])));
            }
        }

        if (IPGeolocation::getContinent($ip) === "localhost") return;
        if (IPGeolocation::isProxy($ip)) {
            $event->setKickFlag(PlayerPreLoginEvent::KICK_FLAG_PLUGIN, Utils::PREFIX . "§cDésactivez votre proxy\n§fSi ceci est une erreur\n§fcontactez nous sur Discord");
        }
    }

    public function onUse(PlayerItemUseEvent $event): void
    {

        $player = $event->getPlayer();
        $item = $event->getItem();
        $ItemName = $item->getCustomName();
        $name = "(";
        if ($item->getTypeId() == VanillaItems::EXPERIENCE_BOTTLE()->getTypeId() && strpos($ItemName, $name) !== false) {
            $event->cancel();
            $lvl = explode("§fBouteille d'expérience §d(", $ItemName);
            $lvl = explode(")", $lvl[1]);
            $lvl = intval($lvl[0]);
            $player->sendMessage(Utils::PREFIX . "§fVous avez obtenu §d{$lvl} niveaux §fgrâce à votre bouteille d'expérience");
            $player->getXpManager()->addXpLevels($lvl);
            $itemremove = VanillaItems::EXPERIENCE_BOTTLE()->setCount($item->getCount() - 1);
            $itemremove->setCustomName($ItemName);
            $player->getInventory()->setItemInHand($itemremove);
        }
        if ($item->getTypeId() === CustomiesItemFactory::getInstance()->get(CustomItem::SEEDPLANTER)->getTypeId()) {
            $ray = $this->getRayByItem();
            for ($x = ($player->getPosition()->x - $ray); $x <= ($player->getPosition()->x + $ray); $x++) {
                for ($z = ($player->getPosition()->z - $ray); $z <= ($player->getPosition()->z + $ray); $z++) {
                    $block = $player->getWorld()->getBlockAt((int) $x, (int) $player->getPosition()->y, (int) $z);
                    $seed = $player->getWorld()->getBlockAt((int) $x, (int) $player->getPosition()->y + 1, (int) $z);;
                    if (($block instanceof Farmland) and ($seed instanceof Air)) {
                        $item = $this->getSeedsInInventory($player);
                        if (!is_null($item)) {
                            $player->getWorld()->setBlock($seed->getPosition(), $this->getBlockByItem($item));
                            $player->getInventory()->removeItem($item);
                        }
                    }
                }
            }
        }
    }

    public function onEntityEvent(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();
        if ($entity instanceof Player) {
            if ($event->getCause() === EntityDamageEvent::CAUSE_FALL) {
                $dam = $event->getBaseDamage() / 2;
                $event->setBaseDamage((float)$dam);
            }

            $playerEffect = $entity->getEffects();
            if ($playerEffect->has(VanillaEffects::LEVITATION())) {
                $event->cancel();
            }
        }
    }

    public static function isElevatorBlock(int $x, int $y, int $z, World $level): ?Block
    {
        $elevator = $level->getBlockAt($x, $y, $z);

        if ($elevator->getTypeId() !== CustomiesBlockFactory::getInstance()->get(CustomItem::ELEVATOR)->getTypeId()) {
            return null;
        }

        return $elevator;
    }


    public function onPlayerJump(PlayerJumpEvent $event): void
    {
        $player = $event->getPlayer();
        $level = $player->getWorld();

        if ($level->getBlock($player->getPosition()->subtract(0, 1, 0))->getTypeId() !== CustomiesBlockFactory::getInstance()->get(CustomItem::ELEVATOR)->getTypeId()) return;

        $x = (int)floor($player->getPosition()->getX());
        $y = (int)floor($player->getPosition()->getY());
        $z = (int)floor($player->getPosition()->getZ());
        $maxY = $level->getMaxY();
        $found = false;
        $y++;

        for (; $y <= $maxY; $y++) {
            if ($found = (self::isElevatorBlock($x, $y, $z, $level) !== null)) {
                break;
            }
        }

        if ($found) {
            if ($player->getPosition()->distance(new Vector3($x + 0.5, $y + 1, $z + 0.5)) <= 30) {
                $player->teleport(new Vector3($x + 0.5, $y + 1, $z + 0.5));
            } else $player->sendMessage(Utils::PREFIX . "§cL'ascenseur est trop loin §5(30 blocks maximum)");
        } else $player->sendMessage(Utils::PREFIX . "§cAucun ascenseur trouvé");
    }

    public function onPlayerToggleSneak(PlayerToggleSneakEvent $event): void
    {
        $player = $event->getPlayer();
        $level = $player->getWorld();

        if ($level->getBlock($player->getPosition()->subtract(0, 1, 0))->getTypeId() !== CustomiesBlockFactory::getInstance()->get(CustomItem::ELEVATOR)->getTypeId()) return;


        if (!$event->isSneaking()) return;
        if ($level->getBlock($player->getPosition()->subtract(0, 1, 0))->getTypeId() !== CustomiesBlockFactory::getInstance()->get(CustomItem::ELEVATOR)->getTypeId()) return;
        $x = (int)floor($player->getPosition()->getX());
        $y = (int)floor($player->getPosition()->getY()) - 2;
        $z = (int)floor($player->getPosition()->getZ());
        $found = false;
        $y--;

        for (; $y >= 0; $y--) {
            if ($found = (self::isElevatorBlock($x, $y, $z, $level) !== null)) {
                break;
            }
        }

        if ($found) {
            if ($player->getPosition()->distance(new Vector3($x + 0.5, $y + 1, $z + 0.5)) <= 30) {
                $player->teleport(new Vector3($x + 0.5, $y + 1, $z + 0.5));
            } else $player->sendMessage(Utils::PREFIX . "§cL'ascenseur est trop loin §5(30 blocks maximum)");
        } else $player->sendMessage(Utils::PREFIX . "§cAucun ascenseur trouvé");
    }

    public function onSprint(PlayerToggleSprintEvent $event): void
    {
        $player = $event->getPlayer();

        $this->stopCaveBlock($player);
    }

    public function stopCaveBlock(Player $player)
    {
        $xuid = $player->getXuid();
        if (isset($this->spectators[$xuid])) {
            $data = $this->spectators[$xuid];
            $player->teleport($data["position"]);
            $player->setGamemode($data["gamemode"]);
            $player->setNoClientPredictions(false);
            unset($this->spectators[$xuid]);
        }
    }

    public function onInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $action = $event->getAction();
        $blockType = $block->getTypeId();
        $pos = $block->getPosition();
        $x = $pos->getX();
        $y = $pos->getY();
        $z = $pos->getZ();

        if ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            if ($blockType === CustomBlockIds::CAVEBLOCK) {
                $this->spectators[$player->getXuid()] = [
                    "gamemode" => $player->getGamemode(),
                    "position" => $player->getPosition()
                ];
                $player->setNoClientPredictions(true);
                $player->teleport($player->getPosition()->subtract(0, 3, 0));
                $player->setGamemode(GameMode::SPECTATOR);
                $player->sendMessage(Utils::PREFIX . "§fVous pouvez en sortir en sprintant");
                return;
            }

            if ($blockType === CustomBlockIds::DRAWER) {
                $event->cancel();
                if (!$player->isSneaking()) {
                    $count = DrawerManager::getCount($x, $y, $z);
                    if ($count < 1) {
                        $player->sendMessage(Utils::PREFIX . "§cLe drawer est vide");
                        return;
                    }

                    if (DrawerManager::isUsed($x, $y, $z)) {
                        $player->sendMessage(Utils::PREFIX . "§cAttendez, quelqu'un utilise le drawer");
                        return;
                    }

                    self::drawerUI($player, $x, $y, $z);
                    return;
                }

                $cfg = new Config(Main::getInstance()->getDataFolder() . "blocks/drawer.json", Config::JSON);
                $count = DrawerManager::getCount($x, $y, $z);
                $hand = $player->getInventory()->getItemInHand();

                if ($count >= 2000) {
                    $player->sendMessage(Utils::PREFIX . "§cVous avez atteint la limite du drawer");
                    return;
                }

                if ($hand->getTypeId() === VanillaBlocks::AIR()->getTypeId()) {
                    return;
                }

                if (DrawerManager::isUsed($x, $y, $z)) {
                    $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas utiliser le drawer, un autre joueur l’utilise déjà");
                    return;
                }

                if ($hand->hasEnchantments()) {
                    $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas mettre des items enchantés");
                    return;
                }

                if ($hand instanceof Durable && $hand->getDamage() > 0) {
                    $player->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas mettre des items endommagés");
                    return;
                }

                $auction = bin2hex(Utils::ItemSerialize($hand));
                if ($auction === '') {
                    $player->sendMessage(Utils::PREFIX . "§cVous avez rien dans votre main");
                    return;
                }

                if ($count >= 1) {
                    $item = Utils::ItemDeserialize($cfg->get("drawer-{$x}.{$y}.{$z}")['name']);
                    if ($hand->getTypeId() !== $item->getTypeId()) {
                        return;
                    }
                }

                $player->getInventory()->removeItem($hand->setCount(1));
                DrawerManager::setItem($x, $y, $z, $auction, $auction);
            }
        }
    }

    public function getRayByItem(): int
    {
        return 8;
    }

    public function getSeedsInInventory(Player $player): ?Item
    {
        $seeds = [
            VanillaItems::WHEAT(),
            VanillaItems::BEETROOT(),
            VanillaItems::CARROT(),
            VanillaItems::POTATO(),
            CustomiesItemFactory::getInstance()->get(CustomItem::COTON_CROP_SEED),
            CustomiesItemFactory::getInstance()->get(CustomItem::STRAWBERRY_CROP_SEED),
            CustomiesItemFactory::getInstance()->get(CustomItem::TOMATO_CROP_SEED),
            CustomiesItemFactory::getInstance()->get(CustomItem::LUNAIRE_SEED)
        ];

        foreach ($seeds as $id) {
            if ($player->getInventory()->contains($id)) {
                return $id;
            }
        }
        return null;
    }

    public function getBlockByItem(Item $item): Block
    {
        return match ($item->getTypeId()) {
            ItemTypeIds::WHEAT_SEEDS => VanillaBlocks::WHEAT(),
            ItemTypeIds::BEETROOT_SEEDS => VanillaBlocks::BEETROOTS(),
            ItemTypeIds::CARROT => VanillaBlocks::CARROTS(),
            ItemTypeIds::POTATO => VanillaBlocks::POTATOES(),
            CustomiesItemFactory::getInstance()->get(CustomItem::COTON)->getTypeId() => CustomiesItemFactory::getInstance()->get(CustomItem::COTON_CROP_SEED)->getBlock(),
            CustomiesItemFactory::getInstance()->get(CustomItem::TOMATO)->getTypeId() => CustomiesItemFactory::getInstance()->get(CustomItem::STRAWBERRY_CROP_SEED)->getBlock(),
            CustomiesItemFactory::getInstance()->get(CustomItem::STRAWBERRY)->getTypeId() => CustomiesItemFactory::getInstance()->get(CustomItem::TOMATO_CROP_SEED)->getBlock(),
            CustomiesItemFactory::getInstance()->get(CustomItem::LUNAIRE_SEED)->getTypeId() => CustomiesItemFactory::getInstance()->get(CustomItem::LUNAIRE_SEED)->getBlock()
        };
    }

    public static function drawerUI(Player $player, $x, $y, $z)
    {
        $cfg = new Config(Main::getInstance()->getDataFolder() . "blocks/drawer.json", Config::JSON);

        DrawerManager::setUsed($x, $y, $z, true);

        $cfg->save();
        $form = new CustomForm(function (Player $player, array $data = null) use ($x, $y, $z, $cfg) {
            if (is_null($data)) {
                DrawerManager::setUsed($x, $y, $z, false);
                $cfg->save();
                return true;
            }
            if (is_null($cfg->get("drawer-{$x}.{$y}.{$z}")['name'])) return true;


            DrawerManager::setUsed($x, $y, $z, false);
            $cfg->save();
            DrawerManager::removeItem($x, $y, $z, $data[1]);

            $item = Utils::ItemDeserialize($cfg->get("drawer-{$x}.{$y}.{$z}")['id']);

            $player->getInventory()->addItem($item->setCount($data[1]));
            $player->sendMessage(Utils::PREFIX . "Vous avez retiré §5" . $data[1] . " " . $item->getName());
            return false;
        });
        $item = Utils::ItemDeserialize($cfg->get("drawer-{$x}.{$y}.{$z}")['name']);
        $form->setTitle("§l§5DRAWER");
        $form->addLabel("Voici l'interface du §5Drawer§f, Vous pouvez voir l'item du §5Drawer §fou le retiré");
        $form->addSlider($item->getName(), 1, DrawerManager::getCount($x, $y, $z), 1, -1);
        $player->sendForm($form);
    }

    private function checkAndStart(Player $player, Item $item)
    {
    }


}