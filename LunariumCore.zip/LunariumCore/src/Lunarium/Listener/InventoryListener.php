<?php

namespace Lunarium\Listener;

use Lunarium\API\StaffAPI;
use pocketmine\block\inventory\EnderChestInventory;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\inventory\InventoryOpenEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;

class InventoryListener implements Listener {

    public array $slots = [
        "slots.voyageur" => 13,
        "slots.guerrier" => 21,
        "slots.lunaire" => 27
    ];

    public function onTransac(InventoryTransactionEvent $event): void{
        $player = $event->getTransaction()->getSource();

        if (StaffAPI::isStaff($player)){
            $event->cancel();
        }

        foreach ($event->getTransaction()->getActions() as $action) {
            $items = [$action->getTargetItem(), $action->getSourceItem()];
            /** @var Item $item */
            foreach ($items as $item) {
                if ($item->getNamedTag()->getTag("EnderChestSlot") !== null) {
                    $event->cancel();
                }
            }
        }
    }

    public function onOpen(InventoryOpenEvent $event)
    {
        if (($event->getInventory()->getItem(0)->getNamedTag()->getTag("EnderChestCommand") !== null) or ($event->getInventory() instanceof EnderChestInventory)) {
            $player = $event->getPlayer();
            foreach ($event->getInventory()->getContents() as $slot => $item) {
                if ($item->getNamedTag()->getTag("EnderChestSlot") !== null) {
                    $event->getInventory()->setItem($slot, VanillaItems::AIR());
                }
            }

            $slot = 6;
            foreach ($this->slots as $perm => $int) {
                if ($player->hasPermission($perm)) $slot = $int;
            }

            $item = VanillaBlocks::BARRIER()->asItem()->setCustomName("§4x");
            $item->getNamedTag()->setString("EnderChestSlot", "EnderChestSlot");
            for ($i = $slot; $i !== 27; $i++) {
                if ($event->getInventory()->getItem($i)->getNamedTag()->getTag("EnderChestSlot") !== null) {
                    $player->getWorld()->dropItem($player->getPosition(), $event->getInventory()->getItem($i));
                }

                $event->getInventory()->setItem($i, $item);
            }
        }
    }

}