<?php

namespace Lunarium\Listener;

use Lunarium\Main;
use Lunarium\Managers\FactionManager;
use Lunarium\Utils\Utils;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\ItemTypeIds;
use pocketmine\player\Player;

class FactionListener implements Listener
{
    public function onJoinPlayer(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        if (!FactionManager::$power->exists($player->getName())) {
            FactionManager::$power->set($player->getName(), 0);
            FactionManager::$power->save();
        }
    }
    public function entityDamage(EntityDamageByEntityEvent $event): void
    {
        $player = $event->getEntity();
        $sender = $event->getDamager();
        $api = Main::getInstance()->getFactionManager();


        if (!$api->isInFaction($player)) return;
        if (!$api->isInFaction($sender)) return;

        if ($api->getFactionPlayer($sender) === $api->getFactionPlayer($player)) {
            $event->cancel();
        }
        if ($api->isAlly($api->getFactionPlayer($sender), $api->getFactionPlayer($player))) {
            $event->cancel();
        }
    }

    public function onChat(PlayerChatEvent $event): void
    {
        $api = Main::getInstance()->getFactionManager();
        $player = $event->getPlayer();
        if ($api->isInFaction($player)) {
            if ($api->getChatPlayer($player) !== "global") {
                $event->cancel();
                if ($api->getChatPlayer($player) === "ally") {
                    $api->sendChatAlly($api->getFactionPlayer($player), "§d§lALLIÉ §r§f| §d" . $api->getFactionPlayer($player) . " {$player->getName()} §f: §d{$event->getMessage()}");
                } else $api->sendChatFaction($api->getFactionPlayer($player), "§a§lFACTION §r§f| §a{$player->getName()} §f: §a{$event->getMessage()}");
            }
        }
    }
    public function onInteract(PlayerInteractEvent $event):void
    {
        $api = Main::getInstance()->getFactionManager();
        $player = $event->getPlayer();
        $item = $event->getItem();
        if($event->getBlock()->getTypeId() === VanillaBlocks::AIR()->getTypeId()){
            $pos = $player;
        }else $pos = $event->getBlock();

        if($api->isChunkClaim($pos->getPosition())){
            if($api->isInFaction($player)){
                if($api->getFactionClaim($pos->getPosition()) !== $api->getFactionPlayer($player)){
                    switch ($item->getTypeId()){
                        case ItemTypeIds::BUCKET:
                        case ItemTypeIds::LAVA_BUCKET:
                        case ItemTypeIds::WATER_BUCKET:

                        case ItemTypeIds::DIAMOND_HOE:
                        case ItemTypeIds::GOLDEN_HOE:
                        case ItemTypeIds::IRON_HOE:
                        case ItemTypeIds::STONE_HOE:
                        case ItemTypeIds::NETHERITE_HOE:
                        case ItemTypeIds::WOODEN_HOE:

                        case ItemTypeIds::DIAMOND_SHOVEL:
                        case ItemTypeIds::GOLDEN_SHOVEL:
                        case ItemTypeIds::IRON_SHOVEL:
                        case ItemTypeIds::STONE_SHOVEL:
                        case ItemTypeIds::WOODEN_SHOVEL:
                        case ItemTypeIds::NETHERITE_SHOVEL:

                        case ItemTypeIds::FLINT:
                            $event->cancel();
                            break;
                    }
                    $event->cancel();
                }
            }else $event->cancel();
        }
    }
    public function onBlockBreak(BlockBreakEvent $event):void
    {
        $api = Main::getInstance()->getFactionManager();
        $player = $event->getPlayer();
        if($event->getBlock()->getTypeId() === VanillaBlocks::AIR()->getTypeId()){
            $pos = $player;
        }else $pos = $event->getBlock();

        if($api->isChunkClaim($pos->getPosition())){
            if($api->isInFaction($player)){
                if($api->getFactionClaim($pos->getPosition()) !== $api->getFactionPlayer($player)){
                    $event->cancel();
                }
            }else $event->cancel();
        }
    }
    public function onBlockPlace(BlockPlaceEvent $event):void
    {
        $api = Main::getInstance()->getFactionManager();
        $player = $event->getPlayer();
        foreach ($event->getTransaction()->getBlocks() as $block) {
            if ($block[3]->getTypeId() === VanillaBlocks::AIR()->getTypeId()) {
                $pos = $player;
            } else $pos = $block[3];

            if ($api->isChunkClaim($pos->getPosition())) {
                if ($api->isInFaction($player)) {
                    if ($api->getFactionClaim($pos->getPosition()) !== $api->getFactionPlayer($player)) {
                        $event->cancel();
                    }
                } else $event->cancel();
            }
        }
    }

    public function onMove(PlayerMoveEvent $event): void
    {
        $api = Main::getInstance()->getFactionManager();
        $player = $event->getPlayer();
        if ($api->isChunkClaim($event->getTo())) {
            if ($api->isChunkClaim($event->getFrom())) {
                if ($api->getFactionClaim($event->getFrom()) !== $api->getFactionClaim($event->getTo())) {
                    $player->sendTitle($api->getFactionClaim($event->getTo()));
                }
            } else $player->sendTitle($api->getFactionClaim($event->getTo()));
        }
    }
    public function onDeath(PlayerDeathEvent $event)
    {
        $api = Main::getInstance()->getFactionManager();
        $player = $event->getPlayer();
        if ($api->getPowerPlayer($player) >= 2) {
            $api->removePowerPlayer($player, 2);
        }
        $cause = $player->getLastDamageCause();
        if ($cause instanceof EntityDamageByEntityEvent) {
            $sender = $cause->getDamager();
            if($sender instanceof Player) {
                $rand = rand(1, 5);
                $api->addPowerPlayer($sender, $rand);
                $sender->sendActionBarMessage(Utils::PREFIX . "+§9{$rand} powers §fpour avoir tué §9{$player->getName()}");
            }
        }
    }
    public function Eat(PlayerItemConsumeEvent $event):void
    {
        $api = Main::getInstance()->getFactionManager();
        $player = $event->getPlayer();
        if ($api->isChunkClaim($player->getPosition())) {
            $event->uncancel();
        }
    }
    public function Projectile(ProjectileLaunchEvent $event):void
    {
        $api = Main::getInstance()->getFactionManager();
        if ($api->isChunkClaim($event->getEntity()->getPosition())) {
            $event->uncancel();
        }
    }
}