<?php

namespace Lunarium\Listener\Events;

use Lunarium\Main;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\Listener;
use pocketmine\player\chat\LegacyRawChatFormatter;

class PlayerRankEv implements Listener
{
    public function onJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        $Main = Main::getInstance();

        $Main->createPlayer($player);
        $Main->initPermission($player);

        self::updateNameTag($player);

        if (!$Main->existPlayer($player)) {
            $Main->createPlayer($player);
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void
    {
        $player = $event->getEntity();
        if ($player instanceof Player) {
            self::updateNameTag($player);
        }
    }

    public function onChat(PlayerChatEvent $event): void
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $rank = $this->formatRank(Main::getInstance()->getRank($player));
        $fac = self::getFaction($player);

        [$color, $bracketsColor] = $this->getRankColors($rank);

        $event->setFormatter(new LegacyRawChatFormatter(
            "§f[§e{$fac}§f] {$bracketsColor}[{$color}{$rank}{$bracketsColor}] {$color}{$name}{$color} §f: {$event->getMessage()}"
        ));
    }

    public static function getFaction(Player $player): string
    {
        $factionAPI = Main::getInstance()->getFactionManager();
        return $factionAPI->isInFaction($player)
            ? $factionAPI->getFactionPlayer($player)
            : "§e...";
    }

    public static function updateNameTag(Player $player): void
    {
        $name = $player->getName();
        $rank = self::formatRank(Main::getInstance()->getRank($player));
        $fac = self::getFaction($player);

        [$color, $bracketsColor] = self::getRankColors($rank);

        $player->setNameTag("§f[§e{$fac}§f] \n{$bracketsColor}[{$color}{$rank}{$bracketsColor}]{$color} {$name}");
    }

    public static function formatRank(string $rank): string
    {
        return match ($rank) {
            "Moderateur" => "Modérateur",
            "Super-Moderateur" => "Super-Modérateur",
            "Youtubeur" => "§cYou§4tube",
            default => $rank,
        };
    }

    public static function getRankColors(string $rank): array
    {
        return match ($rank) {
            "Fondateur" => ["§4", "§c"],
            "§cYou§4tube", "Administrateur" => ["§c", "§4"],
            "Super-Modérateur" => ["§2", "§a"],
            "Modérateur" => ["§a", "§2"],
            "Ange", "Guide" => ["§1", "§9"],
            "Builder" => ["§6", "§e"],
            "Responsable", "Divin" => ["§5", "§d"],
            "Roi-Mage" => ["§e", "§6"],
            "Streameur", "Cavalier" => ["§d", "§5"],
            default => ["§7", "§8"],
        };
    }
}
