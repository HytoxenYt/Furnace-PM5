<?php

namespace Lunarium\Listener;

use CortexPE\DiscordWebhookAPI\Message;
use CortexPE\DiscordWebhookAPI\Webhook;
use Lunarium\Utils\Utils;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerGameModeChangeEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\Server;
use pocketmine\world\sound\EndermanTeleportSound;
use Symfony\Component\Filesystem\Path;

class LogsListener implements Listener
{
    public function onChat(PlayerChatEvent $event): void
    {
        $webhook = new Webhook("https://discordapp.com/api/webhooks/1324130123300995152/UZFf3iq0RDd54wNjVafNzpnKkkuumbP6W4wILCf8IDYoEeVWylCKayV9ohx9_vygqIx1");
        $msg = new Message();
        $msg->setContent("**[LOGS]** {$event->getPlayer()->getName()} : {$event->getMessage()}");
        $webhook->send($msg);
    }

    public function onJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();

        $event->setJoinMessage("§f[§a+§f] {$player->getName()}");
        $webhook = new Webhook("https://discordapp.com/api/webhooks/1324130255832748042/yO9EmBXORr-F8Xy3eqmvm5EpjRjDESnHcf2thMhvG_tODfVTlaY1gRop1Lk1pKjVU7A8");
        $msg = new Message();
        $msg->setContent("[+] {$player->getName()}");
        $webhook->send($msg);
    }

    public function onQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();

        $event->setQuitMessage("§f[§c-§f] {$player->getName()}");
        $webhook = new Webhook("https://discordapp.com/api/webhooks/1324130255832748042/yO9EmBXORr-F8Xy3eqmvm5EpjRjDESnHcf2thMhvG_tODfVTlaY1gRop1Lk1pKjVU7A8");
        $msg = new Message();
        $msg->setContent("[-] {$player->getName()}");
        $webhook->send($msg);
    }

    public function onCommand(CommandEvent $event): void
    {
        $webhook = new Webhook("https://discordapp.com/api/webhooks/1324130535932690442/Hsc1BPBXKYxAPcs8bKQOZs3k0ln_MfP_NKDu9HfVFyYNdWwKqfDtacjU88oUaHLBGeef");
        $msg = new Message();
        $msg->setContent("**[LOGS]** {$event->getSender()->getName()} -> /{$event->getCommand()}");
        $webhook->send($msg);
        Server::getInstance()->getLogger()->info("{$event->getSender()->getName()} -> /{$event->getCommand()}");
    }

    public function onGamemode(PlayerGameModeChangeEvent $event): void
    {
        $player = $event->getPlayer();

        $webhook = new Webhook("https://discordapp.com/api/webhooks/1324130720368558111/HGjiIrp6AzonO1QypDCnzpSb30_dkyHbK0SuQWh4_Pe-v-2E8o2Blej0O8DJam3z4N0u");
        $msg = new Message();
        $msg->setContent("**[LOGS]** {$player->getName()} à changé de mode de jeu");
        $webhook->send($msg);
    }

    public function onDeath(PlayerDeathEvent $event): void
    {
        $player = $event->getPlayer();
        $webhook = new Webhook("https://discordapp.com/api/webhooks/1324130720368558111/HGjiIrp6AzonO1QypDCnzpSb30_dkyHbK0SuQWh4_Pe-v-2E8o2Blej0O8DJam3z4N0u");
        $msg = new Message();
        $msg->setContent("**[LOGS]** **{$player->getName()}** est mort");
        $webhook->send($msg);
    }
}