<?php

namespace Lunarium\Listener;

use Lunarium\API\FreezeAPI;
use Lunarium\API\StaffAPI;
use Lunarium\Main;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\console\ConsoleCommandSender;
class StaffListener implements Listener
{

    /**
     * @param PlayerItemUseEvent $event
     * @return void
     */
    public function onUseItem(PlayerItemUseEvent $event): void{
        $player = $event->getPlayer();
        $item = $event->getItem();
        if (StaffAPI::isStaff($player) && $player->hasPermission("staffmode.command.staff")) {
            switch ($item->getTypeId()) {
                case VanillaItems::DIAMOND()->getTypeId():
                    $event->cancel();
                    $players = [];
                    foreach (Server::getInstance()->getOnlinePlayers() as $onlinePlayer) {
                        if ($onlinePlayer->getName() !== $player->getName()) {
                            $players[] = $onlinePlayer;
                        }
                    }
                    if (empty($players)) {
                        $player->sendMessage("§c»§f Aucun autre joueur trouvé.");
                        return;
                    }
                    shuffle($players);
                    $player->teleport($players[0]->getPosition());
                    $player->sendMessage("§a»§f Vous venez d'être téléporter au joueur " . $players[0]->getName());
                    break;
                case VanillaItems::REDSTONE_DUST()->getTypeId():
                    $player->getInventory()->setItem(7, VanillaItems::EMERALD()->setCustomName("§rfVANISH: §aON"));
                    foreach (Server::getInstance()->getOnlinePlayers() as $ply){
                        $ply->showPlayer($player);
                    }
                    $player->sendMessage("§c»§f Vous n'êtes plus en vanish.");
                    break;
                case VanillaItems::EMERALD()->getTypeId():
                    $player->getInventory()->setItem(7, VanillaItems::REDSTONE_DUST()->setCustomName("§r§ffVANISH: §cOFF"));
                    foreach (Server::getInstance()->getOnlinePlayers() as $ply){
                        $ply->hidePlayer($player);
                    }
                    $player->sendMessage("§a»§f Vous êtes désormais en VanishCommand.");
                    break;
            }
        }
    }

    /**
     * @param EntityDamageByEntityEvent $event
     * @return void
     */
    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void{
        $damager = $event->getDamager();
        $entity = $event->getEntity();
        if ($damager instanceof Player && $entity instanceof Player){
            if (StaffAPI::isStaff($damager) && $damager->hasPermission("staffmode.command.staff")){
                $event->cancel();
                $item = $damager->getInventory()->getItemInHand();
                switch ($item->getTypeId()){
                    // FREEZE UNFREEZE
                    case VanillaBlocks::FROSTED_ICE()->asItem()->getTypeId():
                        if (FreezeAPI::isFrozen($entity)){
                            FreezeAPI::setUnfrozen($entity);
                            $damager->sendMessage("§5[Lunarium] §d " . $entity->getName() . " est désormais libre.");
                        }else{
                            FreezeAPI::setFrozen($entity);
                            $damager->sendMessage("§5[Lunarium] §d Vous venez de freeze " . $entity->getName());
                        }
                        break;
                    case VanillaItems::BLAZE_ROD()->getTypeId():
                        Server::getInstance()->dispatchCommand($damager, "ss " . $entity->getName());
                        break;
                }
            }
        }
    }

    /**
     * @param EntityItemPickupEvent $event
     * @return void
     */
    public function onEntityPickup(EntityItemPickupEvent $event): void{
        $entity = $event->getEntity();
        if ($entity instanceof Player){
            if (StaffAPI::isStaff($entity)){
                $event->cancel();
            }
        }
    }

    /**
     * @param PlayerDropItemEvent $event
     * @return void
     */
    public function onDrop(PlayerDropItemEvent $event): void{
        $player = $event->getPlayer();
        if (StaffAPI::isStaff($player)){
            $event->cancel();
        }
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function onQuit(PlayerQuitEvent $event): void{
        $player = $event->getPlayer();
        if (StaffAPI::isStaff($player)){
            StaffAPI::removeStaff($player);
            $name = $player->getName();
            $server = Server::getInstance();
            $server->dispatchCommand(new ConsoleCommandSender($server, $server->getLanguage()),"unsetuperm \"$name\" interact.mode");
        }

        if (FreezeAPI::isFrozen($player)){
            FreezeAPI::setUnfrozen($player);
            Server::getInstance()->broadcastMessage(str_replace(["{player}"], [$player->getName()], Main::getInstance()->getConfig()->get("broadcast-disconnect-frozen")));
        }
    }

    /**
     * @param BlockBreakEvent $event
     * @return void
     */
    public function onBreak(BlockBreakEvent $event): void{
        $player = $event->getPlayer();
        if (StaffAPI::isStaff($player)){
            $event->cancel();
        }
    }

    /**
     * @param BlockPlaceEvent $event
     * @return void
     */
    public function onPlace(BlockPlaceEvent $event): void{
        $player = $event->getPlayer();
        if (StaffAPI::isStaff($player)){
            $event->cancel();
        }
    }

}