<?php
namespace Lunarium\Listener;

use JsonException;
use Lunarium\Main;
use Lunarium\Utils\Region;
use Lunarium\Utils\Utils;
use pocketmine\block\Transparent;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockBurnEvent;
use pocketmine\event\block\BlockGrowEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\event\block\LeavesDecayEvent;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityExplodeEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\item\Hoe;
use pocketmine\item\ItemBlock;
use pocketmine\item\ItemTypeIds;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Limits;



class RegionListener implements Listener
{
    public function PlayerMove(PlayerMoveEvent $event): void
    {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        $region = Utils::getRegion($player);
        $newRegion = Utils::getRegion($player, true);

        $regionName = "";
        $newRegionName = "";

        if ($region) $regionName = $region->getName();
        if ($newRegion) $newRegionName = $newRegion->getName();

        if ($regionName !== $newRegionName) {
            if ($region) {
                $exitMessage = $region->getFlag(Region::FLAG_EXIT_MESSAGE);
                if (!empty($exitMessage)) $player->sendMessage($exitMessage);
                $brightness = $region->getFlag(Region::FLAG_BRIGHTNESS);
                if ($brightness === true) $player->getEffects()->remove(VanillaEffects::NIGHT_VISION());
            }
            if ($newRegion) {
                $entryMessage = $newRegion->getFlag(Region::FLAG_ENTRY_MESSAGE);
                if (!empty($entryMessage)) $player->sendMessage($entryMessage);
                $gamemode = $newRegion->getFlag(Region::FLAG_GAMEMODE);
                if (!Utils::bypassRegion($player)) {
                    if (!Server::getInstance()->isOp($player->getName())) {
                        $player->setGamemode(GameMode::fromString(strval($gamemode)));
                    }
                }

                $brightness = $newRegion->getFlag(Region::FLAG_BRIGHTNESS);
                if ($brightness) $player->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), Limits::INT32_MAX, 0, false));
            }
        }
    }

    public function BreakBlock(BlockBreakEvent $event): void
    {
        if ($event->isCancelled()) return;

        $player = $event->getPlayer();
        $region = Main::getInstance()->getRegionManager()->getFromPosition($event->getBlock()->getPosition());
        $region2 = Main::getInstance()->getRegionManager()->getFromPosition($player->getPosition());
        if ($region and $region->getFlag(Region::FLAG_CAN_BREAK) === false or $region2 and $region2->getFlag(Region::FLAG_CAN_BREAK) === false) {
            if (!Utils::bypassRegion($player)) {
                $message = Utils::PREFIX . "Vous ne pouvez pas casser de block dans cette région";
                $player->sendMessage($message);
                $event->cancel();
            }
        }
        $pos = $event->getBlock()->getPosition();
        if ($event->isCancelled()) {
            if ($event->getBlock() instanceof Transparent) return;
            if (!($player->getGamemode()->equals(GameMode::CREATIVE()) or $player->getGamemode()->equals(GameMode::SURVIVAL()))) return;
            if ($player->getPosition()->distance($pos) <= 3.0) $player->teleport($player->getLocation());
        }
    }

    public function PlaceBlock(BlockPlaceEvent $event): void
    {
        if ($event->isCancelled()) return;

        $player = $event->getPlayer();
        $region = Main::getInstance()->getRegionManager()->getFromPosition($event->getBlockAgainst()->getPosition());
        $region2 = Main::getInstance()->getRegionManager()->getFromPosition($player->getPosition());
        if ($region and $region->getFlag(Region::FLAG_CAN_PLACE) === false or $region2 and $region2->getFlag(Region::FLAG_CAN_PLACE) === false) {
            if (!Utils::bypassRegion($player)) {
                $message = Utils::PREFIX . "Vous ne pouvez pas placer de block dans cette région";
                $player->sendMessage($message);
                $event->cancel();
            }
        }
        if ($player->getInventory()->getItemInHand() instanceof ItemBlock && strtolower($player->getInventory()->getItemInHand()->getName()) !== "air") {
            if ($event->isCancelled()) {
                if (!($player->getGamemode()->equals(GameMode::CREATIVE()) or $player->getGamemode()->equals(GameMode::SURVIVAL()))) return;
                if ($player->getLocation()->distance($event->getBlockAgainst()->getPosition()) <= 3.0) $player->teleport($player->getLocation());
            }
        }
    }

    public function EntityExplode(EntityExplodeEvent $event): void
    {
        if ($event->isCancelled()) return;

        $region = Main::getInstance()->getRegionManager()->getFromPosition($event->getEntity()->getPosition());
        if ($region and $region->getFlag(Region::FLAG_EXPLOSION) === false) {
            $event->cancel();
        }
    }

    /**
     * @throws JsonException
     */
    public function EntityInteract(PlayerInteractEvent $event): void
    {
        if ($event->isCancelled()) return;

        $player = $event->getPlayer();
        $block = $event->getBlock();

        $region = $event->getBlock()->getTypeId() !== 0 ? Main::getInstance()->getRegionManager()->getFromPosition($event->getBlock()->getPosition()) : Utils::getRegion($player, true);
        if ($region) {
            $item = $event->getItem();
            if ($item instanceof Hoe) {
                if ($block->getTypeId() === VanillaBlocks::DIRT()->getTypeId() || $block->getTypeId() === VanillaBlocks::GRASS()->getTypeId() || $block->getTypeId() === VanillaBlocks::GRASS_PATH()->getTypeId()) {
                    $event->cancel();
                    return;
                }
            }
            if (!Utils::bypassRegion($player)) {
                if ($region->getFlag(Region::FLAG_CAN_INTERACT) === true) {
                    if ($region->getFlag(Region::FLAG_CAN_PLACE) === false) {
                        switch ($item->getTypeId()) {
                            case ItemTypeIds::BUCKET:
                            case ItemTypeIds::LAVA_BUCKET:
                            case ItemTypeIds::WATER_BUCKET:

                            case ItemTypeIds::DIAMOND_HOE:
                            case ItemTypeIds::GOLDEN_HOE:
                            case ItemTypeIds::IRON_HOE:
                            case ItemTypeIds::STONE_HOE:
                            case ItemTypeIds::NETHERITE_HOE:
                            case ItemTypeIds::WOODEN_HOE:

                            case ItemTypeIds::DIAMOND_SHOVEL:
                            case ItemTypeIds::GOLDEN_SHOVEL:
                            case ItemTypeIds::IRON_SHOVEL:
                            case ItemTypeIds::STONE_SHOVEL:
                            case ItemTypeIds::WOODEN_SHOVEL:
                            case ItemTypeIds::NETHERITE_SHOVEL:

                            case ItemTypeIds::FLINT:
                                $event->cancel();
                                break;
                        }
                    }
                } else {
                    $item = $event->getItem();

                    if ($item->getTypeId() !== VanillaBlocks::AIR()->getTypeId()) {
                        if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                            if (in_array($event->getBlock()->getTypeId(), Region::INTERACT_ALLOWED)) {
                                if ($player->isSneaking() or true) return;
                            }
                            if ($region->getFlag(Region::FLAG_CAN_PLACE) === false) {
                                if ($player->getInventory()->getItemInHand() instanceof ItemBlock && strtolower($player->getInventory()->getItemInHand()->getName()) !== "air") {
                                    if ($player->getPosition()->distance($event->getBlock()->getPosition()) <= 4.0) $player->teleport($player->getLocation());
                                }
                            }
                        }

                        $event->cancel();
                    }
                }
            }
        }

        if (in_array($event->getAction(), [PlayerInteractEvent::LEFT_CLICK_BLOCK, PlayerInteractEvent::RIGHT_CLICK_BLOCK])) {
            $regionSelection = Utils::getRegionSelection($player);
            if ($regionSelection !== null) {
                if (!$regionSelection->getPos1()) {
                    $regionSelection->setPos1($event->getBlock()->getPosition()->asVector3());
                    $player->sendMessage(Utils::PREFIX . "Première position sélectionnée");
                } elseif (!$regionSelection->getPos2()) {
                    $regionSelection->setPos2($event->getBlock()->getPosition()->asVector3());
                    Utils::setRegionSelection($player, null);
                    $player->sendMessage(Utils::PREFIX . "Seconde position sélectionnée");
                    if (Main::getInstance()->getRegionManager()->add($regionSelection)) {
                        $player->sendMessage(Utils::PREFIX . "La région §d" . $regionSelection->getName() . "§f a été créée");
                    } else {
                        $player->sendMessage(Utils::PREFIX . "Une autre région portant le nom §d" . $regionSelection->getName() . " §fexiste déjà");
                    }
                }
            }
        }
    }

    public function EntityEat(PlayerExhaustEvent $event): void
    {
        if ($event->isCancelled()) return;

        $player = $event->getPlayer();
        if (!$player instanceof Player) return;
        $region = Utils::getRegion($player, true);
        if ($region and $region->getFlag(Region::FLAG_INVINCIBLE) === true) {
            $event->cancel();
        }
    }

    public function EntityDropItem(PlayerDropItemEvent $event): void
    {
        if ($event->isCancelled()) return;

        $player = $event->getPlayer();
        $region = Utils::getRegion($player, true);
        if ($region and $region->getFlag(Region::FLAG_ITEM_DROP) === false) {
            if (!Utils::bypassRegion($player)) {
                $event->cancel();
            }
        }
    }

    public function EntityDeath(PlayerDeathEvent $event): void
    {
        $player = $event->getPlayer();
        $region = Utils::getRegion($player, true);
        if ($region and $region->getFlag(Region::FLAG_KEEP_INVENTORY) === true) {
            $event->setKeepInventory(true);
            $event->setXpDropAmount(0);
        }
    }

    public function EntityChat(PlayerChatEvent $event): void
    {
        $player = $event->getPlayer();
        if ($event->isCancelled()) return;

        $region = Utils::getRegion($player, true);
        if ($region and $region->getFlag(Region::FLAG_CAN_CHAT) === false) {
            if (!Utils::bypassRegion($player)) {
                $message = Utils::PREFIX . "Vous ne pouvez pas parlé dans cette région";
                $player->sendMessage($message);
                $event->cancel();
            }
        }
    }

    public function LeavesDecay(LeavesDecayEvent $event): void
    {
        if ($event->isCancelled()) return;

        $region = Main::getInstance()->getRegionManager()->getFromPosition($event->getBlock()->getPosition());
        if ($region and $region->getFlag(Region::FLAG_NATURAL) === false) {
            $event->cancel();
        }
    }

    public function EntityHeal(EntityRegainHealthEvent $event): void
    {
        if ($event->isCancelled()) return;
        $player = $event->getEntity();
        if (!($player instanceof Player)) return;

        $region = Utils::getRegion($player, true);
        if ($region and $region->getFlag(Region::FLAG_REGENERATION) === false) {
            $event->cancel();
        }
    }

    public function EntityRecupItem(EntityItemPickupEvent $event): void
    {
        if ($event->isCancelled()) return;

        $entity = $event->getOrigin();
        if ($entity instanceof Player) {
            $region = Utils::getRegion($entity, true);
            if ($region and $region->getFlag(Region::FLAG_ITEM_COLLECT) === false) {
                if (!Utils::bypassRegion($entity)) {
                    $event->cancel();
                }
            }
        }
    }

    public function EntityGetDamage(EntityDamageEvent $event): void
    {
        if ($event->isCancelled()) return;

        $player = $event->getEntity();
        if (!($player instanceof Player)) return;
        $region = Utils::getRegion($player, true);
        if ($region) {
            if ($region->getFlag(Region::FLAG_INVINCIBLE) === true) {
                $event->cancel();
            } elseif ($region->getFlag(Region::FLAG_FALL_DAMAGE) === false) {
                if ($event->getCause() === EntityDamageEvent::CAUSE_FALL)
                    $event->cancel();
            }
        }
    }

    public function EntityDamaging(EntityDamageByEntityEvent $event): void
    {
        if ($event->isCancelled()) return;

        $attacker = $event->getDamager();
        $victim = $event->getEntity();
        if (!($attacker instanceof Player) or !($victim instanceof Player)) return;
        foreach ([$attacker, $victim] as $entity) {
            $region = Utils::getRegion($entity, true);
            if ($region and $region->getFlag(Region::FLAG_PVP) === false) {
                $event->cancel();
                return;
            }
        }
    }

    public function PlayerCommand(CommandEvent $event): void
    {
        if ($event->isCancelled()) return;

        $sender = $event->getSender();
        if (!($sender instanceof Player)) return;
        $longCommand = ltrim($event->getCommand());
        $args = explode(" ", $longCommand);
        $command = strtolower(array_shift($args));
        $region = Utils::getRegion($sender, true);
        if ($region and $deniedCommands = $region->getFlag(Region::FLAG_DENIED_COMMANDS)) {
            if (!Utils::bypassRegion($sender)) {
                $deniedCommands = explode(",", $deniedCommands);
                if (in_array($command, $deniedCommands)) {
                    $message = Utils::PREFIX . "Vous ne pouvez pas envoyé de commande dans cette région";
                    $sender->sendMessage($message);
                    $event->cancel();
                }
            }
        }
    }

    public function BlockUpdate(BlockUpdateEvent $event): void
    {
        if ($event->isCancelled()) return;

        $region = Main::getInstance()->getRegionManager()->getFromPosition($event->getBlock()->getPosition());
        if ($region and $region->getFlag(Region::FLAG_NATURAL) === false) {
            $event->cancel();
        }
    }

    public function BurnBlock(BlockBurnEvent $event): void
    {
        if ($event->isCancelled()) return;

        $region = Main::getInstance()->getRegionManager()->getFromPosition($event->getBlock()->getPosition());
        if ($region and $region->getFlag(Region::FLAG_NATURAL) === false) {
            $event->cancel();
        }
    }

    public function BlockGrow(BlockGrowEvent $event): void
    {
        $region = Main::getInstance()->getRegionManager()->getFromPosition($event->getBlock()->getPosition());
        if ($region and $region->getFlag(Region::FLAG_NATURAL) === false) {
            $event->cancel();
        }
    }

    public function ProjectileLaunch(ProjectileLaunchEvent $event): void
    {
        if ($event->isCancelled()) return;

        $region = Main::getInstance()->getRegionManager()->getFromPosition($event->getEntity()->getPosition());
        if ($region and $region->getFlag(Region::FLAG_PROJECTILES) === false) {
            $event->cancel();
        }
    }

    public function SignEdit(SignChangeEvent $event): void
    {
        $player = $event->getPlayer();
        if ($event->isCancelled()) return;

        $region = Utils::getRegion($player, true);
        if ($region and $region->getFlag(Region::FLAG_CAN_BREAK) === false) {
            if (!Utils::bypassRegion($player)) {
                $message = Utils::PREFIX . "Vous ne pouvez pas édité des panneaux dans cette région";
                $player->sendMessage($message);
                $event->cancel();
            }
        }
    }
}