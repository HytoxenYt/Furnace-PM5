<?php

namespace Lunarium\Listener;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\item\CustomiesItemFactory;
use jojoe77777\FormAPI\SimpleForm;
use JsonException;
use Lunarium\LunaMod\Blocks\CustomBlockIds;
use Lunarium\LunaMod\Blocks\Utility\Cobblebreaker;
use Lunarium\LunaMod\Blocks\Utility\Drawer;
use Lunarium\LunaMod\Item\CustomItem;
use Lunarium\Main;
use Lunarium\Managers\DrawerManager;
use Lunarium\Managers\JobsManager;
use Lunarium\Utils\Region;
use Lunarium\Utils\Utils;
use pocketmine\block\Air;
use pocketmine\block\Bedrock;
use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Crops;
use pocketmine\block\Leaves;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\player\PlayerToggleSneakEvent;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\world\Position;
use pocketmine\world\sound\BlockBreakSound;
use pocketmine\world\World;

class BlockListener implements Listener
{
    /**
     * @throws JsonException
     */
    public function onBreak(BlockBreakEvent $event): void
    {
        $block = $event->getBlock();
        $player = $event->getPlayer();
        $world = $player->getWorld();

        if ($block->getTypeId() === CustomBlockIds::LAVA_OBSIDIAN_ID) {
            $world->addSound($block->getPosition(), new BlockBreakSound(VanillaBlocks::OBSIDIAN()));
        }
        if ($block->getTypeId() === CustomBlockIds::LUNAIRE_LEAVES_ID) {
            $event->setDrops([]);
            $world->addSound($block->getPosition(), new BlockBreakSound(VanillaBlocks::OAK_LEAVES()));
        }

        $this->handleXPForJobs($player, $block);

        $x = $block->getPosition()->getX();
        $y = $block->getPosition()->getY();
        $z = $block->getPosition()->getZ();
        $cfg = new Config(Main::getInstance()->getDataFolder()."blocks/drawer.json", Config::JSON);
        if($block->getTypeId() == CustomBlockIds::DRAWER){
            if (DrawerManager::isUsed($x,$y,$z) === false) {
                if (is_null($cfg->get("drawer-{$x}.{$y}.{$z}")['id'])) return;
                if (is_null($cfg->get("count-{$x}.{$y}.{$z}"))) return;
                if ($cfg->get("count-{$x}.{$y}.{$z}") <= 0) return;
                $drawer = Utils::ItemDeserialize($cfg->get("drawer-{$x}.{$y}.{$z}")['id']);
                $block->getPosition()->getWorld()->dropItem($block->getPosition(), $drawer->setCount((int) DrawerManager::getCount($x,$y,$z)));
                DrawerManager::removeDrawer($x, $y, $z);
            } else {
                $event->cancel();
                $event->getPlayer()->sendMessage(Utils::PREFIX . "§cVous ne pouvez pas utiliser le drawer car un autre joueur l’utilise déjà");
            }
        }
    }

    /**
     * @throws JsonException
     */
    private function handleXPForJobs($player, $block): void
    {
        $xpBoostMultipliers = [
            "Cavalier" => 1.25,
            "Roi-Mage" => 1.75,
            "Ange" => 2.25,
            "Divin" => 2.75,
        ];

        $xpBoostMultiplier = $xpBoostMultipliers[Main::getInstance()->getRank($player)] ?? 1.0;
        $blockTypeId = $block->getTypeId();
        if ($block->hasSameTypeId(VanillaBlocks::COBBLESTONE()) || $block->hasSameTypeId(VanillaBlocks::STONE())) {
            JobsManager::addXp($player, JobsManager::MINEUR, 1);
        } else if ($block->hasSameTypeId(VanillaBlocks::MELON()) || ($block instanceof Crops && !$block->ticksRandomly())) {
            JobsManager::addXp($player, JobsManager::FERMIER, mt_rand(1, 3));
        }
        $xpRewards = [
            VanillaBlocks::DIAMOND_ORE()->getTypeId() => 15,
            VanillaBlocks::LAPIS_LAZULI_ORE()->getTypeId() => 3,
            VanillaBlocks::GOLD_ORE()->getTypeId() => 10,
            VanillaBlocks::IRON_ORE()->getTypeId() => 4,
            VanillaBlocks::COAL_ORE()->getTypeId() => 1,
            VanillaBlocks::REDSTONE_ORE()->getTypeId() => 1,
            VanillaBlocks::NETHER_QUARTZ_ORE()->getTypeId() => 1.5
        ];

        if (isset($xpRewards[$blockTypeId])) {
            JobsManager::addXp($player, JobsManager::MINEUR, $xpRewards[$blockTypeId] * $xpBoostMultiplier);
        }

        if ($block instanceof Crops && $block->getAge() === Crops::MAX_AGE) {
            $farmerRewards = [
                VanillaBlocks::CARROTS()->getTypeId() => 2,
                VanillaBlocks::POTATOES()->getTypeId() => 2,
                VanillaBlocks::WHEAT()->getTypeId() => 1,
                VanillaBlocks::PUMPKIN()->getTypeId() => 5,
                CustomiesBlockFactory::getInstance()->get("lunarium:coton_stage_3")->getTypeId() => 3,
                CustomiesBlockFactory::getInstance()->get("lunarium:tomato_stage_3")->getTypeId() => 3,
                CustomiesBlockFactory::getInstance()->get("lunarium:strawberry_stage_3")->getTypeId() => 3
            ];

            if (isset($farmerRewards[$blockTypeId])) {
                JobsManager::addXp($player, JobsManager::FERMIER, $farmerRewards[$blockTypeId] * $xpBoostMultiplier);
            }
        }
    }

    public function onBlockBreak(BlockBreakEvent $event): void
    {
        if ($event->isCancelled()) return;

        $player = $event->getPlayer();
        $block = $event->getBlock();
        $item = $event->getItem();

        $hammerTypeId = $item->getTypeId();
        if ($hammerTypeId !== CustomiesItemFactory::getInstance()->get(CustomItem::NACRE_HAMMER)->getTypeId() &&
            $hammerTypeId !== CustomiesItemFactory::getInstance()->get(CustomItem::LUNAIRE_HAMMER)->getTypeId() &&
            $hammerTypeId !== CustomiesItemFactory::getInstance()->get(CustomItem::JADE_HAMMER)->getTypeId()) {
            return;
        }

        $blockPos = $block->getPosition();
        $blockWorld = $blockPos->getWorld();
        $radius = match ($hammerTypeId) {
            CustomiesItemFactory::getInstance()->get(CustomItem::NACRE_HAMMER)->getTypeId() => 2,
            CustomiesItemFactory::getInstance()->get(CustomItem::JADE_HAMMER)->getTypeId() => 1,
            CustomiesItemFactory::getInstance()->get(CustomItem::LUNAIRE_HAMMER)->getTypeId() => 3,
            default => 1
        };

        $minX = $blockPos->x - $radius;
        $maxX = $blockPos->x + $radius;
        $minY = $blockPos->y - $radius;
        $maxY = $blockPos->y + $radius;
        $minZ = $blockPos->z - $radius;
        $maxZ = $blockPos->z + $radius;

        for ($x = $minX; $x <= $maxX; $x++) {
            for ($y = $minY; $y <= $maxY; $y++) {
                for ($z = $minZ; $z <= $maxZ; $z++) {
                    $currentBlock = $blockWorld->getBlockAt($x, $y, $z);
                    if ($currentBlock instanceof Bedrock || $currentBlock instanceof Air) {
                        continue;
                    }

                    $region = Main::getInstance()->getRegionManager()->getFromPosition(new Position($x, $y, $z, $blockWorld));
                    $region1 = Main::getInstance()->getRegionManager()->getFromPosition($player->getPosition());
                    if ($region && $region->getFlag(Region::FLAG_CAN_BREAK) === false) {
                        continue;
                    }
                    $faction = Main::getInstance()->getFactionManager();
                    if ($faction->isChunkClaim($currentBlock->getPosition()) && $faction->isInFaction($player)) {
                        $posChunk = $faction->getPosChunk($currentBlock->getPosition());
                        $chunk = $faction->getClaim($posChunk[0], $posChunk[1]);
                        $factionPlayer = $faction->getFactionPlayer($player);
                        $chunkFaction = $faction->getFactionClaim($currentBlock->getPosition());
                        if ($chunk && $factionPlayer !== $chunkFaction) {
                            continue;
                        }
                    }
                    if ($region === null && $region1 === null) {

                        $event->cancel();

                        $this->handleXPForJobs($player, $currentBlock);
                    }

                    $position = new Vector3($x, $y, $z);
                    $blockWorld->setBlock($position, VanillaBlocks::AIR());
                    $blockWorld->dropItem($position, $currentBlock->asItem());
                }
            }
        }
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $iteminhand = $player->getInventory()->getItemInHand();
        if ($block instanceof Cobblebreaker) {
            if ($iteminhand->equals(CustomiesItemFactory::getInstance()->get(CustomItem::COMPRESSED_STONE))) {
                $iteminhand->setCount($iteminhand->getCount() - 1);
                $player->getInventory()->setItemInHand($iteminhand);

                $reward = $this->getRandomReward();
                $player->getInventory()->addItem($reward);

                $player->sendMessage(Utils::PREFIX . "Vous avez reçu une graine en §b" . $reward->getName());
            } else {
                if ($event->getAction() === $event::RIGHT_CLICK_BLOCK) {
                    $form = new SimpleForm(null);
                    $form->setTitle("§l§5COBBLEBREAKER");
                    $form->setContent("§fVous pouvez avoir\n\n§f- §550%%§f: 1 graine en §5Coton\n§f- §525%%§f: 1 graine en §5Tomate\n§f- §520%%§f: 1 graine en §5Fraise\n§f- §55%%§f: 1 graine en §5Lunaire");
                    $form->sendToPlayer($player);
                }
            }
        }


    }

    public function getRandomReward(): ?Item
    {
        $seeds = [
            ["item" => "lunarium:coton_crop_seed", "chance" => 50],
            ["item" => "lunarium:tomato_crop_seed", "chance" => 25],
            ["item" => "lunarium:strawberry_crop_seed", "chance" => 20],
            ["item" => "lunarium:lunaire_seed", "chance" => 5]
        ];

        $random = mt_rand(1, 100);
        $cumulativeChance = 0;

        foreach ($seeds as $seed) {
            $cumulativeChance += $seed["chance"];
            if ($random <= $cumulativeChance) {
                return CustomiesItemFactory::getInstance()->get($seed["item"]);
            }
        }

        return null;
    }

    public function onBlockPlace(BlockPlaceEvent $event): void
    {
        foreach($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
            if($block->getTypeId() == CustomBlockIds::DRAWER) {
                DrawerManager::addDrawer($x, $y, $z);
            }
        }
    }

    public function onBlockUpdate(BlockUpdateEvent $event): void
    {
        $block = $event->getBlock();

        $leavesBlocks = [
            VanillaBlocks::ACACIA_LEAVES(),
            VanillaBlocks::AZALEA_LEAVES(),
            VanillaBlocks::BIRCH_LEAVES(),
            VanillaBlocks::CHERRY_LEAVES(),
            VanillaBlocks::DARK_OAK_LEAVES(),
            VanillaBlocks::FLOWERING_AZALEA_LEAVES(),
            VanillaBlocks::JUNGLE_LEAVES(),
            VanillaBlocks::MANGROVE_LEAVES(),
            VanillaBlocks::OAK_LEAVES(),
            VanillaBlocks::SPRUCE_LEAVES(),
        ];

        if ($block instanceof Leaves || in_array($block, $leavesBlocks, true)) {
            $event->cancel();
        }
    }

}