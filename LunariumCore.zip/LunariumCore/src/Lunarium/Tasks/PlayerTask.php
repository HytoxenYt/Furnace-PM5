<?php

namespace Lunarium\Tasks;

use customiesdevs\customies\item\CustomiesItemFactory;
use Lunarium\Effects\CustomEffects;
use Lunarium\LunaMod\Item\CustomItem;
use Lunarium\Main;
use Lunarium\Managers\MoneyManager;
use Lunarium\Managers\ScoreboardManager;
use Lunarium\Utils\Utils;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Human;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\world\format\Chunk;
use pocketmine\world\particle\RedstoneParticle;

class PlayerTask extends Task
{
    public static array $seeChunk = [];
    private const showTimes = [1200, 900, 600, 300, 240, 180, 120, 60, 30, 15, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1];
    private int $interval;
    private static float $nextExecution;

    private array $lotteryTimes = [
        60*240 => "4 heures",
        60*180 => "3 heures",
        60*120 => "2 heures",
        60*60  => "1 heure",
        60*30  => "30 minutes",
        60*10  => "10 minutes",
        60*5   => "5 minutes",
        60     => "1 minute",
        10     => "10 secondes",
        3      => "3 secondes"
    ];
    public function __construct(int $interval)
    {
        date_default_timezone_set("Europe/Paris");

        $this->interval = $interval;
        self::$nextExecution = microtime(true) + $interval;
    }

    public static function armorEffect(): void
    {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            foreach ($player->getArmorInventory()->getContents() as $armor) {
                $effectManager = $player->getEffects();

                switch ($armor->getTypeId()) {
                    case CustomiesItemFactory::getInstance()->get(CustomItem::NACRE_HELMET)->getTypeId():
                    case CustomiesItemFactory::getInstance()->get(CustomItem::JADE_HELMET)->getTypeId():
                    case CustomiesItemFactory::getInstance()->get(CustomItem::LUNAIRE_HELMET)->getTypeId():
                        $effectManager->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 15 * 20, 1, false));
                        $effectManager->add(new EffectInstance(VanillaEffects::RESISTANCE(), 15 * 20, 0, false));
                        break;

                    case CustomiesItemFactory::getInstance()->get(CustomItem::LUNAIRE_CHESTPLATE)->getTypeId():
                        $effectManager->add(new EffectInstance(CustomEffects::CUSTOM_HEALTH_BOOST_LUNAIRE(), 15 * 20, 1, false));
                        break;
                    case CustomiesItemFactory::getInstance()->get(CustomItem::NACRE_CHESTPLATE)->getTypeId():
                        $effectManager->add(new EffectInstance(CustomEffects::CUSTOM_HEALTH_BOOST_NACRE(), 15 * 20, 1, false));
                        break;

                    case CustomiesItemFactory::getInstance()->get(CustomItem::JADE_CHESTPLATE)->getTypeId():
                        $effectManager->add(new EffectInstance(CustomEffects::CUSTOM_HEALTH_BOOST_JADE(), 15 * 20, 0, false));
                        break;

                    case CustomiesItemFactory::getInstance()->get(CustomItem::LUNAIRE_LEGGINGS)->getTypeId():
                    case CustomiesItemFactory::getInstance()->get(CustomItem::NACRE_LEGGINGS)->getTypeId():
                        $effectManager->add(new EffectInstance(VanillaEffects::SPEED(), 15 * 20, 1, false));
                        break;
                    case CustomiesItemFactory::getInstance()->get(CustomItem::JADE_LEGGINGS)->getTypeId():
                        $effectManager->add(new EffectInstance(VanillaEffects::SPEED(), 15 * 20, 0, false));
                        break;
/**
                    case CustomiesItemFactory::getInstance()->get(CustomItem::FARM_HELMET)->getTypeId():
                        $effectManager->add(new EffectInstance(VanillaEffects::HASTE(), 15 * 20, 0, false));
                        $effectManager->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 15 * 20, 0, false));
                        break;

                    case CustomiesItemFactory::getInstance()->get(CustomItem::FARM_CHESTPLATE)->getTypeId():
                        $effectManager->add(new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 15 * 20, 0, false));
                        break;

                    case CustomiesItemFactory::getInstance()->get(CustomItem::FARM_LEGGINGS)->getTypeId():
                        $effectManager->add(new EffectInstance(VanillaEffects::SPEED(), 15 * 20, 2, false));
                        break;

                    case CustomiesItemFactory::getInstance()->get(CustomItem::FARM_BOOTS)->getTypeId():
                        $effectManager->add(new EffectInstance(VanillaEffects::JUMP_BOOST(), 15 * 20, 1, false));
                        break;
 * */
                }
            }
        }
    }

    public function onRun(): void
    {
        $diff = (int)(self::$nextExecution - microtime(true));
        if ($diff <= 0) {
            self::execute(Main::getInstance());
            self::$nextExecution = microtime(true) + $this->interval;
        } else {
            if (in_array($diff, self::showTimes)) {
                $message = "§d§l- §r§fProchaine suppression d'entités §l§d-\n";

                if ($diff <= 10) {
                    $message .= ($diff > 5 ? "§d" : "§d") . "§l"
                        . str_repeat(" ", 3)
                        . str_repeat("█", min($diff, 10))
                        . str_repeat("▒", 10 - $diff)
                        . str_repeat(" ", 3);
                } else {
                    $message .= str_repeat(" ", 15) . "§d";
                }

                if ($diff < 60) {
                    $message .= $diff . " " . ($diff > 1 ? "secondes" : " seconde");
                } else {
                    $minLeft = floor($diff / 60);
                    $message .= $minLeft . " minute" . ($minLeft > 1 ? "s" : "");
                }
                self::broadcast(Main::getInstance(), $message, false);
            }
        }

        self::armorEffect();

        $server = Server::getInstance();
        $config = new Config(Main::getInstance()->getDataFolder() . "lottery.yml", Config::YAML);
        $onlinePlayers = $server->getOnlinePlayers();

        Utils::$lotterietime = is_numeric($config->get("lottery_time")) ? (int)$config->get("lottery_time") : 60*240 + 1;
        $lottery = Utils::$lottery;

        if (isset($this->lotteryTimes[Utils::$lotterietime])) {
            $message = Utils::PREFIX . "§fTirage dans §d" . $this->lotteryTimes[Utils::$lotterietime] . " §7(/lottery)\n" .
                Utils::PREFIX . "§fLa lotterie contient actuellement §d{$lottery}§f$";
            $this->sendToAllPlayers($onlinePlayers, $message);
        }

        foreach ($onlinePlayers as $player) {
            if ($player instanceof Player) {
                $this->showChunkBorders($player);
                ScoreboardManager::updateScoreboard($player);
            }
        }

        if (Utils::$lotterietime === 0) {
            $this->runLotteryDraw($onlinePlayers, $config);
        } else {
            Utils::$lotterietime--;
            $config->set("lottery_time", Utils::$lotterietime);
            $config->save();
        }

        if (date("H:i:s") === "20:00:00") {
            $this->updateShopPrices();
            $server->broadcastMessage(Utils::PREFIX . "§c§k!§r§6§k!§r§e§k!§r§a§k!§r§9§k!§r §fLes prix de la bourse ont été changés, une nouvelle journée de farm commence §c§k!§r§6§k!§r§e§k!§r§a§k!§r§9§k!§f");
        }
    }

    public static function getTimeLeft(): int
    {
        return self::$nextExecution - microtime(true);
    }

    private function showChunkBorders(Player $player): void
    {
        if (isset(self::$seeChunk[$player->getXuid()])) {
            $chunkX = $player->getPosition()->getFloorX() >> Chunk::COORD_BIT_SIZE;
            $chunkZ = $player->getPosition()->getFloorZ() >> Chunk::COORD_BIT_SIZE;

            $minX = $chunkX * 16;
            $maxX = $minX + 16;
            $minZ = $chunkZ * 16;
            $maxZ = $minZ + 16;
            $y = $player->getPosition()->y + 1.5;
            $world = $player->getWorld();

            for ($x = $minX; $x <= $maxX; $x += 0.5) {
                for ($z = $minZ; $z <= $maxZ; $z += 0.5) {
                    if ($x === $minX || $x === $maxX || $z === $minZ || $z === $maxZ) {
                        $world->addParticle(new Vector3($x, $y, $z), new RedstoneParticle(), [$player]);
                    }
                }
            }
        }
    }


    public static function execute(Main $main): int
    {
        $cleared = 0;
        foreach ($main->getServer()->getWorldManager() as $level) {
            foreach ($level->getEntities() as $entity) {
                if (!($entity instanceof Human)) {
                    $entity->flagForDespawn();
                    $cleared++;
                }
            }
        }

        if ($cleared > 0) {
            $message = "§dUne entité §ca été supprimée";
            if ($cleared > 1) $message = "§d" . $cleared . " entités §font été supprimées";
        } else {
            $message = "§dAucune entité §fn'a été supprimée";
        }

        self::broadcast($main, $message, $cleared > 0);
        return $cleared;
    }

    private static function broadcast(Main $main, string $message, bool $console = true)
    {
        if ($console)
            $main->getLogger()->notice("[ClearLag] " . TextFormat::clean($message));

        foreach ($main->getServer()->getOnlinePlayers() as $player) {
            if (!$player instanceof Player) return;
            $player->sendActionBarMessage($message);
        }
    }

    private function sendToAllPlayers(array $onlinePlayers, string $message): void
    {
        foreach ($onlinePlayers as $player) {
            if ($player instanceof Player) {
                $player->sendMessage($message);
            }
        }
    }
    
    private function runLotteryDraw(array $onlinePlayers, Config $config): void
    {
        if (empty(Utils::$lotteryp)) {
            $this->sendToAllPlayers($onlinePlayers, Utils::PREFIX . "§cLa lotterie ne contient pas assez de joueurs");
        } else {
            $tickets = [];
            foreach (Utils::$lotteryp as $player => $amount) {
                $tickets = array_merge($tickets, array_fill(0, $amount, $player));
            }
            shuffle($tickets);
            $winner = $tickets[array_rand($tickets)];
            $recomp = round((Utils::$lottery / 100) * 90);

            MoneyManager::addMoney($winner, $recomp);

            $this->sendToAllPlayers(
                $onlinePlayers,
                Utils::PREFIX . "§d{$winner} §fremporte la lotterie d'un montant de §d" . Utils::$lottery . "§f §fen ayant misé §d" . Utils::$lotteryp[$winner] . "§f$"
            );
        }

        Utils::$lottery = 0;
        Utils::$lotteryp = [];
        Utils::$lotterietime = 60*240 + 1;
        $config->set("lottery_time", Utils::$lotterietime);
        $config->save();
    }

    public static function updateShopPrices(): void
    {
        $config = new Config(Main::getInstance()->getDataFolder() . "shop.yml", Config::YAML);

        $array = $config->get("Agricultures");
        $array[0] = "minecraft:wheat&Blé&" . mt_rand(3, 8) . "&textures/items/wheat&15";
        $array[1] = "minecraft:melon&Melon&" . mt_rand(1, 2) . "&textures/items/melon&15";
        $array[2] = "minecraft:pumpkin&Citrouille&" . mt_rand(3, 9) . "&textures/items/pumpkin_side&15";
        $array[3] = "minecraft:beetroot&Betterave&" . mt_rand(3, 8) . "&textures/items/beetroot&15";
        $array[4] = "minecraft:carrot&Carotte&" . mt_rand(4, 8) . "&textures/items/carrot&15";
        $array[5] = "minecraft:potato&Pomme de terre&" . mt_rand(4, 8) . "&textures/items/potato&15";
        $array[6] = "minecraft:reeds&Canne à sucre&" . mt_rand(3, 8) . "&textures/items/reeds&10";
        $array[7] = "pyritia:coton&Coton&" . mt_rand(5, 12) . "&textures/items/coton&15";
        $array[8] = "pyritia:tomato&Tomate&" . mt_rand(4, 14) . "&textures/items/tomato&15";
        $array[9] = "pyritia:strawberry&Fraise&" . mt_rand(2, 10) . "&textures/items/strawberry&15";
        $config->set("Agricultures", $array);

        $array = $config->get("Minerais");
        $array[0] = "minecraft:coal&Charbon&" . mt_rand(2, 4) . "&textures/items/coal&8";
        $array[1] = "minecraft:iron_ingot&Lingot de fer&" . mt_rand(5, 8) . "&textures/items/iron_ingot&25";
        $array[2] = "minecraft:gold_ingot&Lingot d'or&" . mt_rand(12, 20) . "&textures/items/gold_ingot&40";
        $array[3] = "minecraft:lapis_lazuli&Lapis-lazuli&" . mt_rand(1, 3) . "&textures/items/dye_powder_blue&15";
        $array[4] = "minecraft:redstone&Redstone&" . mt_rand(1, 3) . "&textures/items/redstone_dust&30";
        $array[5] = "minecraft:diamond&Diamant&" . mt_rand(25, 40) . "&textures/items/diamond&75";
        $array[6] = "minecraft:emerald&Émeraude&" . mt_rand(40, 60) . "&textures/items/emerald&0";
        $config->set("Minerais", $array);

        $config->save();
    }

}