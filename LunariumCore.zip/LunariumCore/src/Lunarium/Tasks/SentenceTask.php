<?php

namespace Lunarium\Tasks;

use Lunarium\Utils\Utils;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class SentenceTask extends Task
{
    public static array $message = [];
    public static int $old = 0;

    public function onRun(): void
    {
        $count = count(glob(Server::getInstance()->getDataPath()."players/*"));

        self::$message = [Utils::PREFIX . "§fLe saviez-vous, il y'a §d$count joueurs§f inscrit sur le serveur", Utils::PREFIX . "§fUn signalement à faire ? Créez un §dticket§f sur notre §ddiscord", Utils::PREFIX . "§fVous voulez nous contactez ou restez à l'affût des dernières mises à jours ? Rejoignez notre discord §d/discord"];

        Server::getInstance()->broadcastMessage(self::$message[self::$old]);

        self::$old++;
        if(self::$old > count(self::$message) - 1){
            self::$old = 0;
        }
    }
}