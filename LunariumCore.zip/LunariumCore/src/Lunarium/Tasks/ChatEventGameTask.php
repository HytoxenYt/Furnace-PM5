<?php

namespace Lunarium\Tasks;

use Lunarium\Utils\Utils;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ChatEventGameTask extends Task
{
    public static string $event;
    public static string $code;
    public static bool $claim;
    public static string $reponse;
    public static string $calcul;
    public static string $shuffle;


    public function onRun(): void
    {
        $event = mt_rand(1, 3);

        if ($event == 1) {
            $this->generateRandomCodeEvent();
        } elseif ($event == 2) {
            $this->generateCalculationEvent();
        } elseif ($event == 3) {
            $this->generateWordShuffleEvent();
        }
    }

    private function generateRandomCodeEvent(): void
    {
        $characters = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ1234567890';
        $code_aleatory = '';
        for ($i = 0; $i < 10; $i++) {
            $code_aleatory .= $characters[mt_rand(0, strlen($characters) - 1)];
        }
        self::$event = "texte";
        self::$code = $code_aleatory;
        self::$claim = false;
        Server::getInstance()->broadcastMessage(Utils::PREFIX . "§fSoit le premier à recopié le code pour gagné §d5.000$ \n§fCode : §d" . $code_aleatory);
    }

    private function generateCalculationEvent(): void
    {
        $signes = ["+", "-", "*"];
        $chiffre1 = mt_rand(1, 100);
        $signe1 = $signes[array_rand($signes)];
        $chiffre2 = mt_rand(1, 100);

        $difficulty = mt_rand(1, 2);
        if ($difficulty == 1) {
            $calcul_aleatoire = "{$chiffre1}{$signe1}{$chiffre2}";
        } else {
            $signe2 = $signes[array_rand($signes)];
            $chiffre3 = mt_rand(1, 100);
            $calcul_aleatoire = "{$chiffre1}{$signe1}{$chiffre2}{$signe2}{$chiffre3}";
        }

        $result = eval('return ' . $calcul_aleatoire . ';');
        self::$reponse = $result;
        self::$event = "calcul";
        self::$calcul = $calcul_aleatoire;
        self::$claim = false;
        Server::getInstance()->broadcastMessage(Utils::PREFIX . "§fSoit le premier à trouver le bon calcul pour gagné §d5.000$ \n§fCalcul : §d" . $calcul_aleatoire);
    }

    private function generateWordShuffleEvent(): void
    {
        $words = [
        "pomme", "voiture", "ordinateur", "smartphone", "bouteille",
        "tasse", "train", "tarte", "sandwich", "plage", "lait", "araignee",
        "pieds", "oignon", "banane", "tapis", "chien", "crayon", "valise",
        "fromage", "animal", "route", "casque", "moustache", "chaussure",
        "radio", "journal", "livre", "internet", "minecraft", "uniforme",
        "bibliotheque", "sport", "terrasse", "famille", "faction", "pierre",
        "terre", "coffre", "victoire", "france", "quebec", "belgique", "ecole",
        "arbre", "nature", "hamburger", "table", "bureau", "temple", "argent",
        "football", "champignon", "fleur", "armoire", "coiffeur", "pain"
    ];
        $word = $words[array_rand($words)];
        $wordShuffle = str_shuffle($word);

        self::$event = "shuffle";
        self::$shuffle = $wordShuffle;
        self::$reponse = $word;
        self::$claim = false;
        Server::getInstance()->broadcastMessage(Utils::PREFIX . "§fSoit le premier à trouver le mot de passe pour gagné §d5.000$ \n§fMot mélanger : §d" . $wordShuffle);
    }
}

