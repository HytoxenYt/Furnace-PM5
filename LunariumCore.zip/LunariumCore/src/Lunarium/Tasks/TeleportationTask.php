<?php

namespace Lunarium\Tasks;

use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\world\Position;

class TeleportationTask extends Task
{
    private Position $start_position;
    private Position $position;
    private string $message;
    private Player $player;
    private int $timer = 5;

    public function __construct(Player $player, Position $position, string $message)
    {
        $this->player = $player;
        $this->position = $position;
        $this->message = $message;
        $this->start_position = $player->getPosition();
        Main::getInstance()->getScheduler()->scheduleDelayedRepeatingTask($this, 20, 20);
    }

    public function onRun(): void
    {
        $player = $this->player;
        if (!$player->isOnline()) {
            $this->getHandler()->cancel();
            return;
        }

        if (($player->getPosition()->getFloorX() === $this->start_position->getFloorX()) and
            ($player->getPosition()->getFloorY() === $this->start_position->getFloorY()) and
            ($player->getPosition()->getFloorZ() === $this->start_position->getFloorZ())) {
            $time = $this->timer - 1;
            $player->sendTip(Utils::PREFIX . "Téléportation dans §d" . Main::getInstance()->intToTime($time));
            $this->timer--;
        } else {
            $player->sendTip(Utils::PREFIX . "La téléportation a été annulé");
            $this->getHandler()->cancel();
            return;
        }

        if ($this->timer === 0) {
            $player->teleport($this->position);
            $player->sendTip($this->message);
            $this->getHandler()->cancel();
            return;
        }
    }
}