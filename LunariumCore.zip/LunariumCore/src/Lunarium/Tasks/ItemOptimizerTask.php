<?php

namespace Lunarium\Tasks;

use Lunarium\Main;
use pocketmine\entity\object\ItemEntity;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ItemOptimizerTask extends Task
{
    public function __construct()
    {
    }

    public function onRun(): void
    {
        foreach (Main::getInstance()->getServer()->getWorldManager() as $level) {
            foreach ($level->getEntities() as $entity) {
                if (!($entity instanceof ItemEntity) || $entity->isClosed()) continue;
                if ($entity->getItem()->getCount() >= $entity->getItem()->getMaxStackSize()) continue;
                if (!empty($entities = $level->getNearbyEntities($entity->getBoundingBox()->expandedCopy(2, 2, 2), $entity))) {
                    foreach ($entities as $possibleItem) {
                        if (!$possibleItem instanceof ItemEntity || $possibleItem->isClosed()) continue;
                        if ($possibleItem->getItem()->getCount() >= $possibleItem->getItem()->getMaxStackSize()) continue;
                        if ($entity->getItem()->equals($possibleItem->getItem(), true, true)) {
                            if (($newCount = $entity->getItem()->getCount() + $possibleItem->getItem()->getCount()) >= $entity->getItem()->getMaxStackSize()) continue;
                            $entity->getItem()->setCount($newCount);
                            $entity->respawnToAll();
                            $possibleItem->close();
                        }
                    }
                }
            }
        }
    }
}