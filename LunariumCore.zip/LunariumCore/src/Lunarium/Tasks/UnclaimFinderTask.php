<?php

namespace Lunarium\Tasks;

use Lunarium\Listener\PlayerListener;
use Lunarium\LunaMod\Item\CustomItem;
use pocketmine\block\tile\Barrel;
use pocketmine\block\tile\Chest;
use pocketmine\block\tile\Furnace;
use pocketmine\block\tile\Hopper;
use pocketmine\block\tile\MonsterSpawner;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Durable;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;

class UnclaimFinderTask extends Task
{
    public function __construct(private readonly Player $player, private readonly PlayerListener $event, private readonly string $type){}

    public function onRun() : void
    {
        if ($this->type === "vert") {
            $player = $this->player;
            if (!($player->isOnline())) {
                unset($this->event->using_vert[$player->getXuid()]);
                $this->getHandler()->cancel();
                return;
            }

            $itemHeld = $player->getInventory()->getItemInHand();

            $item = StringToItemParser::getInstance()->parse(CustomItem::UNCLAIM_FINDER_VERT);

            if (!($itemHeld->equals($item, true, false))) {
                unset($this->event->using_vert[$player->getXuid()]);
                $this->getHandler()->cancel();
                return;
            }
            $chestCount = 0;
            $rayon = 16 * 3;
            $xMax = $player->getPosition()->getX() + $rayon;
            $zMax = $player->getPosition()->getZ() + $rayon;
            $pourcent = 0;

            $validTileTypes = [
                Furnace::class,
                Hopper::class,
                Barrel::class,
                Chest::class,
                MonsterSpawner::class
            ];


            for ($x = $player->getPosition()->getX() - $rayon; $x <= $xMax; $x += 16) {
                for ($z = $player->getPosition()->getZ() - $rayon; $z <= $zMax; $z += 16) {
                    $chunkX = intval($x) >> 4;
                    $chunkZ = intval($z) >> 4;
                    if (!$player->getWorld()->isChunkLoaded($chunkX, $chunkZ)) {
                        $player->getWorld()->loadChunk($chunkX, $chunkZ);
                    } else {
                        $chunk = $player->getWorld()->getChunk($chunkX, $chunkZ);
                        if (!is_null($chunk)) {
                            foreach ($chunk->getTiles() as $tile) {
                                if (in_array(get_class($tile), $validTileTypes, true)) {
                                    $pourcent++;
                                }
                            }
                        }
                    }
                }
            }

            if ($pourcent !== 0) {
                $message = "§a" . $pourcent . "§7%%";
            } else {
                $message = "§c0%%";
            }
            $player->sendPopup($message);
            $itemInHand = $player->getInventory()->getItemInHand();
            if ($itemInHand instanceof Durable) {
                $itemInHand->applyDamage(1);
                $player->getInventory()->setItemInHand($itemInHand);
            }
        } else if($this->type === "violet"){
            $player = $this->player;
            if (!($player->isOnline())) {
                unset($this->event->using_violet[$player->getXuid()]);
                $this->getHandler()->cancel();
                return;
            }

            $itemHeld = $player->getInventory()->getItemInHand();

            $item = StringToItemParser::getInstance()->parse(CustomItem::UNCLAIM_FINDER_VIOLET);

            if (!($itemHeld->equals($item, true, false))) {
                unset($this->event->using_violet[$player->getXuid()]);
                $this->getHandler()->cancel();
                return;
            }
            $chestCount = 0;
            $rayon = 16 * 6;
            $xMax = $player->getPosition()->getX() + $rayon;
            $zMax = $player->getPosition()->getZ() + $rayon;
            $pourcent = 0;

            $validTileTypes = [
                Furnace::class,
                Hopper::class,
                Barrel::class,
                Chest::class,
                MonsterSpawner::class
            ];


            for ($x = $player->getPosition()->getX() - $rayon; $x <= $xMax; $x += 16) {
                for ($z = $player->getPosition()->getZ() - $rayon; $z <= $zMax; $z += 16) {
                    $chunkX = intval($x) >> 4;
                    $chunkZ = intval($z) >> 4;
                    if (!$player->getWorld()->isChunkLoaded($chunkX, $chunkZ)) {
                        $player->getWorld()->loadChunk($chunkX, $chunkZ);
                    } else {
                        $chunk = $player->getWorld()->getChunk($chunkX, $chunkZ);
                        if (!is_null($chunk)) {
                            foreach ($chunk->getTiles() as $tile) {
                                if (in_array(get_class($tile), $validTileTypes, true)) {
                                    $pourcent++;
                                }
                            }
                        }
                    }
                }
            }

            if ($pourcent !== 0) {
                $message = "§a" . $pourcent . "§7%%";
            } else {
                $message = "§c0%%";
            }
            $player->sendPopup($message);
            $itemInHand = $player->getInventory()->getItemInHand();
            if ($itemInHand instanceof Durable) {
                $itemInHand->applyDamage(1);
                $player->getInventory()->setItemInHand($itemInHand);
            }
        }
    }
}