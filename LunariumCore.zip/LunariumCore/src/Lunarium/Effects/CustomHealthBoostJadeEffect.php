<?php

declare(strict_types=1);

namespace Lunarium\Effects;

use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\Living;

class CustomHealthBoostJadeEffect extends Effect
{

    public function add(Living $entity, EffectInstance $instance): void
    {
        if (!$entity->getEffects()->has($this)){
            if ($entity->getMaxHealth() < 24){
                $entity->setMaxHealth(24);
            }
        }
    }

    public function remove(Living $entity, EffectInstance $instance): void
    {
        if (!$entity->getEffects()->has($this)) {

            $entity->setMaxHealth(20);

            if ($entity->getHealth() > 20) {
                $entity->setHealth(20);
            }
        }
    }
}