<?php

declare(strict_types=1);

namespace Lunarium\Effects;

use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\Living;

class CustomHealthBoostNacreEffect extends Effect
{

    public function add(Living $entity, EffectInstance $instance): void
    {
        if (!$entity->getEffects()->has($this)){
            if ($entity->getMaxHealth() < 28){
                $entity->setMaxHealth(28);
            }
        }
    }

    public function remove(Living $entity, EffectInstance $instance): void
    {
        if (!$entity->getEffects()->has($this)) {

            $entity->setMaxHealth(20);

            if ($entity->getHealth() > 20) {
                $entity->setHealth(20);
            }
        }
    }
}