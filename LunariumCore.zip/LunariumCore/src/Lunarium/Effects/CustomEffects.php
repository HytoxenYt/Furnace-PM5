<?php

declare(strict_types=1);

namespace Lunarium\Effects;

use Lunarium\Effects\CustomHealthBoostJadeEffect;
use pocketmine\color\Color;
use pocketmine\entity\effect\Effect;
use pocketmine\lang\KnownTranslationFactory;
use pocketmine\utils\RegistryTrait;

/**
 * @method static CustomHealthBoostJadeEffect CUSTOM_HEALTH_BOOST_JADE()
 * @method static CustomHealthBoostNacreEffect CUSTOM_HEALTH_BOOST_NACRE()
 * @method static CustomHealthBoostLunaireEffect CUSTOM_HEALTH_BOOST_LUNAIRE()
 */

final class CustomEffects
{
    use RegistryTrait;

    protected static function setup(): void
    {
        self::register("custom_health_boost_jade", new CustomHealthBoostJadeEffect(KnownTranslationFactory::potion_healthBoost(), new Color(0xf8, 0x7d, 0x23)));
        self::register("custom_health_boost_nacre", new CustomHealthBoostNacreEffect(KnownTranslationFactory::potion_healthBoost(), new Color(0xf8, 0x7d, 0x23)));
        self::register("custom_health_boost_lunaire", new CustomHealthBoostLunaireEffect(KnownTranslationFactory::potion_healthBoost(), new Color(0xf8, 0x7d, 0x23)));
    }

    protected static function register(string $name, Effect $member): void
    {
        self::_registryRegister($name, $member);
    }

    /**
     * @return Effect[]
     * @phpstan-return array<string, Effect>
     */
    public static function getAll(): array
    {
        //phpstan doesn't support generic traits yet :(
        /** @var Effect[] $result */
        $result = self::_registryGetAll();
        return $result;
    }
}
