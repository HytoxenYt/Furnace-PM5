<?php

namespace Lunarium\LunaMod\Item\Utility;

use customiesdevs\customies\item\component\AllowOffHandComponent;
use customiesdevs\customies\item\component\DurabilityComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\LunaMod\CustomRecipe;
use Lunarium\LunaMod\Item\CustomItem;
use pocketmine\block\VanillaBlocks;
use pocketmine\crafting\CraftingRecipe;
use pocketmine\crafting\ExactRecipeIngredient;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\entity\object\ItemEntity;
use pocketmine\item\Durable;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\player\Player;

class Aimant extends Item implements ItemComponents, CustomRecipe
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Aimant");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("aimant", $creativeInfo);
        $this->addComponent(new AllowOffHandComponent(false));
    }

    public static function onAimantEffect(Player $player): void
    {
        $inhand = $player->getInventory()->getItemInHand();

        if ($inhand instanceof Aimant) {
            $radius = 4;
            $radiusY = 2;

            foreach($player->getWorld()->getEntities() as $entity){
                if($entity instanceof ItemEntity && $entity->getPosition()->distance($player->getPosition()) < 5){
                    $playerPos = $player->getPosition();
                    $entityPos = $entity->getPosition();

                    $directionX = $playerPos->getX() - $entityPos->getX();
                    $directionY = $playerPos->getY() - $entityPos->getY();
                    $directionZ = $playerPos->getZ() - $entityPos->getZ();

                    $motion = new Vector3($directionX, $directionY, $directionZ);
                    $entity->setMotion($motion->normalize()->multiply(0.5));
                }
            }
        }
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }

    public static function getRecipe(): CraftingRecipe|array
    {
        return new ShapedRecipe(
            ["E E", "S S", "SSS"],
            [
                "E" => new ExactRecipeIngredient(StringToItemParser::getInstance()->parse(CustomItem::JADE_INGOT)),
                "S" => new ExactRecipeIngredient(VanillaItems::IRON_INGOT())
            ],
            [StringToItemParser::getInstance()->parse(CustomItem::AIMANT)]
        );
    }


}
