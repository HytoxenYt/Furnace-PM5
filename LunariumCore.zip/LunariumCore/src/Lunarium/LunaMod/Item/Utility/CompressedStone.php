<?php

namespace Lunarium\LunaMod\Item\Utility;

use customiesdevs\customies\item\component\AllowOffHandComponent;
use customiesdevs\customies\item\component\DurabilityComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\LunaMod\CustomRecipe;
use Lunarium\LunaMod\Item\CustomItem;
use pocketmine\block\VanillaBlocks;
use pocketmine\crafting\CraftingRecipe;
use pocketmine\crafting\ExactRecipeIngredient;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\item\Durable;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;

class CompressedStone extends Item implements ItemComponents, CustomRecipe
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Stone Compressé");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("compressed_stone", $creativeInfo);
        $this->addComponent(new AllowOffHandComponent(false));
    }

    public static function getRecipe(): CraftingRecipe|array
    {
        return new ShapedRecipe(
            ["SSS", "SSS", "SSS"],
            [
                "S" => new ExactRecipeIngredient(VanillaBlocks::COBBLESTONE()->asItem())
            ],
            [StringToItemParser::getInstance()->parse(CustomItem::COMPRESSED_STONE)]
        );
    }
}