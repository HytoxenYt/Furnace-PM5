<?php

namespace Lunarium\LunaMod\Item\Utility\Rune;

use customiesdevs\customies\item\component\AllowOffHandComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\block\Block;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class InvisibilityRune extends Item implements ItemComponents
{
    use ItemComponentsTrait;
    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Rune d'Invisibilité");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("invisibility_rune", $creativeInfo);
        $this->addComponent(new AllowOffHandComponent(true));
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }

    public function onClickAir(Player $player, Vector3 $directionVector, array &$returnedItems): ItemUseResult
    {
        $clickAir = parent::onClickAir($player, $directionVector, $returnedItems);

        if(!is_null($player)){
            $this->doInvisibility($player);
        }
        return $clickAir;
    }

    public function onInteractBlock(Player $player, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, array &$returnedItems): ItemUseResult
    {
        $interactBlock = parent::onInteractBlock($player, $blockReplace, $blockClicked, $face, $clickVector, $returnedItems);

        if(!is_null($player)){
            $this->doInvisibility($player);
        }
        return $interactBlock;
    }

    public function onInteractEntity(Player $player, Entity $entity, Vector3 $clickVector): bool
    {
        $interactEntity = parent::onInteractEntity($player, $entity, $clickVector);

        if(!is_null($player)){
            $this->doInvisibility($player);
        }
        return $interactEntity;
    }

    public function doInvisibility(Player $player): void
    {
        if(Utils::getCooldown()->has($player->getXuid(), "rune_invisibility")){
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre " . Main::getInstance()->intToTime(Utils::getCooldown()->get($player->getXuid(), "rune_invisibility"), "§c"));
            return;
        }

        $player->getEffects()->add(new EffectInstance(VanillaEffects::INVISIBILITY(), 36000, 10, false));
        Utils::getCooldown()->add($player->getXuid(), "rune_invisibility", (60 * 60) * 12);
        $player->sendMessage(Utils::PREFIX . "§fVous avez utilisé une §5Rune d'Invisibilité");
    }
}