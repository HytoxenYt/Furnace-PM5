<?php

namespace Lunarium\LunaMod\Item\Utility\Rune;

use customiesdevs\customies\item\component\AllowOffHandComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\CustomiesItemFactory;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\Utils\Utils;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class RandomRune extends Item implements ItemComponents
{
    use ItemComponentsTrait;
    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Rune Aléatoire");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("random_rune", $creativeInfo);
        $this->addComponent(new AllowOffHandComponent(true));
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }

    public function onClickAir(Player $player, Vector3 $directionVector, array &$returnedItems): ItemUseResult
    {
        $runes = [
            CustomiesItemFactory::getInstance()->get("lunarium:teleportation_rune"),
            CustomiesItemFactory::getInstance()->get("lunarium:invisibility_rune"),
            CustomiesItemFactory::getInstance()->get("lunarium:jobs_rune"),
            CustomiesItemFactory::getInstance()->get("lunarium:chaos_rune"),
        ];

        /** @var Item $randomRune */
        $randomRune = $runes[array_rand($runes)];

        $player->getInventory()->setItemInHand($player->getInventory()->getItemInHand()->pop());
        $player->getInventory()->addItem($randomRune);
        $player->sendMessage(Utils::PREFIX . "§fVous avez obtenu une §5" . $randomRune->getName());
        return ItemUseResult::SUCCESS();
    }

}