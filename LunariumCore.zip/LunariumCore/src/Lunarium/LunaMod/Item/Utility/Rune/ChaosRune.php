<?php

namespace Lunarium\LunaMod\Item\Utility\Rune;

use customiesdevs\customies\item\component\AllowOffHandComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\utils\Config;

class ChaosRune extends Item implements ItemComponents
{
    use ItemComponentsTrait;
    private Config $cooldowns;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Rune de Chaos");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("chaos_rune", $creativeInfo);
        $this->addComponent(new AllowOffHandComponent(true));
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }
}