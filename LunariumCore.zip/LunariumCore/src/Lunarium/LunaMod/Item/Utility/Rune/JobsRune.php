<?php

namespace Lunarium\LunaMod\Item\Utility\Rune;

use customiesdevs\customies\item\component\AllowOffHandComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\Main;
use Lunarium\Managers\JobsManager;
use Lunarium\Utils\Utils;
use pocketmine\block\Block;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class JobsRune extends Item implements ItemComponents
{
    use ItemComponentsTrait;
    private Config $cooldowns;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Rune de Métier");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("jobs_rune", $creativeInfo);
        $this->addComponent(new AllowOffHandComponent(true));
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }

    public function onClickAir(Player $player, Vector3 $directionVector, array &$returnedItems): ItemUseResult
    {
        $clickAir = parent::onClickAir($player, $directionVector, $returnedItems);

        if(!is_null($player)){
            $this->doJobs($player);
        }
        return $clickAir;
    }

    public function onInteractBlock(Player $player, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, array &$returnedItems): ItemUseResult
    {
        $interactBlock = parent::onInteractBlock($player, $blockReplace, $blockClicked, $face, $clickVector, $returnedItems);

        if(!is_null($player)){
            $this->doJobs($player);
        }
        return $interactBlock;
    }

    public function onInteractEntity(Player $player, Entity $entity, Vector3 $clickVector): bool
    {
        $interactEntity = parent::onInteractEntity($player, $entity, $clickVector);

        if(!is_null($player)){
            $this->doJobs($player);
        }
        return $interactEntity;
    }

    public function doJobs(Player $player): void
    {
        if (Utils::getCooldown()->has($player->getXuid(), "rune_jobs")) {
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre " . Main::getInstance()->intToTime(Utils::getCooldown()->get($player->getXuid(), "rune_jobs"), "§c"));
            return;
        }

        $jobs = [JobsManager::MINEUR, JobsManager::ASSASSIN, JobsManager::BUCHERON, JobsManager::FERMIER];

        $validJob = null;

        foreach ($jobs as $job) {
            if (JobsManager::getLevel($player, $job) < 25) {
                $validJob = $job;
                break;
            }
        }

        if ($validJob === null) {
            $player->sendMessage(Utils::PREFIX . "§cTous vos métiers sont déjà au niveau 25 ou plus. Vous ne pouvez plus utiliser la Rune de Métier.");
            return;
        }

        $i = rand(2000, 7000);
        JobsManager::addXp($player, $validJob, $i);

        $player->sendMessage(Utils::PREFIX . "§fVous avez gagné §5$i xp §fpour le métier de §5$validJob");

        Utils::getCooldown()->add($player->getXuid(), "rune_jobs", (60 * 60) * 24);
        $player->sendMessage(Utils::PREFIX . "§fVous avez utilisé une §5Rune de Métier");
    }

}