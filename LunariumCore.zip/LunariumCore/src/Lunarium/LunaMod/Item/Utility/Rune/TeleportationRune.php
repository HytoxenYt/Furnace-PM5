<?php

namespace Lunarium\LunaMod\Item\Utility\Rune;

use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\Utils\Utils;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\WorldException;

class TeleportationRune extends Item implements ItemComponents
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Rune de Téléportation");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::CATEGORY_EQUIPMENT);
        $this->initComponent("teleportation_rune", $creativeInfo);
    }
    
    public function getMaxStackSize(): int
    {
        return 1;
    }

    public function onClickAir(Player $player, Vector3 $directionVector, array &$returnedItems): ItemUseResult
    {
        $clickAir = parent::onClickAir($player, $directionVector, $returnedItems);

        if(!is_null($player)){
            $this->doTeleportation($player);
        }
        return $clickAir;
    }

    public function onInteractBlock(Player $player, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, array &$returnedItems): ItemUseResult
    {
        $interactBlock = parent::onInteractBlock($player, $blockReplace, $blockClicked, $face, $clickVector, $returnedItems);

        if(!is_null($player)){
            $this->doTeleportation($player);
        }
        return $interactBlock;
    }

    public function onInteractEntity(Player $player, Entity $entity, Vector3 $clickVector): bool
    {
        $interactEntity = parent::onInteractEntity($player, $entity, $clickVector);

        if(!is_null($player)){
            $this->doTeleportation($player);
        }
        return $interactEntity;
    }
    
    public function doTeleportation(Player $sender): void
    {
        $y = 200;
        $foundSafeLocation = false;
        $targetPosition = null;
        while (!$foundSafeLocation) {
            $xv = rand(1, 2);
            $x = ($xv === 1) ? rand(-5000, -9900) : rand(5000, 9900);

            $zv = rand(1, 2);
            $z = ($zv === 1) ? rand(-5000, -9900) : rand(5000, 9900);

            $chunkX = $x >> 4;
            $chunkZ = $z >> 4;

            if (!$sender->getWorld()->isChunkLoaded($chunkX, $chunkZ)) {
                $sender->getWorld()->loadChunk($chunkX, $chunkZ);
            }

            try {
                $targetPosition = $sender->getWorld()->getSafeSpawn(new Vector3($x, $y, $z));
                if ($targetPosition !== null) {
                    $foundSafeLocation = true;
                }
            } catch (WorldException $e) {
                var_dump($e->getMessage());
            }
        }
        $sender->teleport($targetPosition);
        $sender->sendMessage(Utils::PREFIX . "§fVous avez été téléporté aléatoirement");
    }
}
