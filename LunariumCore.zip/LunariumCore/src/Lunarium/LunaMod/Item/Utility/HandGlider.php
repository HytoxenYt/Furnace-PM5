<?php

namespace Lunarium\LunaMod\Item\Utility;

use customiesdevs\customies\item\component\AllowOffHandComponent;
use customiesdevs\customies\item\component\DurabilityComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use pocketmine\item\Durable;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\math\Vector3;

class HandGlider extends Durable implements ItemComponents
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Planeur");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("planeur", $creativeInfo);
        $this->addComponent(new DurabilityComponent(7));
        $this->addComponent(new AllowOffHandComponent(true));
    }

    public function getMaxDurability(): int
    {
        return 21600;
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }
}