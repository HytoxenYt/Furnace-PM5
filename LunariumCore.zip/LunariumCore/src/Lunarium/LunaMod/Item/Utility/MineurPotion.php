<?php

namespace Lunarium\LunaMod\Item\Utility;

use customiesdevs\customies\item\component\AllowOffHandComponent;
use customiesdevs\customies\item\component\DurabilityComponent;
use customiesdevs\customies\item\component\FoodComponent;
use customiesdevs\customies\item\component\UseDurationComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\LunaMod\CustomRecipe;
use Lunarium\LunaMod\Item\CustomItem;
use Lunarium\Utils\Utils;
use pocketmine\crafting\CraftingRecipe;
use pocketmine\crafting\ExactRecipeIngredient;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Living;
use pocketmine\entity\object\ItemEntity;
use pocketmine\item\Durable;
use pocketmine\item\Food;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\StringToItemParser;
use pocketmine\math\Vector3;
use pocketmine\player\Player;

class MineurPotion extends Food implements ItemComponents {

    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Potion de Mineur");
        $this->initComponent("mineur_potion", new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS));
        $this->addComponent(new FoodComponent(true));
        $this->addComponent(new UseDurationComponent(32));
    }

    public function getFoodRestore(): int {
        return 6;
    }

    public function getSaturationRestore(): float {
        return 9.3;
    }

    public function requiresHunger(): bool {
        return false;
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }

    public function onConsume(Living $consumer): void {
        $consumer->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 3 * 60 * 20, 9, false));
         if ($consumer instanceof Player) {
             $consumer->sendMessage(Utils::PREFIX . "§fVous avez du courage de boire cette §5Potion Sacré");
         }
    }
}
