<?php

namespace Lunarium\LunaMod\Item\Sword;

use customiesdevs\customies\item\component\DurabilityComponent;
use customiesdevs\customies\item\component\HandEquippedComponent;
use customiesdevs\customies\item\component\MaxStackSizeComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use pocketmine\item\enchantment\ItemEnchantmentTags as EnchantmentTags;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\Sword;
use pocketmine\item\ToolTier;

class NacreSword extends Sword implements ItemComponents
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Epée en Nacre", ToolTier::NETHERITE, [EnchantmentTags::SWORD]);

        $this->initComponent("nacre_sword", new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE));
        $this->addComponent(new DurabilityComponent(2972));
        $this->addComponent(new MaxStackSizeComponent(1));
        $this->addComponent(new HandEquippedComponent(true));
    }

    public function getMaxDurability(): int
    {
        return 2972;
    }

    public function getAttackPoints(): int
    {
        return 13;
    }
}