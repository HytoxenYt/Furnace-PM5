<?php

namespace Lunarium\LunaMod\Item\Stick;

use customiesdevs\customies\item\component\DurabilityComponent;
use customiesdevs\customies\item\component\HandEquippedComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\block\Block;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Entity;
use pocketmine\item\Durable;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;

class SpeedStick extends Durable implements ItemComponents
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Bâton de Vitesse");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("speed_stick", $creativeInfo);
        $this->addComponent(new DurabilityComponent(8));
        $this->addComponent(new HandEquippedComponent(true));
    }

    public function getMaxDurability(): int
    {
        return 8;
    }

    public function onInteractBlock(Player $player, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, array &$returnedItems): ItemUseResult
    {
        $this->doSpeed($player);
        return ItemUseResult::SUCCESS();
    }

    final function onInteractEntity(Player $player, Entity $entity, Vector3 $clickVector): bool
    {
        $this->doSpeed($player);
        return true;
    }

    final function onClickAir(Player $player, Vector3 $directionVector, array &$returnedItems): ItemUseResult
    {
        $this->doSpeed($player);
        return ItemUseResult::SUCCESS();
    }

    private function doSpeed(Player $player): void
    {
        $cooldownName = "speed_stick";
        $playerXuid = $player->getXuid();

        if (Utils::getCooldown()->has($playerXuid, $cooldownName)) {
            $remainingTime = Utils::getCooldown()->get($cooldownName, $playerXuid);
            $formattedTime = Main::getInstance()->intToTime(intval($remainingTime), "§c");
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre §5$formattedTime");
            return;
        }

        Utils::getCooldown()->add($playerXuid, $cooldownName, 60);

        $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 10 * 20, 2, false));
        $player->sendMessage(Utils::PREFIX . "§fVous avez utilisé votre §5Bâton de Vitesse");

        $this->applyDamage(1);
        $player->getInventory()->setItemInHand($this);
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }
}
