<?php

namespace Lunarium\LunaMod\Item\Stick;

use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\Main;
use Lunarium\Utils\Utils;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\item\Durable;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\player\Player;

class HealStick extends Item implements ItemComponents
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Bâton de Vie");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("heal_stick", $creativeInfo);
    }

    public function onInteractBlock(Player $player, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, array &$returnedItems): ItemUseResult
    {
        $this->doHeal($player);
        return ItemUseResult::SUCCESS();
    }

    final function onInteractEntity(Player $player, Entity $entity, Vector3 $clickVector): bool
    {
        $this->doHeal($player);
        return true;
    }

    final function onClickAir(Player $player, Vector3 $directionVector, array &$returnedItems): ItemUseResult
    {
        $this->doHeal($player);
        return ItemUseResult::SUCCESS();
    }


    private function doHeal(Player $player): void
    {
        $cooldownName = "heal_stick";
        $playerXuid = $player->getXuid();

        if (Utils::getCooldown()->has($playerXuid, $cooldownName)) {
            $remainingTime = Utils::getCooldown()->get($cooldownName, $playerXuid);
            $formattedTime = Main::getInstance()->intToTime(intval($remainingTime), "§c");
            $player->sendMessage(Utils::PREFIX . "§cVous devez attendre §5$formattedTime");
            return;
        }

        Utils::getCooldown()->add($playerXuid, $cooldownName, 5);

        $player->setHealth(min($player->getMaxHealth(), $player->getHealth() + 10));
        $player->sendMessage(Utils::PREFIX . "§fVous avez utilisé votre §5Bâton de Soin");

        $player->getInventory()->remove($this);
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }
}