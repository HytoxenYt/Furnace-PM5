<?php

namespace Lunarium\LunaMod\Item\Stick;

use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\Entity\Player;
use Lunarium\LunaMod\Item\CustomItem;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;

use pocketmine\world\sound\BlazeShootSound;

/**
 * @property mixed $cooldowns
 */
class MagicStick extends Item implements ItemComponents, Listener
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Bâton Magique");
        $creativeInfo = new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::CATEGORY_ITEMS);
        $this->initComponent("magic_stick", $creativeInfo);
    }

}
