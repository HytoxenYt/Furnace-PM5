<?php

namespace Lunarium\LunaMod\Item\Food;

use customiesdevs\customies\item\component\FoodComponent;
use customiesdevs\customies\item\component\UseDurationComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use pocketmine\data\bedrock\EffectIdMap;
use pocketmine\data\bedrock\EffectIds;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Living;
use pocketmine\item\Food;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class LunaireApple extends Food implements ItemComponents {

    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Pomme en Lunaire");
        $this->initComponent("lunaire_apple", new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::GROUP_COOKED_FOOD));
        $this->addComponent(new FoodComponent(true));
        $this->addComponent(new UseDurationComponent(32));
    }

    public function getFoodRestore(): int {
        return 6;
    }

    public function getSaturationRestore(): float {
        return 9.3;
    }

    public function requiresHunger(): bool {
        return false;
    }

    public function onConsume(Living $consumer): void {
        $consumer->getEffects()->add(new EffectInstance(VanillaEffects::ABSORPTION(), 20 * 120, 1, true));
        $consumer->getEffects()->add(new EffectInstance(VanillaEffects::REGENERATION(), 20 * 7, 1, true));
    }
}
