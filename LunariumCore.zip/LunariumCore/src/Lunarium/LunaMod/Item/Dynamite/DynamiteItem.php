<?php

namespace Lunarium\LunaMod\Item\Dynamite;

use customiesdevs\customies\item\component\HandEquippedComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\Entity\DynamiteEntity;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Living;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ProjectileItem;
use pocketmine\player\Player;

class DynamiteItem extends ProjectileItem implements ItemComponents {
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Dynamite", []);


        $this->initComponent("dynamite", new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE));
        $this->addComponent(new HandEquippedComponent(true));
    }

    public function getThrowForce() : float{
        return 1.5;
    }

    protected function createEntity(Location $location, Player $thrower): Throwable
    {
        return new DynamiteEntity($location, $thrower);
    }
}
