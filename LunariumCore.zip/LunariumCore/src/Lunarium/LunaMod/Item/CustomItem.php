<?php

namespace Lunarium\LunaMod\Item;

class CustomItem
{
    const PREFIX = "lunarium:";

    const COTON = self::PREFIX . "coton";
    const TOMATO = self::PREFIX . "tomato";
    const STRAWBERRY = self::PREFIX . "strawberry";
    const COTON_CROP_SEED = self::PREFIX . "coton_crop_seed";
    const TOMATO_CROP_SEED = self::PREFIX . "tomato_crop_seed";
    const STRAWBERRY_CROP_SEED = self::PREFIX . "strawberry_crop_seed";

    const JADE_POWDER = self::PREFIX . "jade_powder";
    const NACRE_POWDER = self::PREFIX . "nacre_powder";
    const LUNAIRE_POWDER = self::PREFIX . "lunaire_powder";

    const JADE_FRAGMENT = self::PREFIX . "jade_fragment";
    const NACRE_FRAGMENT = self::PREFIX . "nacre_fragment";
    const LUNAIRE_FRAGMENT = self::PREFIX . "lunaire_fragment";

    const JADE_INGOT = self::PREFIX . "jade_ingot";
    const NACRE_INGOT = self::PREFIX . "nacre_ingot";
    const LUNAIRE_INGOT = self::PREFIX . "lunaire_ingot";

    const NACRE_PICKAXE = self::PREFIX . "nacre_pickaxe";
    const NACRE_AXE = self::PREFIX . "nacre_axe";
    const NACRE_SHOVEL = self::PREFIX . "nacre_shovel";
    const NACRE_HOE = self::PREFIX . "nacre_hoe";

    const JADE_PICKAXE = self::PREFIX . "jade_pickaxe";
    const JADE_AXE = self::PREFIX . "jade_axe";
    const JADE_SHOVEL = self::PREFIX . "jade_shovel";
    const JADE_HOE = self::PREFIX . "jade_hoe";

    const LUNAIRE_PICKAXE = self::PREFIX . "lunarium_pickaxe";
    const LUNAIRE_AXE = self::PREFIX . "lunarium_axe";
    const LUNAIRE_SHOVEL = self::PREFIX . "lunarium_shovel";
    const LUNAIRE_HOE = self::PREFIX . "lunarium_hoe";

    const NACRE_HAMMER = self::PREFIX . "nacre_hammer";
    const JADE_HAMMER = self::PREFIX . "jade_hammer";

    const LUNAIRE_SWORD = self::PREFIX . "lunaire_sword";
    const JADE_SWORD = self::PREFIX . "jade_sword";
    const NACRE_SWORD = self::PREFIX . "nacre_sword";
    const DYNAMITE = self::PREFIX . "dynamite";

    const JADE_HELMET = self::PREFIX . "jade_helmet";
    const JADE_CHESTPLATE = self::PREFIX . "jade_chestplate";
    const JADE_LEGGINGS = self::PREFIX . "jade_leggings";
    const JADE_BOOTS = self::PREFIX . "jade_boots";

    const NACRE_HELMET = self::PREFIX . "nacre_helmet";
    const NACRE_CHESTPLATE = self::PREFIX . "nacre_chestplate";
    const NACRE_LEGGINGS = self::PREFIX . "nacre_leggings";
    const NACRE_BOOTS = self::PREFIX . "nacre_boots";

    const LUNAIRE_HELMET = self::PREFIX . "lunaire_helmet";
    const LUNAIRE_CHESTPLATE = self::PREFIX . "lunaire_chestplate";
    const LUNAIRE_LEGGINGS = self::PREFIX . "lunaire_leggings";
    const LUNAIRE_BOOTS = self::PREFIX . "lunaire_boots";

    const FARM_HELMET = self::PREFIX . "farm_helmet";
    const FARM_CHESTPLATE = self::PREFIX . "farm_chestplate";
    const FARM_LEGGINGS = self::PREFIX . "farm_leggings";
    const FARM_BOOTS = self::PREFIX . "farm_boots";

    const PLANEUR = self::PREFIX . "planeur";
    const CHEST_EXPLORER = self::PREFIX . "chest_explorer";
    const UNCLAIM_FINDER_VERT = self::PREFIX . "unclaim_finder_vert";
    const UNCLAIM_FINDER_VIOLET = self::PREFIX . "unclaim_finder_violet";

    const LUNAIRE_APPLE = self::PREFIX . "lunaire_apple";
    const JADE_APPLE = self::PREFIX . "jade_apple";
    const LUNAIRE_KEY = self::PREFIX . "lunaire_key";

    const SPEED_STICK = self::PREFIX . "speed_stick";
    const JUMP_STICK = self::PREFIX . "jump_stick";
    const STRENGTH_STICK = self::PREFIX . "strength_stick";

    const CREEPER_EGG_SPAWN = self::PREFIX . "creeper_egg_spawn";
    const BILLET = self::PREFIX . "billet";
    const LUNAIRE_SEED = self::PREFIX . "lunaire_seed";
    const EARTH = self::PREFIX . "earth";
    const WING = self::PREFIX . "wing";
    const HAT = self::PREFIX . "hat";
    const VOTE_KEY = self::PREFIX . "vote_key";
    const NACRE_KEY = self::PREFIX . "nacre_key";
    const JADE_KEY = self::PREFIX . "jade_key";
    const HEAL_STICK = self::PREFIX . "heal_stick";
    const RANDOM_RUNE = self::PREFIX . "random_rune";
    const JOBS_RUNE = self::PREFIX . "jobs_rune";
    const INVISIBILITY_RUNE = self::PREFIX . "invisibility_rune";
    const CHAOS_RUNE = self::PREFIX . "chaos_rune";
    const TELEPORTATION_RUNE = self::PREFIX . "teleportion_rune";
    const LUNAIRE_HAMMER = self::PREFIX . "lunaire_hammer";

    const MINEUR_POTION = self::PREFIX . "mineur_potion";
    const AIMANT = self::PREFIX . "aimant";

    const COMPRESSED_STONE = self::PREFIX . "compressed_stone";
    const SLIMEPAD = self::PREFIX . "slimepad";
    const ELEVATOR = self::PREFIX . "elevator";
    const SEEDPLANTER = self::PREFIX . "seedplanter";
    const DRAWER = self::PREFIX . "drawer";
    const CAVEBLOCK = self::PREFIX . "cave_block";
    const LUNAIRE_CHEST = self::PREFIX . "lunaire_chest";
    const LIVRE = self::PREFIX . "livre";
    const MAGIC_STICK = self::PREFIX . "magic_stick";
}
