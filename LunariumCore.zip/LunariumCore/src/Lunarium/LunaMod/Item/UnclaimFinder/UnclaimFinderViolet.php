<?php

namespace Lunarium\LunaMod\Item\UnclaimFinder;

use customiesdevs\customies\item\component\DurabilityComponent;
use customiesdevs\customies\item\component\HandEquippedComponent;
use customiesdevs\customies\item\component\MaxStackSizeComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use Lunarium\LunaMod\CustomRecipe;
use Lunarium\LunaMod\Item\CustomItem;
use pocketmine\block\tile\Barrel;
use pocketmine\block\tile\Chest;
use pocketmine\block\tile\Furnace;
use pocketmine\block\tile\Hopper;
use pocketmine\block\tile\MonsterSpawner;
use pocketmine\crafting\CraftingRecipe;
use pocketmine\crafting\ExactRecipeIngredient;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\item\Durable;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

class UnclaimFinderViolet extends Durable implements ItemComponents, CustomRecipe
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Unclaim Finder Violet");
        $this->initComponent("unclaim_finder_violet", new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::NONE));
        $this->setNamedTag($this->getNamedTag()->setInt("type", 10));
        $this->addComponent(new HandEquippedComponent(true));
        $this->addComponent(new MaxStackSizeComponent(1));
        $this->addComponent(new DurabilityComponent(7200));
    }

    public function check(Player $player): int
    {
        $rayon = 16 * $this->getNamedTag()->getInt("type");
        $xMax = $player->getPosition()->getX() + $rayon;
        $zMax = $player->getPosition()->getZ() + $rayon;
        $pourcent = 0;

        $validTileTypes = [
            Furnace::class,
            Hopper::class,
            Barrel::class,
            Chest::class,
            MonsterSpawner::class
        ];

        for ($x = $player->getPosition()->getX() - $rayon; $x <= $xMax; $x += 16) {
            for ($z = $player->getPosition()->getZ() - $rayon; $z <= $zMax; $z += 16) {
                $chunkX = intval($x) >> 4;
                $chunkZ = intval($z) >> 4;

                if (!$player->getWorld()->isChunkLoaded($chunkX, $chunkZ)) {
                    $player->getWorld()->loadChunk($chunkX, $chunkZ);
                }

                $chunk = $player->getWorld()->getChunk($chunkX, $chunkZ);
                if (!is_null($chunk)) {
                    foreach ($chunk->getTiles() as $tile) {
                        if (in_array(get_class($tile), $validTileTypes, true)) {
                            $pourcent++;
                        }
                    }
                }
            }
        }


        return $pourcent;
    }


    public function getMaxDurability(): int
    {
        return 7200;
    }

    public function getMaxStackSize(): int
    {
        return 1;
    }

    public static function getRecipe(): CraftingRecipe|array
    {
        return new ShapedRecipe(
            ["EEE", "ESE", "EEE"],
            [
                "E" => new ExactRecipeIngredient(StringToItemParser::getInstance()->parse(CustomItem::NACRE_HAMMER)),
                "S" => new ExactRecipeIngredient(StringToItemParser::getInstance()->parse(CustomItem::LUNAIRE_POWDER))
            ],
            [StringToItemParser::getInstance()->parse(CustomItem::UNCLAIM_FINDER_VIOLET)]
        );
    }
}