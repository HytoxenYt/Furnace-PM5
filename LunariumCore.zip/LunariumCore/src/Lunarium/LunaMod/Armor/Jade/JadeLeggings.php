<?php

namespace Lunarium\LunaMod\Armor\Jade;

use customiesdevs\customies\item\component\DurabilityComponent;
use customiesdevs\customies\item\component\MaxStackSizeComponent;
use customiesdevs\customies\item\component\WearableComponent;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\ItemComponentsTrait;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Entity;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\Armor;
use pocketmine\item\ArmorTypeInfo;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\player\Player;

class JadeLeggings extends Armor implements ItemComponents
{
    use ItemComponentsTrait;

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::newId()), "Jambière en Jade", new ArmorTypeInfo($this->getDefensePoints(), $this->getMaxDurability(), ArmorInventory::SLOT_LEGS));
        $this->initComponent("jade_leggings", new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_ITEMS, CreativeInventoryInfo::GROUP_LEGGINGS));
        $this->addComponent(new DurabilityComponent(744));
        $this->addComponent(new MaxStackSizeComponent(1));
        $this->addComponent(new WearableComponent(WearableComponent::SLOT_ARMOR_LEGS, $this->getDefensePoints()));
    }

    public function getDefensePoints(): int
    {
        return 6;
    }

    public function getMaxDurability(): int
    {
        return 744;
    }
}