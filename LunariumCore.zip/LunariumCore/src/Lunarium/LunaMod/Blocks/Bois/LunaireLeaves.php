<?php

namespace Lunarium\LunaMod\Blocks\Bois;

use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeInfo;
use pocketmine\block\Opaque;
use pocketmine\event\Listener;

class LunaireLeaves extends Opaque implements Listener {

    public function __construct(BlockIdentifier $idInfo, string $name, BlockTypeInfo $blockTypeInfo) {
        parent::__construct($idInfo, $name, $blockTypeInfo);
    }


}
