<?php

namespace Lunarium\LunaMod\Blocks\Bois;

use pocketmine\block\Block;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeInfo;

class LunairePlanks extends Block {

    public function __construct(BlockIdentifier $idInfo, string $name, BlockTypeInfo $blockTypeInfo) {
        parent::__construct($idInfo, $name, $blockTypeInfo);
    }
}
