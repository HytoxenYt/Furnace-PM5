<?php

namespace Lunarium\LunaMod\Blocks\Minerais;

use customiesdevs\customies\item\CustomiesItemFactory;
use pocketmine\block\Block;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeInfo;
use pocketmine\item\Item;

class JadeOre extends Block {

    public function __construct(BlockIdentifier $idInfo, string $name, BlockTypeInfo $blockTypeInfo) {
        parent::__construct($idInfo, $name, $blockTypeInfo);
    }

    protected function getXpDropAmount() : int{
        return mt_rand(3, 7);
    }

    public function getDropsForCompatibleTool(Item $item) : array{
        return [
            CustomiesItemFactory::getInstance()->get("jade_ingot")
        ];
    }
}
