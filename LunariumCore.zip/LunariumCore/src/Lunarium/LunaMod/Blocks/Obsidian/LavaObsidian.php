<?php

namespace Lunarium\LunaMod\Blocks\Obsidian;

use pocketmine\block\Block;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeInfo;
use pocketmine\event\Listener;

class LavaObsidian extends Block implements Listener {

    public function __construct(BlockIdentifier $idInfo, string $name, BlockTypeInfo $blockTypeInfo) {
        parent::__construct($idInfo, $name, $blockTypeInfo);
    }
}
