<?php

namespace Lunarium\LunaMod\Blocks\Chest;

use customiesdevs\customies\block\permutations\BlockProperty;
use customiesdevs\customies\block\permutations\Permutable;
use customiesdevs\customies\block\permutations\Permutation;
use customiesdevs\customies\block\permutations\Permutations;
use Lunarium\LunaMod\Blocks\Chest\Tile\CustomChestTile;
use pocketmine\block\Chest;
use pocketmine\world\sound\ChestCloseSound;
use pocketmine\world\sound\ChestOpenSound;
use customiesdevs\customies\block\permutations\RotatableTrait;
use pocketmine\block\Block;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeInfo;
use pocketmine\data\bedrock\block\convert\BlockStateReader;
use pocketmine\data\bedrock\block\convert\BlockStateWriter;
use pocketmine\item\Item;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\world\BlockTransaction;

class CustomChest extends Chest implements Permutable
{
    use RotatableTrait;

    public function __construct(BlockIdentifier $idInfo, string $name, BlockTypeInfo $typeInfo)
    {
        parent::__construct($idInfo, $name, $typeInfo);
    }

    public function getBlockProperties(): array
    {
        return [
            new BlockProperty("customies:rotation", [2, 3, 4, 5]),
        ];
    }

    public function getPermutations(): array {
        return [
            (new Permutation("q.block_property('customies:rotation') == 2"))
                ->withComponent("minecraft:transformation", CompoundTag::create()
                    ->setInt("RX", 0)
                    ->setInt("RY", 2)
                    ->setInt("RZ", 0)
                    ->setFloat("SX", 1.0)
                    ->setFloat("SY", 1.0)
                    ->setFloat("SZ", 1.0)
                    ->setFloat("TX", 0.0)
                    ->setFloat("TY", 0.0)
                    ->setFloat("TZ", 0.0)),
            (new Permutation("q.block_property('customies:rotation') == 3"))
                ->withComponent("minecraft:transformation", CompoundTag::create()
                    ->setInt("RX", 0)
                    ->setInt("RY", 0)
                    ->setInt("RZ", 0)
                    ->setFloat("SX", 1.0)
                    ->setFloat("SY", 1.0)
                    ->setFloat("SZ", 1.0)
                    ->setFloat("TX", 0.0)
                    ->setFloat("TY", 0.0)
                    ->setFloat("TZ", 0.0)),
            (new Permutation("q.block_property('customies:rotation') == 4"))
                ->withComponent("minecraft:transformation", CompoundTag::create()
                    ->setInt("RX", 0)
                    ->setInt("RY", 3)
                    ->setInt("RZ", 0)
                    ->setFloat("SX", 1.0)
                    ->setFloat("SY", 1.0)
                    ->setFloat("SZ", 1.0)
                    ->setFloat("TX", 0.0)
                    ->setFloat("TY", 0.0)
                    ->setFloat("TZ", 0.0)),
            (new Permutation("q.block_property('customies:rotation') == 5"))
                ->withComponent("minecraft:transformation", CompoundTag::create()
                    ->setInt("RX", 0)
                    ->setInt("RY", 1)
                    ->setInt("RZ", 0)
                    ->setFloat("SX", 1.0)
                    ->setFloat("SY", 1.0)
                    ->setFloat("SZ", 1.0)
                    ->setFloat("TX", 0.0)
                    ->setFloat("TY", 0.0)
                    ->setFloat("TZ", 0.0)),
        ];
    }

    public function getCurrentBlockProperties(): array
    {
        return [$this->facing];
    }

    protected function writeStateToMeta(): int
    {
        return Permutations::toMeta($this);
    }

    public function readStateFromData(int $id, int $stateMeta): void
    {
        $blockProperties = Permutations::fromMeta($this, $stateMeta);
        $this->facing = $blockProperties[0] ?? Facing::NORTH;
    }

    public function getStateBitmask(): int
    {
        return Permutations::getStateBitmask($this);
    }

    public function serializeState(BlockStateWriter $out): void
    {
        $out->writeInt("customies:rotation", $this->facing);
    }

    public function deserializeState(BlockStateReader $in): void
    {
        $this->facing = $in->readInt("customies:rotation");
    }

    public function place(BlockTransaction $tx, Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, ?Player $player = null): bool
    {
        if (!is_null($player)) {
            $this->facing = $player->getHorizontalFacing();
        }
        return parent::place($tx, $item, $blockReplace, $blockClicked, $face, $clickVector, $player);
    }

    public function onInteract(Item $item, int $face, Vector3 $clickVector, ?Player $player = null, array &$returnedItems = []): bool
    {
        $tile = $this->getPosition()->getWorld()->getTile($this->getPosition());
        if (!is_null($tile) && $tile instanceof CustomChestTile && !is_null($player) && is_null($player->getCurrentWindow()))
        {
            $player->getWorld()->addSound($player->getEyePos(), new ChestOpenSound());
            $player->setCurrentWindow($tile->getInventory());
        }
        return parent::onInteract($item, $face, $clickVector, $player, $returnedItems);
    }


}