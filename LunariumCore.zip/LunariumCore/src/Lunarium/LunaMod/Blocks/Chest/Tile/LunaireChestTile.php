<?php

namespace Lunarium\LunaMod\Blocks\Chest\Tile;

use pocketmine\math\Vector3;
use pocketmine\world\World;
use tedo0627\inventoryui\CustomInventory;

class LunaireChestTile extends CustomChestTile
{
    private CustomInventory $customInventory;

    public function __construct(World $world, Vector3 $pos)
    {
        parent::__construct($world, $pos);
        $this->customInventory = new CustomInventory($this->getSlots(), $this->getDefaultName());
    }

    public function getDefaultName(): string
    {
        return "Coffre Lunaire";
    }

    public function getSlots(): int
    {
        return 99;
    }
}