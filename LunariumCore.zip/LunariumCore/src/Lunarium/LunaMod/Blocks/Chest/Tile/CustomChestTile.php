<?php

namespace Lunarium\LunaMod\Blocks\Chest\Tile;

use pocketmine\block\tile\Container;
use pocketmine\block\tile\ContainerTrait;
use pocketmine\block\tile\Nameable;
use pocketmine\block\tile\NameableTrait;
use pocketmine\block\tile\Spawnable;
use pocketmine\inventory\Inventory;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\timings\TimingsHandler;
use pocketmine\world\World;
use tedo0627\inventoryui\CustomInventory;
use pocketmine\world\sound\ChestCloseSound;
use pocketmine\world\sound\ChestOpenSound;

class CustomChestTile extends Spawnable implements Container, Nameable
{
    use ContainerTrait;
    use NameableTrait;

    private CustomInventory $customInventory;

    public function __construct(World $world, Vector3 $pos)
    {
        parent::__construct($world, $pos);
        $this->customInventory = new CustomInventory($this->getSlots(), $this->getDefaultName());
    }

    public function getRealInventory(): Inventory
    {
        return $this->customInventory;
    }

    public function getInventory(): Inventory
    {
        return $this->customInventory;
    }

    public function getDefaultName(): string
    {
        return "CustomChest";
    }

    public function readSaveData(CompoundTag $nbt): void
    {
        $this->loadItems($nbt);
        $this->loadName($nbt);
    }

    protected function writeSaveData(CompoundTag $nbt): void
    {
        $this->saveItems($nbt);
        $this->saveName($nbt);
    }

    public function close(): void
    {
        if (!$this->closed) {
            $this->customInventory->removeAllViewers();
            parent::close();
        }
    }

    public function getSlots(): int
    {
        return 26;
    }

}