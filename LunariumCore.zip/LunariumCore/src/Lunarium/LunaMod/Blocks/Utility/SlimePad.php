<?php

namespace Lunarium\LunaMod\Blocks\Utility;

use pocketmine\block\Block;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeInfo;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\player\Player;

class SlimePad extends Block implements Listener {

    public function __construct(BlockIdentifier $idInfo, string $name, BlockTypeInfo $blockTypeInfo) {
        parent::__construct($idInfo, $name, $blockTypeInfo);
    }

    public function onEntityInside(Entity $entity): bool
    {
        $entity->setMotion(new Vector3(0, 1.2, 0));
        return true;
    }
}
