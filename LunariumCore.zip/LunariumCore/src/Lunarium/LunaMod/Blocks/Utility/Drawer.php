<?php

namespace Lunarium\LunaMod\Blocks\Utility;

use customiesdevs\customies\item\CustomiesItemFactory;
use Lunarium\LunaMod\Item\CustomItem;
use Lunarium\Utils\Utils;
use pocketmine\block\Block;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Item;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\VanillaItems;

class Drawer extends Block implements Listener {

    public function __construct(BlockIdentifier $idInfo, string $name, BlockTypeInfo $blockTypeInfo) {
        parent::__construct($idInfo, $name, $blockTypeInfo);
    }
}
