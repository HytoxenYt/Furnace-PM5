<?php

namespace Lunarium\LunaMod\Blocks\Seeds;

use customiesdevs\customies\item\CustomiesItemFactory;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Flowable;
use pocketmine\item\Item;
use pocketmine\math\Facing;

class CotonStage3 extends Flowable
{
    public function getDropsForCompatibleTool(Item $item): array
    {
        return [CustomiesItemFactory::getInstance()->get("lunarium:coton")->setCount(mt_rand(1,3))];
    }

    public function onNearbyBlockChange(): void
    {
        if($this->getSide(Facing::DOWN)->getTypeId() !== BlockTypeIds::FARMLAND){
            $this->position->getWorld()->useBreakOn($this->position);
        }
    }
}