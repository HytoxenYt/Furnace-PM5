<?php

namespace Lunarium\LunaMod\Blocks\Seeds;

use customiesdevs\customies\block\CustomiesBlockFactory;
use customiesdevs\customies\item\CustomiesItemFactory;
use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Flowable;
use pocketmine\data\runtime\RuntimeDataDescriber;
use pocketmine\event\block\BlockGrowEvent;
use pocketmine\item\Fertilizer;
use pocketmine\item\Item;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\BlockTransaction;
use pocketmine\world\Position;

class LunairePlantStage2 extends Flowable {

    public const MAX_AGE = 7;

    protected int $age = 0;

    protected function describeBlockOnlyState(RuntimeDataDescriber $w) : void{
        $w->boundedInt(3, 0, self::MAX_AGE, $this->age);
    }

    public function getDropsForCompatibleTool(Item $item): array
    {
        return [CustomiesItemFactory::getInstance()->get("lunarium:lunaire_seed")];
    }

    private function grow(Position $pos) : void
    {
        $world = $pos->getWorld();
        $world->setBlockAt($pos->x, $pos->y, $pos->z, CustomiesBlockFactory::getInstance()->get("lunarium:lunaire_plant_stage_3"));
    }

    public function getAge() : int{ return $this->age; }

    /** @return $this */
    public function setAge(int $age) : self{
        if($age < 0 || $age > self::MAX_AGE){
            throw new \InvalidArgumentException("Age must be in range 0 ... " . self::MAX_AGE);
        }
        $this->age = $age;
        return $this;
    }

    public function onInteract(Item $item, int $face, Vector3 $clickVector, ?Player $player = null, array &$returnedItems = []) : bool{
        if($item instanceof Fertilizer){
            $this->grow($this->position);
            $item->pop();
            return true;
        }
        return false;
    }

    public function onNearbyBlockChange() : void{
        if($this->getSide(Facing::DOWN)->getTypeId() !== BlockTypeIds::FARMLAND){
            $this->position->getWorld()->useBreakOn($this->position);
        }
    }

    public function ticksRandomly() : bool{
        return true;
    }

    public function onRandomTick() : void{
        if($this->age < self::MAX_AGE && mt_rand(0, 2) === 1){
            $block = clone $this;
            ++$block->age;
            $ev = new BlockGrowEvent($this, $block);
            $ev->call();
            if(!$ev->isCancelled()){
                $this->grow($this->position);
            }
        }
    }

    public function place(BlockTransaction $tx, Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, ?Player $player = null) : bool{
        if($blockReplace->getSide(Facing::DOWN)->getTypeId() === BlockTypeIds::FARMLAND){
            return parent::place($tx, $item, $blockReplace, $blockClicked, $face, $clickVector, $player);
        }
        return false;
    }
}
