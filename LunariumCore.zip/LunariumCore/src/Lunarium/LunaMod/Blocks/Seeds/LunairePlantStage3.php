<?php

namespace Lunarium\LunaMod\Blocks\Seeds;

use customiesdevs\customies\item\CustomiesItemFactory;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Flowable;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\math\Facing;

class LunairePlantStage3 extends Flowable {

    /**
     * @param Item $item
     * @return array|Item[]
     */
    public function getDropsForCompatibleTool(Item $item): array
    {
        $rand = rand(1, 50);
        if ($rand < 49 ) {
            return [VanillaItems::AIR()];
        } else {
            return [CustomiesItemFactory::getInstance()->get("lunarium:lunaire_powder")];
        }
    }

    /**
     * @return void
     */
    public function onNearbyBlockChange() : void{
        if($this->getSide(Facing::DOWN)->getTypeId() !== BlockTypeIds::FARMLAND){
            $this->position->getWorld()->useBreakOn($this->position);
        }
    }
}
