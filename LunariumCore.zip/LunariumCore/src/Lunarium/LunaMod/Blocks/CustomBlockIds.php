<?php

namespace Lunarium\LunaMod\Blocks;

use customiesdevs\customies\block\CustomiesBlockFactory;
use pocketmine\block\Block;

class CustomBlockIds {
    public const LUNAIRE_LEAVES_ID = 1101;
    public const LUNAIRE_WOOD_ID = 1102;
    public const LUNAIRE_PLANKS_ID = 1103;
    public const NACRE_ORE_ID = 1104;
    public const JADE_ORE_ID = 1105;
    public const LUNAIRE_ORE_ID = 1106;
    public const LUNAIRE_PLANT_1_ID = 1107;
    public const LUNAIRE_PLANT_2_ID = 1108;
    public const LUNAIRE_PLANT_3_ID = 1109;
    public const LAVA_OBSIDIAN_ID = 1110;
    public const STRAWBERRY_STAGE_1 = 1111;
    public const STRAWBERRY_STAGE_2 = 1112;
    public const STRAWBERRY_STAGE_3 = 1113;
    public const COTON_STAGE_1 = 1114;
    public const COTON_STAGE_2 = 1115;
    public const COTON_STAGE_3 = 1116;
    public const TOMATE_STAGE_1 = 1117;
    public const TOMATE_STAGE_2 = 1118;
    public const TOMATE_STAGE_3 = 1119;

    public const COBBLEBREAKER = 1120;
    public const SLIMEPAD = 1121;
    public const ELEVATOR = 1122;
    public const CAVEBLOCK = 1123;
    public const DRAWER = 1124;
    public const LUNAIRE_CHEST = 1125;
    public const LIVRE = 1126;


    public static function get(string $identifier): Block
    {
        return CustomiesBlockFactory::getInstance()->get($identifier);
    }
}
