<?php

namespace Lunarium\LunaMod;


use pocketmine\crafting\CraftingRecipe;

interface CustomRecipe {
    /**
     * @return CraftingRecipe|CraftingRecipe[]
     */
    public static function getRecipe() : CraftingRecipe|array;
}