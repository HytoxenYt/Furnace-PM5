<?php

/*
 * ███╗   ███╗██╗   ██╗███████╗██╗   ██╗██╗    ███████╗███████╗███████╗███████╗███╗   ██╗████████╗██╗ █████╗ ██╗     ███████╗
 * ████╗ ████║██║   ██║██╔════╝██║   ██║██║    ██╔════╝██╔════╝██╔════╝██╔════╝████╗  ██║╚══██╔══╝██║██╔══██╗██║     ██╔════╝
 * ██╔████╔██║██║   ██║███████╗██║   ██║██║    █████╗  ███████╗███████╗█████╗  ██╔██╗ ██║   ██║   ██║███████║██║     ███████╗
 * ██║╚██╔╝██║██║   ██║╚════██║██║   ██║██║    ██╔══╝  ╚════██║╚════██║██╔══╝  ██║╚██╗██║   ██║   ██║██╔══██║██║     ╚════██║
 * ██║ ╚═╝ ██║╚██████╔╝███████║╚██████╔╝██║    ███████╗███████║███████║███████╗██║ ╚████║   ██║   ██║██║  ██║███████╗███████║
 * ╚═╝     ╚═╝ ╚═════╝ ╚══════╝ ╚═════╝ ╚═╝    ╚══════╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝
 *
 * You may not redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published.
 * under the terms of the GNU Lesser General Public License as published by the
 *
 * @author Zwuiix-cmd
 * @link https://discord.gg/musui
 *
 */



namespace CortexPE\Commando\args;

use nagasaki\loader\manager\KeyManager;
use CortexPE\Commando\args\StringEnumArgument;
use pocketmine\command\CommandSender;

class KeysArgument extends StringEnumArgument
{
    protected const VALUES = [
        "0" => 0,
        "s" => 0,
        "survival" => 0,

        "1" => 1,
        "c" => 1,
        "creative" => 1,

        "2" => 2,
        "a" => 2,
        "adventure" => 2,


        "3" => 3,
        "spec" => 3,
        "spectator" => 3,
    ];

    public function getTypeName(): string
    {
        return "mode";
    }

    public function getEnumName(): string
    {
        return "mode";
    }

    /**
     * @param string $argument
     * @param CommandSender $sender
     * @return mixed
     */
    public function parse(string $argument, CommandSender $sender): mixed
    {
        return $this->getValue($argument) ?? null;
    }
}
